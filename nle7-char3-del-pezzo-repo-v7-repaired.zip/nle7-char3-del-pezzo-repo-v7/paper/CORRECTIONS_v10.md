# Corrections applied in `N_le_7_char3_paper_draft_v10`

This note records the concrete source-level fixes applied after the v8 review.

## Mathematical / logical consistency fixes

1. **Mixed-basket grouped normalization fixed.**
   The displayed standard canonical subsystem is now chosen in the grouped-model-compatible form
   \[
   S_{\mathrm{std}}=\langle E_3-E_1,\ E_1-E_2,\ E_6-E_4,\ E_5-E_6,\ E_7-E_8\rangle,
   \]
   so Proposition 5.4 now correctly forces
   \[
   m_1=m_2=m_3,\qquad m_4=m_5=m_6,\qquad m_7=m_8.
   \]
   This removes the previous mismatch between the displayed grouped form and the orthogonality calculation.

2. **Exotic-basket appendix counts corrected.**
   Appendix B now records the corrected orthogonal root counts
   \[
   56,\ 48,\ 32
   \]
   instead of the stale pre-patch `56, 30, 30` wording.

3. **Small-discriminant-window wording corrected.**
   The prose now distinguishes between the 45 baskets decided immediately and the 2 historically unresolved baskets that were resolved later, removing the arithmetic ambiguity in the v8 wording.

## Cross-reference and editorial fixes

4. **`cleveref` theorem/proposition/lemma typing fixed.**
   The theorem-like environments now use `aliascnt`, so cross-references render with the correct labels (`proposition`, `lemma`, etc.) instead of collapsing to `theorem`.

5. **Spacing typo fixed.**
   The `i.e.all` extraction issue was fixed by changing `\ie all` to `\ie{} all`.

6. **Repeated orbit representatives clarified.**
   Proposition 5.6 now explicitly notes that orbits 2 and 3 share one displayed witness class, as do orbits 6 and 7.

7. **Repository placeholder text regularized.**
   The raw GitHub placeholder URL was replaced by a neutral submission note indicating that the final public repository URL should be inserted later.
