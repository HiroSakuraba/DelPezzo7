# External audits

This repository includes external-style audits that are useful for confidence checks but are not primary proof dependencies unless explicitly cited in the paper.

## Aristotle audit of paper draft v7

Location: `audits/aristotle_v7/`

Summary:
- the audit judged the main theorem and overall proof chain correct;
- it verified the discrepancy table, basket arithmetic, mixed-basket polarization arithmetic, grouped Bezout contradictions, and the degree-1 `8A1` node-bound chain;
- it identified one local correction: the root counts in the two exotic chain cases should be recorded as `48` and `32`, with maximal pairwise orthogonal size `4` in each case, rather than the older `30`/`30` and `3`/`3` values.

That correction is incorporated in `paper/N_le_7_char3_paper_draft_v8.tex` and its PDF.
