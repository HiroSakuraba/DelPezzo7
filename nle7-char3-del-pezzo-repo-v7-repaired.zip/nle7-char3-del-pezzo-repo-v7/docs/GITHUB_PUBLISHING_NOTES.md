# GitHub publishing notes

1. Create a new GitHub repository named `nle7-char3-del-pezzo`.
2. Upload the contents of this directory.
3. Set the first release tag to `v1.0.0-paper-submission`.
4. The paper appendix should use the public GitHub URL `https://github.com/HiroSakuraba/DelPezzo7`.
5. Optionally archive the release to Zenodo and add the DOI to both the paper and `CITATION.cff`.


## Recommended additional files for publication
- `docs/AI_AGENT_ENTRYPOINT.md`
- `docs/HISTORICAL_NO_GO_LEDGER.md`
- `docs/EXPLORATORY_MAP.md`

These make the repository more legible to future AI agents and prevent confusion between load-bearing proof files and historical exploratory branches.
