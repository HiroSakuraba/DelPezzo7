# Historical documents index

This note indexes older documents that are useful for provenance, AI-agent continuity, and understanding abandoned or superseded search lanes.

## Status rule
These documents are **not** part of the logical core of the final theorem unless the paper explicitly cites them. They are preserved because they contain useful search infrastructure, explanatory framing, or early versions of arguments that later evolved into the corrected proof chain.

## Documents

### `exploratory/historical_documents/older_drafts/incidence_defect_bound_proof.docx`
Role:
- coding-theoretic / matroid-style exposition of the cubic incidence-defect idea,
- useful for understanding how the project previously framed combinatorial obstructions.

Use with caution:
- good explanatory value,
- not a load-bearing theorem source,
- some claims in that draft are presented more strongly than the computational scope later justified.

### `exploratory/historical_documents/older_drafts/singular_delpez_char3.docx`
Role:
- broad earlier computational program mixing cubic and quartic ambient searches,
- useful for understanding how quartic/K3-type sandbox branches were explored.

Use with caution:
- not part of the final rank-one del Pezzo proof,
- contains exploratory candidate language rather than final theorem-level closure.

### `exploratory/historical_documents/older_drafts/singular_surfaces_char3_v2.docx`
Role:
- cleaner and more explicit historical version of the broad computational program,
- useful for seeing which quartic results were evidence only and which ideas survived.

Use with caution:
- still historical and exploratory,
- should not be cited as theorem support for the final paper.

### `exploratory/historical_documents/older_drafts/char3_search_handoff_paper.docx`
Role:
- AI-agent handoff on search lanes, tool stack, and strategy changes,
- especially useful for future agents who need to understand why the quartic and CI(2,2) lanes were treated differently.

Use with caution:
- handoff note only,
- not a theorem document.

## Recommended use for future AI agents
1. Read `docs/AI_AGENT_ENTRYPOINT.md` first.
2. Read `docs/HISTORICAL_NO_GO_LEDGER.md` second.
3. Use the documents in this folder only after understanding which branches are final, exploratory, or superseded.
4. Treat these files as provenance and search-memory, not as automatic proof dependencies.
