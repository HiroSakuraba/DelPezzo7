# Exploratory map

This repository intentionally keeps several older branches for clarity.

## v30 Picard-merge / ambient-deformation lane
Use this if you want to understand the high-dimensional search stack and the structural tools (including matroid/circuit screens) that helped triage candidates.

## v50 quasi-elliptic global probe
Use this if you want to see how the ambient and quasi-elliptic branches evolved before the blowup-lattice proof chain became dominant.

## v20 wild alpha3 / Artin-Schreier lane
Use this if you want the best compact explanation of why characteristic-3 additive-action constructions were investigated and what killed the most obvious versions.


## Historical draft documents
Use this if you want older narrative documents, search handoffs, and earlier expository papers that explain how the project's search language evolved. See `docs/HISTORICAL_DOCUMENTS_INDEX.md`.
