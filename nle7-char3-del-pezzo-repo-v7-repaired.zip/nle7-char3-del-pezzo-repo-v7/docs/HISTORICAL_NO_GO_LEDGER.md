# Historical no-go ledger

This note separates three kinds of branches:
1. branches that are fully closed and part of the final proof architecture,
2. branches that are genuinely closed but are not needed in the final paper,
3. branches that were useful search lanes but were later superseded.

## Closed and used in the final proof
- Exotic `7A_1 +` one-point baskets: closed globally.
- Mixed basket: closed via polarization reduction, global normalization, grouped orbit reduction, and tangent-contact argument.
- Pure `8A_1`: closed via the global degree-1 weak del Pezzo anticanonical model and branch-node bound.

## Closed but not load-bearing in the final theorem
- Explicit nonsplit torsor family: non-klt / simple elliptic.
- Semisplit `I_0^* + I_0^*` quotient: `8A_1` but Picard rank 2 with `(-K)^2 = 0`.
- Smooth rational involution and smooth/singular double-cover lanes checked in the v68--v73 range.
- Wild/additive local and ambient linear lanes summarized in `exploratory/wild_alpha3/v20/`.

## Historically useful but superseded
- Early basket filters before the corrected odd-lattice bilinear screen.
- Finite-family mixed-basket witnesses later shown reducible.
- Ambient/deformation search lanes recorded in `dual_track_handoff_v30.md` and the v30/v50 directories.

## Rule for future readers
If a file predates the corrected final chain and the paper does not cite it, treat it as historical context, not theorem support.


## Historical documents preserved for provenance
The folder `exploratory/historical_documents/older_drafts/` stores older papers and handoff notes that are useful for context and future agents. They may contain exploratory claims, superseded framings, or broader ambient-search discussion. Always cross-check them against the corrected final chain before reusing any statement.
