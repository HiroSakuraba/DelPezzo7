# KLT del Pezzo progress v20

This round pushed the nonlinear wild `alpha_3` lane past the split-product model and into a **systematic local normal-form search**.

## New module

- `wild_alpha3_local_search.py`

It enumerates all homogeneous quadratic local vector fields
\[
D = P_2(x,y)\,\partial_x + Q_2(x,y)\,\partial_y
\]
over \(\mathbf F_3\), checks the nilpotence condition \(D^3=0\), keeps only the models with an **isolated** zero at the origin, and computes the fixed-point pattern after the first equivariant blow-up.

## Main scouting results

Counts:
- total homogeneous quadratic pairs: `728`
- nilpotent pairs with \(D^3=0\): `112`
- nilpotent pairs with isolated zero at the origin: `48`

Blow-up behavior:
- maximum number of exceptional fixed points after one blow-up: `4`
- number of models attaining this maximum: `18`
- every exceptional fixed point in every isolated quadratic nilpotent model is **reduced** (nonzero linear part)

So the nonlinear wild lane is stronger than the earlier prototype `x^2 ∂_x + y^2 ∂_y`: the best quadratic local models branch to **4** exceptional fixed points rather than 3.

But the search also shows a sharp limitation:
- no exceptional fixed point remains quadratic-nilpotent,
- so there is **no automatic recursive branching** from iterating the same local quadratic model.

## Interpretation

This keeps the wild lane alive, but in a more constrained way than a naive local tree-growth heuristic suggested.

A successful wild construction now likely requires **global geometry**:
- a blown-up rational surface with several nilpotent zeros interacting,
- or a genuinely nonlinear additive vector field that is not determined by a single repeated local quadratic normal form.

## Best next move

Build a **global alpha_3 surface scout** on rational blow-ups with several local nilpotent charts glued by explicit birational transition rules, rather than continuing purely local blow-up iteration.
