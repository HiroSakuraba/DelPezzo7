# Handoff v30: deformation-first branch after the tool update

## Closed or reduced branches

### 1. `P(1,1,4)` deformation-first branch
Use the recent literature statement:
- if `X` is a deformation from `P(1,1,4)`, then the only singularity of `X` is a deformation of `1/4(1,1)`;
- that singularity has a 1-dimensional Q-Gorenstein miniversal deformation space, so it cannot be partially smoothed;
- therefore such an `X` is either `P^2` or `P(1,1,4)`.

Operational consequence: this branch is closed for any `N>1` singularity search.

### 2. Natural `P(1,3,5)` sextic branch in characteristic 3
The recorded Veronese embedding
`P(1,3,5) -> P(1,1,2,5)` with image `xw=z^3` suggests the sextic family
`xw=Q_6(x,y,z)`.

In characteristic `3`, every singular point of such a sextic lies on `x=0`, and the `x=0` singular equations reduce to
`q_y = y z (b y^2 + 2 c z)`,
`q_z = y^2 (b y^2 + 2 c z)`.

So there are at most 3 projective singular points in the isolated case.

Operational consequence: the natural sextic `P(1,3,5)` branch is count-closed for the `N>7` target.

## Still live

### `P(1,2,3)` deformation-first branch
This is now the next clean ambient to test.

Reason:
- `P(1,1,4)` is closed by a direct deformation-rigidity statement;
- the first natural `P(1,3,5)` family is count-closed in characteristic `3`;
- `P(1,2,3)` remains the smallest direct toric rank-1 ambient not yet cut down by the same mechanism.

## Suggested next move

Build a characteristic-3-specific deformation ansatz for `P(1,2,3)` and derive a singular-count bound analogous to the `P(1,3,5)` note.
