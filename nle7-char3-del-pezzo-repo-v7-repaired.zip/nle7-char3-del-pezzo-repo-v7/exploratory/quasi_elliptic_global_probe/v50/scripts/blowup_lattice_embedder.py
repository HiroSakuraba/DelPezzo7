from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json
from typing import Any, Iterable


@dataclass(frozen=True)
class CurveClass:
    coeffs: tuple[int, ...]  # coefficients on E_1,...,E_n in a pure blowup basis

    def square(self) -> int:
        return -sum(c * c for c in self.coeffs)

    def intersection(self, other: 'CurveClass') -> int:
        return -sum(a * b for a, b in zip(self.coeffs, other.coeffs))

    def text(self) -> str:
        parts: list[str] = []
        for i, c in enumerate(self.coeffs, start=1):
            if c == 0:
                continue
            sign = '+' if c > 0 else '-'
            mag = abs(c)
            term = f"E{i}" if mag == 1 else f"{mag}E{i}"
            if not parts:
                parts.append(term if c > 0 else f"-{term}")
            else:
                parts.append(f" {sign} {term}")
        return ''.join(parts) if parts else '0'

    def to_dict(self) -> dict[str, Any]:
        return {
            'coeffs': list(self.coeffs),
            'square': self.square(),
            'text': self.text(),
        }


def formal_chain_blowups(chain: Iterable[int]) -> int:
    t = tuple(int(x) for x in chain)
    if not t:
        return 0
    return sum(t) - (len(t) - 1)


def build_rooted_chain_classes(chain: Iterable[int], start_index: int = 1) -> tuple[list[CurveClass], int]:
    """Build a canonical rooted exceptional-chain embedding in a blowup basis.

    For chain [b1,...,bl], produce classes C_i in a pure exceptional basis so that
      C_i^2 = -b_i,
      C_i.C_{i+1} = 1,
      C_i.C_j = 0 for |i-j|>1.

    The model uses formal infinitely-near blowups and is a sufficient local realization
    template, not a proof of minimality.
    """
    b = tuple(int(x) for x in chain)
    if not b:
        return [], start_index
    n = formal_chain_blowups(b)
    coeffs: list[list[int]] = [[0 for _ in range(n)] for _ in range(len(b))]
    # first component
    root = 0
    for j in range(b[0]):
        coeffs[0][j] = 1 if j == 0 else -1
    pivot = b[0] - 1
    next_free = b[0]
    # subsequent components reuse the previous pivot and add b_i-1 new blowups
    for i in range(1, len(b)):
        coeffs[i][pivot] = 1
        for k in range(b[i] - 1):
            coeffs[i][next_free + k] = -1
        pivot = next_free + (b[i] - 2) if b[i] >= 2 else pivot
        next_free += b[i] - 1
    # pad to global basis start_index..end_index
    out: list[CurveClass] = []
    total_dim = start_index - 1 + n
    for row in coeffs:
        full = [0] * (start_index - 1) + row
        out.append(CurveClass(tuple(full)))
    return out, start_index + n


def _pad(curves: list[CurveClass], dim: int) -> list[CurveClass]:
    out: list[CurveClass] = []
    for c in curves:
        coeffs = list(c.coeffs)
        if len(coeffs) < dim:
            coeffs.extend([0] * (dim - len(coeffs)))
        out.append(CurveClass(tuple(coeffs)))
    return out


def verify_chain_intersection(curves: list[CurveClass], chain: Iterable[int]) -> dict[str, Any]:
    t = tuple(int(x) for x in chain)
    n = len(curves)
    matrix = [[curves[i].intersection(curves[j]) for j in range(n)] for i in range(n)]
    expected = [[0 for _ in range(n)] for _ in range(n)]
    for i, b in enumerate(t):
        expected[i][i] = -b
        if i > 0:
            expected[i][i - 1] = expected[i - 1][i] = 1
    return {
        'ok': matrix == expected,
        'matrix': matrix,
        'expected': expected,
    }


def _block_multiplicity(block: dict[str, Any]) -> int:
    return 2 if block.get('orbit_kind') == 'pair' else 1


def embed_plan_rooted(plan: dict[str, Any]) -> dict[str, Any]:
    blocks = plan.get('toric_blocks') or plan.get('chart_choices') or plan.get('blocks') or []
    next_idx = 1
    orbit_embeddings: list[dict[str, Any]] = []
    total_blowups = 0
    total_rank = 0
    total_extra = 0
    geometric_components: list[CurveClass] = []

    for block in blocks:
        chain_src = block.get('hj_chain') or block.get('chain') or (block.get('toric_model') or {}).get('chain') or []
        chain = tuple(int(x) for x in chain_src)
        sing_type = block.get('singularity_type', 'unknown')
        mult = _block_multiplicity(block)
        local_embeddings: list[dict[str, Any]] = []
        for copy in range(mult):
            curves, next_idx = build_rooted_chain_classes(chain, start_index=next_idx)
            local_blowups = formal_chain_blowups(chain)
            local_rank = len(chain)
            total_blowups += local_blowups
            total_rank += local_rank
            total_extra += local_blowups - local_rank
            geometric_components.extend(curves)
            ver = verify_chain_intersection(curves, chain)
            local_embeddings.append({
                'copy_index': copy,
                'curve_classes': [c.to_dict() for c in curves],
                'blowups_used': local_blowups,
                'rank': local_rank,
                'extra_blowups': local_blowups - local_rank,
                'verification': ver,
            })
        orbit_embeddings.append({
            'orbit_kind': block.get('orbit_kind', 'fixed'),
            'orbit_index': int(block.get('orbit_index', len(orbit_embeddings))),
            'singularity_type': sing_type,
            'hj_chain': list(chain),
            'orbit_singularity_count': mult,
            'orbit_rank_geometric': mult * len(chain),
            'orbit_blowups_geometric': mult * formal_chain_blowups(chain),
            'orbit_extra_geometric': mult * (formal_chain_blowups(chain) - len(chain)),
            'point': block.get('point'),
            'conjugate_point': block.get('conjugate_point'),
            'local_embeddings': local_embeddings,
        })

    geom_dim = total_blowups
    geometric_components = _pad(geometric_components, geom_dim)
    exc_matrix = [[geometric_components[i].intersection(geometric_components[j]) for j in range(len(geometric_components))] for i in range(len(geometric_components))]

    rho_y_rooted = 1 + total_blowups
    rho_x_contract_only = rho_y_rooted - total_rank
    k_y_sq_rooted = 9 - total_blowups

    out = dict(plan)
    out.update({
        'rooted_embedding_success': True,
        'rooted_total_blowups': total_blowups,
        'rooted_total_rank_geometric': total_rank,
        'rooted_total_extra_blowups': total_extra,
        'rho_y_rooted': rho_y_rooted,
        'rho_x_contract_only_rooted': rho_x_contract_only,
        'k_y_sq_rooted': k_y_sq_rooted,
        'supports_rho1_rooted_model': rho_x_contract_only == 1,
        'orbit_embeddings': orbit_embeddings,
        'rooted_exceptional_matrix': exc_matrix,
        'rooted_caveat': 'rooted pure-exceptional embedding; sufficient local blowup model, not a minimality proof',
    })
    return out


def embed_report(report: dict[str, Any]) -> dict[str, Any]:
    plans = [embed_plan_rooted(p) for p in report.get('plans', [])]
    success = sum(1 for p in plans if p.get('rooted_embedding_success'))
    min_rho_x = min((p.get('rho_x_contract_only_rooted', 10**9) for p in plans), default=None)
    best = sorted(plans, key=lambda p: (p.get('rho_x_contract_only_rooted', 10**9), -p.get('skeleton', {}).get('total_singularities', 0), p.get('rooted_total_blowups', 10**9)))
    return {
        'characteristic': report.get('characteristic'),
        'tame_only': report.get('tame_only'),
        'descent_strict': report.get('descent_strict'),
        'input_plan_count': len(report.get('plans', [])),
        'embedded_plan_count': success,
        'min_rho_x_contract_only_rooted': min_rho_x,
        'plans': plans,
        'best_by_rooted_rho_x': best[:15],
    }


def render_markdown(report: dict[str, Any]) -> str:
    lines: list[str] = []
    lines.append('# Blow-up lattice embedding scan')
    lines.append('')
    lines.append(f"- characteristic: {report.get('characteristic')}")
    lines.append(f"- input plans: {report.get('input_plan_count')}")
    lines.append(f"- embedded plans: {report.get('embedded_plan_count')}")
    lines.append(f"- minimum rooted rho(X) after contracting only planned chains: {report.get('min_rho_x_contract_only_rooted')}")
    lines.append('')
    lines.append('## Best plans by rooted rho(X)')
    lines.append('')
    for i, p in enumerate(report.get('best_by_rooted_rho_x', [])[:15], start=1):
        sk = p.get('skeleton', {})
        lines.append(
            f"{i}. total={sk.get('total_singularities')} (fixed={sk.get('fixed_count')}, pairs={sk.get('pair_count')}), "
            f"types fixed={p.get('fixed_types') or ['—']}, pairs={p.get('pair_types') or ['—']}"
        )
        lines.append(
            f"   - v36 rank={p.get('total_rank')}, rooted blowups={p.get('rooted_total_blowups')}, "
            f"rooted rho(Y)={p.get('rho_y_rooted')}, rooted rho(X)_contract_only={p.get('rho_x_contract_only_rooted')}, rooted K_Y^2={p.get('k_y_sq_rooted')}"
        )
        lines.append(f"   - rho=1 in rooted model? {p.get('supports_rho1_rooted_model')}")
        lines.append(f"   - caveat: {p.get('rooted_caveat')}")
    lines.append('')
    return '\n'.join(lines) + '\n'


def write_report(base_path: str | Path, report: dict[str, Any]) -> tuple[Path, Path]:
    base = Path(base_path)
    json_path = base.with_suffix('.json')
    md_path = base.with_suffix('.md')
    json_path.write_text(json.dumps(report, indent=2), encoding='utf-8')
    md_path.write_text(render_markdown(report), encoding='utf-8')
    return json_path, md_path
