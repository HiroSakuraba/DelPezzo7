"""
frobenius_shadow.py — Frobenius-shadow budget heuristics for char 3.

This module supplements the existing trace-based Picard estimator. It does not
prove rho=1, but it helps distinguish two cases:
  (1) rho inflation that looks structurally hopeless, and
  (2) rho inflation that might plausibly be absorbed by wild A_{3k-1}-type data.
"""
from __future__ import annotations

from typing import Dict, List


def frobenius_eigenvalue_analysis(point_counts: Dict[int, int], b2_max: int = 7) -> dict:
    traces = {n: count - 1 - (3 ** n) ** 2 for n, count in point_counts.items()}
    result = {"traces": traces, "n_traces": len(traces)}
    if 1 in traces:
        result["e1"] = traces[1]
    if 1 in traces and 2 in traces:
        s1, s2 = traces[1], traces[2]
        e2_num = s1 * s1 - s2
        if e2_num % 2 == 0:
            result["e2"] = e2_num // 2
        else:
            result["e2"] = None
            result["e2_warning"] = f"s1^2-s2={e2_num} is odd."
        rho_plus = round((s2 / 9 + s1 / 3) / 2)
        rho_minus = round((s2 / 9 - s1 / 3) / 2)
        result["rho_plus_estimate"] = rho_plus
        result["rho_minus_estimate"] = rho_minus
        result["rho_total_estimate"] = abs(rho_plus) + abs(rho_minus)
    if 1 in traces and 2 in traces and 3 in traces and result.get("e2") is not None:
        s1, s2, s3 = traces[1], traces[2], traces[3]
        predicted_s3 = s1 * s2 - result["e2"] * s1
        result["s3_check"] = {"predicted": predicted_s3, "actual": s3, "consistent": predicted_s3 == s3}
        discrepancy = s3 - predicted_s3
        if discrepancy % 3 == 0:
            result["e3"] = discrepancy // 3
    return result



def wild_deficiency_analysis(singularity_classifications: List[dict]) -> dict:
    tame_curves = 0
    wild_curves = 0
    wild_shadow_min = 0
    wild_shadow_max = 0
    wild_count = 0
    tame_count = 0
    for cl in singularity_classifications:
        stype = cl.get("type", "UNKNOWN")
        milnor = cl.get("milnor")
        if stype.startswith("A_"):
            try:
                n = int(stype.split("_")[1])
            except Exception:
                n = milnor if milnor else 1
            if (n + 1) % 3 == 0:
                wild_count += 1
                wild_curves += n
                k = (n + 1) // 3
                wild_shadow_max += k
            else:
                tame_count += 1
                tame_curves += n
        elif stype.startswith("D_"):
            try:
                n = int(stype.split("_")[1])
            except Exception:
                n = milnor if milnor else 4
            tame_count += 1
            tame_curves += n
        elif stype in ("RANK0_DEGENERATE", "HIGH_MILNOR_OR_NON_ISOLATED", "RANK1_UNKNOWN"):
            wild_count += 1
            est_curves = milnor if milnor and milnor > 0 else 3
            wild_curves += est_curves
            wild_shadow_max += est_curves
        elif stype == "A_1":
            tame_count += 1
            tame_curves += 1
    return {
        "tame_count": tame_count,
        "wild_count": wild_count,
        "tame_curves": tame_curves,
        "wild_curves": wild_curves,
        "total_curves": tame_curves + wild_curves,
        "shadow_budget_min": wild_shadow_min,
        "shadow_budget_max": wild_shadow_max,
        "notes": [
            f"{tame_count} tame singularities contributing {tame_curves} definite Picard classes",
            f"{wild_count} wild singularities contributing {wild_curves} curves, of which {wild_shadow_min}-{wild_shadow_max} might lie in the Frobenius shadow",
        ],
    }



def shadow_budget_report(point_counts: Dict[int, int], singularity_classifications: List[dict], b2_max: int = 7) -> dict:
    eigen = frobenius_eigenvalue_analysis(point_counts, b2_max=b2_max)
    wild = wild_deficiency_analysis(singularity_classifications)
    rho_naive = 1 + wild["total_curves"]
    rho_achievable = max(1, rho_naive - wild["shadow_budget_max"])
    rho_trace = eigen.get("rho_total_estimate")
    consistent = True
    notes = list(wild["notes"])
    if rho_trace is not None:
        if rho_trace < rho_achievable:
            notes.append(
                f"Trace-based rho={rho_trace} is below the shadow-achievable rho={rho_achievable}; there may be extra structure beyond the coarse type budget."
            )
        elif rho_trace > rho_naive:
            notes.append(
                f"Trace-based rho={rho_trace} exceeds naive rho={rho_naive}; this usually signals degeneracy or unreliable traces."
            )
            consistent = False
    return {
        "frobenius_analysis": eigen,
        "wild_analysis": wild,
        "rho_naive": rho_naive,
        "rho_achievable": rho_achievable,
        "rho_from_traces": rho_trace,
        "consistent": consistent,
        "could_achieve_rho_1": rho_achievable <= 1,
        "notes": notes,
    }
