# Star-fiber / quasi-elliptic tail basket scan

This is a genuinely different geometry from the ruled/disjoint-cluster model. Instead of arbitrary quotient baskets, it scans **singularity baskets obtained by contracting tails of star-shaped genus-one / quasi-elliptic fiber graphs** with a retained central core component.

- max_fibers: 4
- min_total_singularities: 8
- plan_count: 56
- minimum primitive rho(X) lower bound: 3
- minimum fiber-core rho(X): 5

## Best plans by primitive lower bound

1. fibers=['II*_A1A2A4', 'II*_A1A2A4', 'II*_A1A2A4'], total_singularities=9, tails=['A1', 'A2', 'A4', 'A1', 'A2', 'A4', 'A1', 'A2', 'A4']
   - rank=21, discr_len=3, snf=[30, 30, 30]
   - primitive n_lb=23, primitive rho_lb=3
   - fiber-core raw n=24, clamped n=24, fiber-core rho=5, gap=1, undercut? False
2. fibers=['III*_A1A2A3', 'II*_A1A2A4', 'II*_A1A2A4'], total_singularities=9, tails=['A1', 'A2', 'A3', 'A1', 'A2', 'A4', 'A1', 'A2', 'A4']
   - rank=20, discr_len=4, snf=[2, 6, 30, 60]
   - primitive n_lb=23, primitive rho_lb=4
   - fiber-core raw n=23, clamped n=23, fiber-core rho=5, gap=0, undercut? False
3. fibers=['II*_A1A2A4', 'II*_A1A2A4', 'II*_A1A2A4', 'II*_A1A2A4'], total_singularities=12, tails=['A1', 'A2', 'A4', 'A1', 'A2', 'A4', 'A1', 'A2', 'A4', 'A1', 'A2', 'A4']
   - rank=28, discr_len=4, snf=[30, 30, 30, 30]
   - primitive n_lb=31, primitive rho_lb=4
   - fiber-core raw n=32, clamped n=32, fiber-core rho=6, gap=1, undercut? False
4. fibers=['I0*_A1x4', 'IV*_A2x3', 'II*_A1A2A4'], total_singularities=10, tails=['A1', 'A1', 'A1', 'A1', 'A2', 'A2', 'A2', 'A1', 'A2', 'A4']
   - rank=17, discr_len=5, snf=[2, 6, 6, 6, 30]
   - primitive n_lb=21, primitive rho_lb=5
   - fiber-core raw n=20, clamped n=21, fiber-core rho=6, gap=0, undercut? True
5. fibers=['IV*_A2x3', 'III*_A1A2A3', 'III*_A1A2A3'], total_singularities=9, tails=['A2', 'A2', 'A2', 'A1', 'A2', 'A3', 'A1', 'A2', 'A3']
   - rank=18, discr_len=5, snf=[3, 6, 6, 12, 12]
   - primitive n_lb=22, primitive rho_lb=5
   - fiber-core raw n=21, clamped n=22, fiber-core rho=6, gap=0, undercut? True
6. fibers=['IV*_A2x3', 'III*_A1A2A3', 'II*_A1A2A4'], total_singularities=9, tails=['A2', 'A2', 'A2', 'A1', 'A2', 'A3', 'A1', 'A2', 'A4']
   - rank=19, discr_len=5, snf=[3, 3, 6, 6, 60]
   - primitive n_lb=23, primitive rho_lb=5
   - fiber-core raw n=22, clamped n=23, fiber-core rho=6, gap=0, undercut? True
7. fibers=['III*_A1A2A3', 'III*_A1A2A3', 'II*_A1A2A4'], total_singularities=9, tails=['A1', 'A2', 'A3', 'A1', 'A2', 'A3', 'A1', 'A2', 'A4']
   - rank=19, discr_len=5, snf=[2, 2, 6, 12, 60]
   - primitive n_lb=23, primitive rho_lb=5
   - fiber-core raw n=22, clamped n=23, fiber-core rho=6, gap=0, undercut? True
8. fibers=['IV*_A2x3', 'II*_A1A2A4', 'II*_A1A2A4'], total_singularities=9, tails=['A2', 'A2', 'A2', 'A1', 'A2', 'A4', 'A1', 'A2', 'A4']
   - rank=20, discr_len=5, snf=[3, 3, 3, 30, 30]
   - primitive n_lb=24, primitive rho_lb=5
   - fiber-core raw n=23, clamped n=24, fiber-core rho=6, gap=0, undercut? True
9. fibers=['III*_A1A2A3', 'II*_A1A2A4', 'II*_A1A2A4', 'II*_A1A2A4'], total_singularities=12, tails=['A1', 'A2', 'A3', 'A1', 'A2', 'A4', 'A1', 'A2', 'A4', 'A1', 'A2', 'A4']
   - rank=27, discr_len=5, snf=[2, 6, 30, 30, 60]
   - primitive n_lb=31, primitive rho_lb=5
   - fiber-core raw n=31, clamped n=31, fiber-core rho=6, gap=0, undercut? False
10. fibers=['I0*_A1x4', 'IV*_A2x3', 'IV*_A2x3'], total_singularities=10, tails=['A1', 'A1', 'A1', 'A1', 'A2', 'A2', 'A2', 'A2', 'A2', 'A2']
   - rank=16, discr_len=6, snf=[3, 3, 6, 6, 6, 6]
   - primitive n_lb=21, primitive rho_lb=6
   - fiber-core raw n=19, clamped n=21, fiber-core rho=7, gap=0, undercut? True
11. fibers=['I0*_A1x4', 'IV*_A2x3', 'III*_A1A2A3'], total_singularities=10, tails=['A1', 'A1', 'A1', 'A1', 'A2', 'A2', 'A2', 'A1', 'A2', 'A3']
   - rank=16, discr_len=6, snf=[2, 2, 6, 6, 6, 12]
   - primitive n_lb=21, primitive rho_lb=6
   - fiber-core raw n=19, clamped n=21, fiber-core rho=7, gap=0, undercut? True
12. fibers=['I0*_A1x4', 'II*_A1A2A4', 'II*_A1A2A4'], total_singularities=10, tails=['A1', 'A1', 'A1', 'A1', 'A1', 'A2', 'A4', 'A1', 'A2', 'A4']
   - rank=18, discr_len=6, snf=[2, 2, 2, 2, 30, 30]
   - primitive n_lb=23, primitive rho_lb=6
   - fiber-core raw n=21, clamped n=23, fiber-core rho=7, gap=0, undercut? True
13. fibers=['III*_A1A2A3', 'III*_A1A2A3', 'III*_A1A2A3'], total_singularities=9, tails=['A1', 'A2', 'A3', 'A1', 'A2', 'A3', 'A1', 'A2', 'A3']
   - rank=18, discr_len=6, snf=[2, 2, 2, 12, 12, 12]
   - primitive n_lb=23, primitive rho_lb=6
   - fiber-core raw n=21, clamped n=23, fiber-core rho=7, gap=0, undercut? True
14. fibers=['I0*_A1x4', 'IV*_A2x3', 'II*_A1A2A4', 'II*_A1A2A4'], total_singularities=13, tails=['A1', 'A1', 'A1', 'A1', 'A2', 'A2', 'A2', 'A1', 'A2', 'A4', 'A1', 'A2', 'A4']
   - rank=24, discr_len=6, snf=[2, 6, 6, 6, 30, 30]
   - primitive n_lb=29, primitive rho_lb=6
   - fiber-core raw n=28, clamped n=29, fiber-core rho=7, gap=0, undercut? True
15. fibers=['IV*_A2x3', 'III*_A1A2A3', 'III*_A1A2A3', 'III*_A1A2A3'], total_singularities=12, tails=['A2', 'A2', 'A2', 'A1', 'A2', 'A3', 'A1', 'A2', 'A3', 'A1', 'A2', 'A3']
   - rank=24, discr_len=6, snf=[6, 6, 6, 12, 12, 12]
   - primitive n_lb=29, primitive rho_lb=6
   - fiber-core raw n=28, clamped n=29, fiber-core rho=7, gap=0, undercut? True

## Conclusion

If these star-fiber baskets beat the low-discriminant ruled baskets on primitive lower bound and realistic fiber-core cost, that is direct evidence that the next geometry should be genus-one / quasi-elliptic rather than another ruled-surface variant.

