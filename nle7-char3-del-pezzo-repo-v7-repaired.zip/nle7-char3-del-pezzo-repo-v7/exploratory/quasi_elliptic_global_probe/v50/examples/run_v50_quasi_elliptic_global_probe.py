from pathlib import Path
from scripts.quasi_elliptic_global_probe import run_quasi_elliptic_global_probe, write_report

if __name__ == '__main__':
    report = run_quasi_elliptic_global_probe()
    base = Path('quasi_elliptic_global_probe_v50')
    json_path, md_path = write_report(base, report)
    print(json_path)
    print(md_path)
