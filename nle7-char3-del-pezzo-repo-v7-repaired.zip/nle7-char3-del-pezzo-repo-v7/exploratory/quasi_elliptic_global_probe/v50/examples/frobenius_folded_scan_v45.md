# Frobenius-folded ruled compression scan

This extends the v44 ruled-corner model with a highly optimistic symmetry-compression probe: Frobenius pair blocks are charged once at the orbit level, plus small descent bookkeeping charges. The purpose is to test whether pair symmetry could in principle explain away the remaining blowup/Picard gap.

- selected_basket_count: 8
- plan_count: 8
- frobenius_folded_success_count: 8
- minimum folded contract-only rho(X): 7

## Best plans by folded rho(X)

1. total=8 (fixed=0, pairs=4), ell=2, primitive rho_lb=2, folded rho=7
   - rooted n=40, ruled-corner n=32, folded n=17, folded savings vs ruled=15, folded savings vs rooted=23
   - primitive n_lb=13, folded gap=4, descent charge=1, bridge charge=0
   - fixed types: ['—']
   - pair types: ['1/4(1,1)', '1/5(1,1)', '1/7(1,2)', '1/11(1,3)']
2. total=10 (fixed=0, pairs=5), ell=4, primitive rho_lb=4, folded rho=10
   - rooted n=48, ruled-corner n=38, folded n=20, folded savings vs ruled=18, folded savings vs rooted=28
   - primitive n_lb=15, folded gap=5, descent charge=1, bridge charge=0
   - fixed types: ['—']
   - pair types: ['1/4(1,1)', '1/4(1,1)', '1/5(1,1)', '1/5(1,1)', '1/11(1,3)']
3. total=8 (fixed=2, pairs=3), ell=2, primitive rho_lb=2, folded rho=11
   - rooted n=40, ruled-corner n=32, folded n=21, folded savings vs ruled=11, folded savings vs rooted=19
   - primitive n_lb=13, folded gap=8, descent charge=1, bridge charge=1
   - fixed types: ['1/4(1,1)', '1/4(1,1)']
   - pair types: ['1/5(1,1)', '1/7(1,2)', '1/11(1,3)']
4. total=9 (fixed=1, pairs=4), ell=3, primitive rho_lb=3, folded rho=11
   - rooted n=45, ruled-corner n=36, folded n=22, folded savings vs ruled=14, folded savings vs rooted=23
   - primitive n_lb=15, folded gap=7, descent charge=1, bridge charge=1
   - fixed types: ['1/5(1,1)']
   - pair types: ['1/4(1,1)', '1/5(1,1)', '1/7(1,2)', '1/11(1,3)']
5. total=12 (fixed=0, pairs=6), ell=4, primitive rho_lb=4, folded rho=11
   - rooted n=60, ruled-corner n=48, folded n=25, folded savings vs ruled=23, folded savings vs rooted=35
   - primitive n_lb=19, folded gap=6, descent charge=1, bridge charge=0
   - fixed types: ['—']
   - pair types: ['1/4(1,1)', '1/4(1,1)', '1/5(1,1)', '1/5(1,1)', '1/11(1,3)', '1/11(1,3)']
6. total=10 (fixed=2, pairs=4), ell=3, primitive rho_lb=3, folded rho=13
   - rooted n=49, ruled-corner n=39, folded n=25, folded savings vs ruled=14, folded savings vs rooted=24
   - primitive n_lb=16, folded gap=9, descent charge=1, bridge charge=1
   - fixed types: ['1/4(1,1)', '1/5(1,1)']
   - pair types: ['1/4(1,1)', '1/5(1,1)', '1/7(1,2)', '1/11(1,3)']
7. total=11 (fixed=1, pairs=5), ell=4, primitive rho_lb=4, folded rho=14
   - rooted n=54, ruled-corner n=43, folded n=26, folded savings vs ruled=17, folded savings vs rooted=28
   - primitive n_lb=17, folded gap=9, descent charge=1, bridge charge=1
   - fixed types: ['1/11(1,3)']
   - pair types: ['1/4(1,1)', '1/4(1,1)', '1/5(1,1)', '1/5(1,1)', '1/11(1,3)']
8. total=12 (fixed=2, pairs=5), ell=4, primitive rho_lb=4, folded rho=15
   - rooted n=60, ruled-corner n=48, folded n=29, folded savings vs ruled=19, folded savings vs rooted=31
   - primitive n_lb=19, folded gap=10, descent charge=1, bridge charge=1
   - fixed types: ['1/4(1,1)', '1/4(1,1)']
   - pair types: ['1/4(1,1)', '1/5(1,1)', '1/5(1,1)', '1/11(1,3)', '1/11(1,3)']

## Conclusion

If even this folded-orbit cost model still stays far from rho(X)=1, then the remaining gap is unlikely to be explained by pair symmetry alone. That would force a substantially different realization mechanism rather than a better accounting of the same ruled geometry.

