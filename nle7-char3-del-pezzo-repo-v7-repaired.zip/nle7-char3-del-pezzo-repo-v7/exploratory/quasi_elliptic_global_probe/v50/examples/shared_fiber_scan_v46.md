# Shared singular-fiber compression scan

This extends the v45 folded-orbit ruled model by allowing orbit blocks to be partitioned into shared singular fibers. Each group gets a common-fiber saving and a proper common-prefix HJ saving. The purpose is to test whether multiple singularities could share more global fiber structure than the plain folded model allows.

- selected_basket_count: 8
- plan_count: 8
- shared_fiber_success_count: 8
- minimum shared-fiber contract-only rho(X): 2

## Best plans by shared-fiber rho(X)

1. total=8 (fixed=0, pairs=4), ell=2, primitive rho_lb=2, shared-fiber rho=2
   - rooted n=40, ruled-corner n=32, folded n=17, shared-fiber n=12
   - savings vs folded=5, vs ruled=20, vs rooted=28, primitive n_lb=13, shared gap=-1
   - fixed types: ['—']
   - pair types: ['1/4(1,1)', '1/5(1,1)', '1/7(1,2)', '1/11(1,3)']
     * group size=2, cost=6, prefix=[], labels=['1/4(1,1)', '1/5(1,1)']
     * group size=2, cost=5, prefix=[4], labels=['1/7(1,2)', '1/11(1,3)']
2. total=12 (fixed=0, pairs=6), ell=4, primitive rho_lb=4, shared-fiber rho=4
   - rooted n=60, ruled-corner n=48, folded n=25, shared-fiber n=18
   - savings vs folded=7, vs ruled=30, vs rooted=42, primitive n_lb=19, shared gap=-1
   - fixed types: ['—']
   - pair types: ['1/4(1,1)', '1/4(1,1)', '1/5(1,1)', '1/5(1,1)', '1/11(1,3)', '1/11(1,3)']
     * group size=4, cost=11, prefix=[], labels=['1/4(1,1)', '1/4(1,1)', '1/5(1,1)', '1/5(1,1)']
     * group size=2, cost=6, prefix=[4], labels=['1/11(1,3)', '1/11(1,3)']
3. total=8 (fixed=2, pairs=3), ell=2, primitive rho_lb=2, shared-fiber rho=5
   - rooted n=40, ruled-corner n=32, folded n=21, shared-fiber n=15
   - savings vs folded=6, vs ruled=17, vs rooted=25, primitive n_lb=13, shared gap=2
   - fixed types: ['1/4(1,1)', '1/4(1,1)']
   - pair types: ['1/5(1,1)', '1/7(1,2)', '1/11(1,3)']
     * group size=3, cost=9, prefix=[], labels=['1/4(1,1)', '1/4(1,1)', '1/5(1,1)']
     * group size=2, cost=5, prefix=[4], labels=['1/7(1,2)', '1/11(1,3)']
4. total=9 (fixed=1, pairs=4), ell=3, primitive rho_lb=3, shared-fiber rho=5
   - rooted n=45, ruled-corner n=36, folded n=22, shared-fiber n=16
   - savings vs folded=6, vs ruled=20, vs rooted=29, primitive n_lb=15, shared gap=1
   - fixed types: ['1/5(1,1)']
   - pair types: ['1/4(1,1)', '1/5(1,1)', '1/7(1,2)', '1/11(1,3)']
     * group size=3, cost=10, prefix=[], labels=['1/5(1,1)', '1/4(1,1)', '1/5(1,1)']
     * group size=2, cost=5, prefix=[4], labels=['1/7(1,2)', '1/11(1,3)']
5. total=10 (fixed=0, pairs=5), ell=4, primitive rho_lb=4, shared-fiber rho=6
   - rooted n=48, ruled-corner n=38, folded n=20, shared-fiber n=16
   - savings vs folded=4, vs ruled=22, vs rooted=32, primitive n_lb=15, shared gap=1
   - fixed types: ['—']
   - pair types: ['1/4(1,1)', '1/4(1,1)', '1/5(1,1)', '1/5(1,1)', '1/11(1,3)']
     * group size=5, cost=15, prefix=[], labels=['1/4(1,1)', '1/4(1,1)', '1/5(1,1)', '1/5(1,1)', '1/11(1,3)']
6. total=10 (fixed=2, pairs=4), ell=3, primitive rho_lb=3, shared-fiber rho=6
   - rooted n=49, ruled-corner n=39, folded n=25, shared-fiber n=18
   - savings vs folded=7, vs ruled=21, vs rooted=31, primitive n_lb=16, shared gap=2
   - fixed types: ['1/4(1,1)', '1/5(1,1)']
   - pair types: ['1/4(1,1)', '1/5(1,1)', '1/7(1,2)', '1/11(1,3)']
     * group size=4, cost=12, prefix=[], labels=['1/4(1,1)', '1/5(1,1)', '1/4(1,1)', '1/5(1,1)']
     * group size=2, cost=5, prefix=[4], labels=['1/7(1,2)', '1/11(1,3)']
7. total=11 (fixed=1, pairs=5), ell=4, primitive rho_lb=4, shared-fiber rho=7
   - rooted n=54, ruled-corner n=43, folded n=26, shared-fiber n=19
   - savings vs folded=7, vs ruled=24, vs rooted=35, primitive n_lb=17, shared gap=2
   - fixed types: ['1/11(1,3)']
   - pair types: ['1/4(1,1)', '1/4(1,1)', '1/5(1,1)', '1/5(1,1)', '1/11(1,3)']
     * group size=4, cost=11, prefix=[], labels=['1/4(1,1)', '1/4(1,1)', '1/5(1,1)', '1/5(1,1)']
     * group size=2, cost=7, prefix=[4], labels=['1/11(1,3)', '1/11(1,3)']
8. total=12 (fixed=2, pairs=5), ell=4, primitive rho_lb=4, shared-fiber rho=7
   - rooted n=60, ruled-corner n=48, folded n=29, shared-fiber n=21
   - savings vs folded=8, vs ruled=27, vs rooted=39, primitive n_lb=19, shared gap=2
   - fixed types: ['1/4(1,1)', '1/4(1,1)']
   - pair types: ['1/4(1,1)', '1/5(1,1)', '1/5(1,1)', '1/11(1,3)', '1/11(1,3)']
     * group size=5, cost=14, prefix=[], labels=['1/4(1,1)', '1/4(1,1)', '1/4(1,1)', '1/5(1,1)', '1/5(1,1)']
     * group size=2, cost=6, prefix=[4], labels=['1/11(1,3)', '1/11(1,3)']

## Conclusion

If even a shared-singular-fiber compression model still stays far from rho(X)=1, then the remaining gap is unlikely to be explained by fiber sharing inside the same ruled geometry. If it gets close to the primitive lower bound, that is evidence that a more global fibered realization mechanism could be the right next direction.

