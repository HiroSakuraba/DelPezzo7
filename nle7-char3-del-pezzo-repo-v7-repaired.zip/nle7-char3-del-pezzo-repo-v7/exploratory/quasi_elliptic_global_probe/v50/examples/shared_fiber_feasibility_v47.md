# Shared-fiber feasibility scan (prefix-disabled)

This takes the v46 shared-fiber grouping and recomputes a conservative cost where **shared HJ-prefix savings are disabled**. Shared exceptional curves would contract to the same singular point, so prefix sharing is not compatible with distinct singularities on a shared central fiber.

- plan_count: 8
- min feasible contract-only rho(X): 5
- total prefix-sharing violations (across all plans): 7

## Best plans by feasible rho(X)

1. total=8 (fixed=0, pairs=4), ell=2, primitive rho_lb=2, feasible rho=5
   - rooted n=40, folded n=17, v46 n=12, feasible n=15
   - feasible gap to primitive n_lb=2, prefix violations=1
2. total=10 (fixed=0, pairs=5), ell=4, primitive rho_lb=4, feasible rho=6
   - rooted n=48, folded n=20, v46 n=16, feasible n=16
   - feasible gap to primitive n_lb=1, prefix violations=0
3. total=12 (fixed=0, pairs=6), ell=4, primitive rho_lb=4, feasible rho=7
   - rooted n=60, folded n=25, v46 n=18, feasible n=21
   - feasible gap to primitive n_lb=2, prefix violations=1
4. total=8 (fixed=2, pairs=3), ell=2, primitive rho_lb=2, feasible rho=8
   - rooted n=40, folded n=21, v46 n=15, feasible n=18
   - feasible gap to primitive n_lb=5, prefix violations=1
5. total=9 (fixed=1, pairs=4), ell=3, primitive rho_lb=3, feasible rho=8
   - rooted n=45, folded n=22, v46 n=16, feasible n=19
   - feasible gap to primitive n_lb=4, prefix violations=1
6. total=10 (fixed=2, pairs=4), ell=3, primitive rho_lb=3, feasible rho=9
   - rooted n=49, folded n=25, v46 n=18, feasible n=21
   - feasible gap to primitive n_lb=5, prefix violations=1
7. total=11 (fixed=1, pairs=5), ell=4, primitive rho_lb=4, feasible rho=10
   - rooted n=54, folded n=26, v46 n=19, feasible n=22
   - feasible gap to primitive n_lb=5, prefix violations=1
8. total=12 (fixed=2, pairs=5), ell=4, primitive rho_lb=4, feasible rho=10
   - rooted n=60, folded n=29, v46 n=21, feasible n=24
   - feasible gap to primitive n_lb=5, prefix violations=1

## Conclusion

If the v46 improvements disappear once prefix sharing is disabled, then the apparent breakthrough was an artifact of over-sharing contracted curves. If feasible rho(X) still drops materially below v45, then central-fiber sharing alone may be a real mechanism worth implementing geometrically.

