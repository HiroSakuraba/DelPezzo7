# KLT del Pezzo Search in Characteristic 3 — No-Go Ledger (v19)

This memo records the branches that are now structurally exhausted, together with the exact obstruction that killed each one. The goal is to prevent reopening dead lanes and to isolate the remaining loopholes.

---

## 1. Smooth-base Artin–Schreier on \(\mathbf P^1 \times \mathbf P^1\)

### Model
We studied covers of the form
\[
Y^3 - H^2 Y - G = 0
\]
on a smooth rational base \(S\), with \(H \in H^0(S,L)\).

### Canonical-class formula
For this model,
\[
K_X = \pi^*(K_S + 2L).
\]
Hence del Pezzo requires
\[
-(K_S + 2L)
\]
to be ample on the base.

### Why \(\mathbf P^1 \times \mathbf P^1\) fails
Write \(L = aF_1 + bF_2\). Then
\[
-K_S - 2L = (2-2a)F_1 + (2-2b)F_2.
\]
Ampleness forces
\[
a < 1, \qquad b < 1.
\]
So no nonzero effective integral class with \(a,b \ge 1\) survives. The high-crossing controlled-pole family therefore lands on the wrong side of the canonical chamber.

### Final verdict
The \(\mathbf P^1 \times \mathbf P^1\) Artin–Schreier controlled-crossing lane is dead as a del Pezzo construction.

---

## 2. Smooth-base Artin–Schreier on \(F_1\)

Let \(S\) be the Hirzebruch surface \(F_1\), with negative section \(S\) and fiber \(F\):
\[
-K_{F_1} = 2S + 3F.
\]
Write
\[
L = aS + bF, \qquad a \ge 0, \quad b \ge a
\]
for an effective divisor class.

Then
\[
-K_{F_1} - 2L = (2-2a)S + (3-2b)F.
\]
A divisor \(xS + yF\) on \(F_1\) is ample iff
\[
x > 0, \qquad y > x.
\]
Applying this to \((2-2a)S + (3-2b)F\) forces
\[
a = 0, \qquad b = 0.
\]
So the only effective \(L\) that survives is the trivial class.

### Final verdict
The naive "swap the base to \(F_1\)" fix is numerically dead in the same Artin–Schreier framework.

---

## 3. Smooth del Pezzo base + reduced SNC controlled-crossing divisor

We ran a global divisor-budget scan over smooth del Pezzo bases for the same Artin–Schreier mechanism.

### Outcome
In the smooth-base, reduced-SNC controlled-crossing framework, the maximum number of crossing-generated singularities is at most
\[
N \le 2.
\]
In fact, the only residual smooth-base case is
\[
S = \mathbf P^2, \qquad L = H,
\]
and then the pole divisor is just a line, so the old crossing mechanism disappears.

### Final verdict
The full smooth del Pezzo Artin–Schreier controlled-crossing program is closed.

---

## 4. Rank-1 toric/log del Pezzo Artin–Schreier bases

We enumerated rank-1 toric/log del Pezzo candidates via weighted projective planes
\[
Y = \mathbf P(a,b,c)
\]
with Cartier generator \(A = \mathcal O_Y(\ell)\),
\[
\ell = \operatorname{lcm}(a,b,c),
\qquad
-K_Y \equiv \frac{a+b+c}{\ell} A.
\]
For a nonzero Cartier class \(L = mA\), ampleness of
\[
-(K_Y + 2L)
\]
forces
\[
\frac{a+b+c}{\ell} > 2m \ge 2,
\]
so
\[
a+b+c > 2\ell.
\]
The only well-formed weighted-projective solution is
\[
(1,1,1),
\]
i.e. \(\mathbf P^2\).

### Residual singularity bound on \(\mathbf P^2\)
With \(L = H\), the standard smooth-pole branch geometry contributes at most
\[
\deg(M|_H) = 2
\]
isolated points.

### Final verdict
The rank-1 toric/log del Pezzo Artin–Schreier lane collapses to \(\mathbf P^2\), and the existing mechanism gives at most 2 isolated singularities there.

---

## 5. Coordinate lane on blow-ups of \(\mathbf P^1 \times \mathbf P^1\): simple points

We exhaustively searched the simple-point lane over \(\mathbf F_3\), \(\mathbf F_9\), and \(\mathbf F_{27}\) for the classes
\[
(1,0),\ (0,1),\ (1,1),\ (1,2),\ (2,1).
\]

### Results
- Over \(\mathbf F_3\), the best clique size is 6.
- Over \(\mathbf F_9\), the entire simple A/B/C lane is closed.
- Adding \((1,2)\) and \((2,1)\) still leaves no 8-curve realization.
- Over \(\mathbf F_{27}\), the unique remaining simple-point survivor orbit is still impossible.

### Final verdict
The full simple-point coordinate lane is closed over the tested characteristic-3 fields.

---

## 6. Infinitely-near / rooted-forest coordinate lane

We pushed beyond simple points through the following cluster types:
- one-step proximity chain,
- two-step chain,
- branched cluster over one point,
- two-center cluster,
- mixed cluster,
- global rooted-forest scan on 7 blow-ups.

### Outcome
The global rooted-forest scan is the strongest statement:
- exactly one forest shape supports an abstract 8-clique,
- it is the all-simple-point forest,
- **no** rooted-forest shape supports an abstract 8-clique containing a genuinely non-simple class.

### Final verdict
Within the 7-point rooted-forest bookkeeping universe, no hidden non-simple 8-clique survives.

---

## 7. First genuine double-point source class

We isolated the first genuinely new abstract class
\[
(2,2;2,1,1,1,1,1,1)
\]
and built its realization engine.

### Uniform obstruction
After \(\mathrm{PGL}_2 \times \mathrm{PGL}_2\) normalization, the realization problem reduces to a 9-by-9 linear system with determinant
\[
d^3 r^5 - d^2 r^5 - d^2 r^3 + d r^3
= d r^3 (d-1)(d r^2 - 1).
\]
The admissibility conditions are
\[
r \neq 0, \qquad d \neq 0, \qquad d \neq 1, \qquad dr^2 \neq 1.
\]
Under those conditions the determinant is nonzero, so the only solution is the zero section.

### Final verdict
There is no such \((2,2)\)-curve over any characteristic-3 field. The first genuine double-point coordinate lane is uniformly closed.

---

## 8. Ambient linear wild quotient lane

We scouted linear order-3 actions on standard del Pezzo ambient models in characteristic 3.

### Outcome
- On cubic surfaces in \(\mathbf P^3\), linear wild \(\mathbf Z/3\)-actions are capped at **3** isolated fixed points.
- On complete intersections \((2,2) \subset \mathbf P^4\), they are capped at **4** isolated fixed points.

### Final verdict
The standard ambient linear wild-quotient lane is too small for the \(>7\) target.

---

## 9. What is still genuinely live

The remaining loopholes are narrower and more explicit now:

1. **Nonlinear wild / additive actions on already blown-up rational surfaces.**
   The ambient linear bounds do not kill this lane.

2. **Singular non-toric bases or stacky / \(\mathbf Q\)-Cartier Artin–Schreier data.**
   The smooth-base and rank-1 toric/base scans are closed, but these more singular top-down variants are not.

3. **A genuinely different characteristic-3 mechanism**, for example quasi-elliptic or purely inseparable constructions not expressible in the rooted-forest coordinate universe.

---

## Strategic conclusion

The search has ruled out a large family of natural first guesses. In particular:
- smooth-base Artin–Schreier is dead,
- \(F_1\) is dead in that same framework,
- rank-1 toric/log Artin–Schreier is dead except for the trivial \(\mathbf P^2\) remnant,
- the tested \(\mathbf P^1 \times \mathbf P^1\) blow-up lanes keep capping out below 8,
- the first genuine double-point source class is uniformly impossible,
- and ambient linear wild quotients are too small.

So the practical surviving fronts are:
\[
\text{nonlinear wild additive actions},
\qquad
\text{more singular top-down Artin–Schreier data},
\qquad
\text{or a different characteristic-3 geometry entirely.}
\]
