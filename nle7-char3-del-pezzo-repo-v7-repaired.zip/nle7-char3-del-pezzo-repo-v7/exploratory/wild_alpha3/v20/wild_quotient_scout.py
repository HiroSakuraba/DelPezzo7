"""
wild_quotient_scout.py

Initial scouting module for the wild characteristic-3 quotient lane.

Scope
-----
We examine linear order-3 actions on projective spaces in characteristic 3.
Such actions are necessarily unipotent: g = I + N with N^3 = 0, so the Jordan
blocks have size at most 3.

This module does three concrete things.

1. Enumerates the relevant Jordan types for P^2, P^3, P^4.
2. Computes the projective fixed-locus dimension from the Jordan type.
3. Computes the invariant-subspace dimension on homogeneous polynomials of the
   degrees relevant to standard del Pezzo embeddings:
      * degree 3 in P^3  (cubic surfaces, K^2 = 3),
      * degree 2 in P^4  (quadrics for degree-4 complete intersections).

The main scouting conclusion is a structural bottleneck:

  * On a cubic surface in P^3, a linear wild Z/3 action can give at most 3
    isolated fixed points, because the smallest possible nontrivial fixed locus
    in P^3 is a line.
  * On a complete intersection (2,2) in P^4, a linear wild Z/3 action can give
    at most 4 isolated fixed points.

So the standard ambient linear wild-quotient lane looks too small to reach >7
singular points; if wild quotients are going to help, they likely need a more
nonlinear / blow-up / fibration-flavored realization.
"""

from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations_with_replacement
from math import comb
from typing import Dict, Iterable, List, Sequence, Tuple


# ---------------------------------------------------------------------------
# Small linear algebra over F_3.
# ---------------------------------------------------------------------------

MOD = 3


def mod3(x: int) -> int:
    return x % MOD


def inv3(x: int) -> int:
    x %= MOD
    if x == 1:
        return 1
    if x == 2:
        return 2
    raise ZeroDivisionError("0 has no inverse in F_3")


def rank_mod3(mat: List[List[int]]) -> int:
    if not mat:
        return 0
    m = [row[:] for row in mat]
    nrows = len(m)
    ncols = len(m[0])
    r = 0
    c = 0
    while r < nrows and c < ncols:
        pivot = None
        for i in range(r, nrows):
            if m[i][c] % MOD != 0:
                pivot = i
                break
        if pivot is None:
            c += 1
            continue
        m[r], m[pivot] = m[pivot], m[r]
        inv = inv3(m[r][c])
        m[r] = [mod3(inv * x) for x in m[r]]
        for i in range(nrows):
            if i == r or m[i][c] % MOD == 0:
                continue
            factor = m[i][c] % MOD
            m[i] = [mod3(m[i][j] - factor * m[r][j]) for j in range(ncols)]
        r += 1
        c += 1
    return r


# ---------------------------------------------------------------------------
# Jordan types and representative matrices.
# ---------------------------------------------------------------------------


def partitions_with_parts_at_most_3(n: int) -> List[Tuple[int, ...]]:
    out: List[Tuple[int, ...]] = []

    def rec(rem: int, max_part: int, prefix: List[int]) -> None:
        if rem == 0:
            out.append(tuple(prefix))
            return
        for p in range(min(3, rem, max_part), 0, -1):
            prefix.append(p)
            rec(rem - p, p, prefix)
            prefix.pop()

    rec(n, n, [])
    return out


def representative_unipotent_matrix(partition: Sequence[int]) -> List[List[int]]:
    n = sum(partition)
    M = [[0] * n for _ in range(n)]
    offset = 0
    for block in partition:
        for i in range(block):
            M[offset + i][offset + i] = 1
            if i + 1 < block:
                M[offset + i][offset + i + 1] = 1
        offset += block
    return M


def fixed_locus_projective_dimension(partition: Sequence[int]) -> int:
    # For a unipotent Jordan form, dim ker(g-I) = number of Jordan blocks.
    return len(partition) - 1


# ---------------------------------------------------------------------------
# Invariant homogeneous polynomials.
# ---------------------------------------------------------------------------


def exponent_vectors(nvars: int, degree: int) -> List[Tuple[int, ...]]:
    out: List[Tuple[int, ...]] = []

    def rec(pos: int, rem: int, prefix: List[int]) -> None:
        if pos == nvars - 1:
            out.append(tuple(prefix + [rem]))
            return
        for e in range(rem + 1):
            prefix.append(e)
            rec(pos + 1, rem - e, prefix)
            prefix.pop()

    rec(0, degree, [])
    return out


def multinomial_expand_linear_form_substitution(M: List[List[int]], exps: Tuple[int, ...]) -> Dict[Tuple[int, ...], int]:
    """
    Expand the image of a monomial under x_i -> sum_j M_{ij} x_j, modulo 3.
    Variables are ordered as row-vectors of linear forms.
    """
    n = len(exps)
    polys: Dict[Tuple[int, ...], int] = {tuple([0] * n): 1}
    for i, power in enumerate(exps):
        if power == 0:
            continue
        linear_terms = [(j, M[i][j] % MOD) for j in range(n) if M[i][j] % MOD != 0]
        # Raise the linear form to the required small power by repeated multiplication.
        factor: Dict[Tuple[int, ...], int] = {tuple([0] * n): 1}
        for _ in range(power):
            new_factor: Dict[Tuple[int, ...], int] = {}
            for evec, coeff in factor.items():
                for j, c in linear_terms:
                    lst = list(evec)
                    lst[j] += 1
                    tup = tuple(lst)
                    new_factor[tup] = mod3(new_factor.get(tup, 0) + coeff * c)
            factor = new_factor
        new_polys: Dict[Tuple[int, ...], int] = {}
        for e1, c1 in polys.items():
            for e2, c2 in factor.items():
                tup = tuple(a + b for a, b in zip(e1, e2))
                new_polys[tup] = mod3(new_polys.get(tup, 0) + c1 * c2)
        polys = new_polys
    return {k: v for k, v in polys.items() if v % MOD != 0}


def invariant_subspace_dimension(partition: Sequence[int], degree: int) -> int:
    nvars = sum(partition)
    basis = exponent_vectors(nvars, degree)
    index = {e: i for i, e in enumerate(basis)}
    M = representative_unipotent_matrix(partition)
    # Build matrix of T - I on the degree-d space.
    mat: List[List[int]] = []
    for e in basis:
        col = [0] * len(basis)
        image = multinomial_expand_linear_form_substitution(M, e)
        for ee, coeff in image.items():
            col[index[ee]] = mod3(col[index[ee]] + coeff)
        col[index[e]] = mod3(col[index[e]] - 1)
        mat.append(col)
    rank = rank_mod3(mat)
    return len(basis) - rank


# ---------------------------------------------------------------------------
# Ambient-model scouting summary.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class WildAmbientRecord:
    ambient: str
    jordan_type: Tuple[int, ...]
    fixed_locus_dim: int
    invariant_dimension: int
    isolated_fixed_point_upper_bound: int | str
    note: str


@dataclass
class WildScoutReport:
    p2_records: List[WildAmbientRecord]
    p3_cubic_records: List[WildAmbientRecord]
    p4_quadric_records: List[WildAmbientRecord]

    def summary(self) -> str:
        lines: List[str] = []
        lines.append("Wild quotient scouting report in characteristic 3")
        lines.append("")
        lines.append("P^2 ambient actions (degree-9 del Pezzo / plane models):")
        for r in self.p2_records:
            lines.append(
                f"  Jordan {r.jordan_type}: fixed locus dim {r.fixed_locus_dim}, inv dim on linear forms {r.invariant_dimension}, upper bound {r.isolated_fixed_point_upper_bound}"
            )
            lines.append(f"    {r.note}")
        lines.append("")
        lines.append("P^3 ambient actions for cubic surfaces:")
        for r in self.p3_cubic_records:
            lines.append(
                f"  Jordan {r.jordan_type}: fixed locus dim {r.fixed_locus_dim}, inv dim on cubics {r.invariant_dimension}, upper bound {r.isolated_fixed_point_upper_bound}"
            )
            lines.append(f"    {r.note}")
        lines.append("")
        lines.append("P^4 ambient actions for (2,2) complete intersections:")
        for r in self.p4_quadric_records:
            lines.append(
                f"  Jordan {r.jordan_type}: fixed locus dim {r.fixed_locus_dim}, inv dim on quadrics {r.invariant_dimension}, upper bound {r.isolated_fixed_point_upper_bound}"
            )
            lines.append(f"    {r.note}")
        lines.append("")
        lines.append("Scouting verdict:")
        lines.append("  * linear wild Z/3 actions on cubic surfaces in P^3 are capped at 3 isolated fixed points;")
        lines.append("  * linear wild Z/3 actions on degree-4 complete intersections in P^4 are capped at 4 isolated fixed points;")
        lines.append("  * therefore the standard ambient linear wild-quotient lane is too small for >7 singularities.")
        lines.append("  * the live wild directions are more nonlinear: blow-ups with unipotent actions, quasi-elliptic fibrations, or purely inseparable quotients not visible in the standard embeddings.")
        return "\n".join(lines)


def p2_note(fixed_dim: int) -> Tuple[int | str, str]:
    if fixed_dim == 0:
        return 1, "Single fixed point in the ambient plane; too small for the target scale."
    return "non-isolated", "Positive-dimensional ambient fixed locus already appears in codimension 1."


def p3_cubic_note(fixed_dim: int) -> Tuple[int | str, str]:
    if fixed_dim == 1:
        return 3, "The fixed locus is a line; intersecting a cubic hypersurface gives at most 3 isolated fixed points."
    return "non-isolated", "A fixed plane or larger forces a positive-dimensional fixed locus on the surface."


def p4_ci22_note(fixed_dim: int) -> Tuple[int | str, str]:
    if fixed_dim in (1, 2):
        return 4, "Restricting two quadrics to the fixed line/plane gives at most 4 isolated common zeros."
    return "non-isolated", "A fixed 3-space or larger forces a positive-dimensional fixed locus on the surface."


def run_wild_scout() -> WildScoutReport:
    p2_records: List[WildAmbientRecord] = []
    for part in partitions_with_parts_at_most_3(3):
        if part == (1, 1, 1):
            continue
        fixed_dim = fixed_locus_projective_dimension(part)
        upper, note = p2_note(fixed_dim)
        p2_records.append(
            WildAmbientRecord(
                ambient="P^2",
                jordan_type=part,
                fixed_locus_dim=fixed_dim,
                invariant_dimension=invariant_subspace_dimension(part, 1),
                isolated_fixed_point_upper_bound=upper,
                note=note,
            )
        )

    p3_records: List[WildAmbientRecord] = []
    for part in partitions_with_parts_at_most_3(4):
        if part == (1, 1, 1, 1):
            continue
        fixed_dim = fixed_locus_projective_dimension(part)
        upper, note = p3_cubic_note(fixed_dim)
        p3_records.append(
            WildAmbientRecord(
                ambient="P^3 cubic",
                jordan_type=part,
                fixed_locus_dim=fixed_dim,
                invariant_dimension=invariant_subspace_dimension(part, 3),
                isolated_fixed_point_upper_bound=upper,
                note=note,
            )
        )

    p4_records: List[WildAmbientRecord] = []
    for part in partitions_with_parts_at_most_3(5):
        if part == (1, 1, 1, 1, 1):
            continue
        fixed_dim = fixed_locus_projective_dimension(part)
        upper, note = p4_ci22_note(fixed_dim)
        p4_records.append(
            WildAmbientRecord(
                ambient="P^4 (2,2)",
                jordan_type=part,
                fixed_locus_dim=fixed_dim,
                invariant_dimension=invariant_subspace_dimension(part, 2),
                isolated_fixed_point_upper_bound=upper,
                note=note,
            )
        )

    p2_records.sort(key=lambda r: (r.fixed_locus_dim, r.jordan_type))
    p3_records.sort(key=lambda r: (r.fixed_locus_dim, r.jordan_type))
    p4_records.sort(key=lambda r: (r.fixed_locus_dim, r.jordan_type))
    return WildScoutReport(p2_records=p2_records, p3_cubic_records=p3_records, p4_quadric_records=p4_records)


if __name__ == "__main__":
    print(run_wild_scout().summary())
