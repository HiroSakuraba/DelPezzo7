# Wild \(\alpha_3\) local quadratic search note

## Purpose

The previous wild scouting showed that the split product field on \(\mathbf P^1\times\mathbf P^1\) starts with only one isolated fixed point, but the first equivariant blow-up of the model
\[
D = x^2\partial_x + y^2\partial_y
\]
creates three exceptional fixed points.

That left an obvious question:

> Is that 3-point branching an artifact of the specific prototype, or can genuinely different nilpotent local models branch more strongly?

## Search space

We searched all homogeneous quadratic local fields over \(\mathbf F_3\):
\[
D = P_2(x,y)\partial_x + Q_2(x,y)\partial_y,
\]
where \(P_2,Q_2\) range over the 3-dimensional \(\mathbf F_3\)-space spanned by
\[
x^2,\ xy,\ y^2.
\]
There are
\[
3^6-1 = 728
\]
nonzero pairs.

We kept only those satisfying
\[
D^3=0,
\]
and then only those whose origin is isolated over \(\overline{\mathbf F}_3\), meaning \(P_2\) and \(Q_2\) have no common projective zero on \(\mathbf P^1\).

## Output counts

- nilpotent pairs: \(112\)
- isolated nilpotent pairs: \(48\)

## First blow-up result

For each isolated nilpotent model we computed the saturated lifted vector field on the two standard blow-up charts and counted the exceptional fixed points.

Result:
\[
\max \#\{\text{exceptional fixed points after one blow-up}\} = 4.
\]
Moreover, exactly `18` of the `48` isolated nilpotent models attain this maximum.

So the first branching number is not rigidly 3. The nonlinear wild lane has more room than the original prototype suggested.

## Sharp limitation

At every exceptional fixed point of every isolated quadratic nilpotent model, the transformed field has a **nonzero linear part**. So every exceptional fixed point is reduced.

Equivalently:
- no exceptional fixed point is again quadratic-nilpotent,
- no model exhibits immediate recursive nilpotent branching.

## Consequence

The local quadratic search supports the following revised view:

1. The nonlinear wild lane is genuinely richer than the split product model.
2. But one cannot get an explosion to \(>7\) singularities by iterating a single quadratic local nilpotent normal form.
3. Any successful wild construction must therefore come from **global organization** of several local nilpotent zeros or from more structured additive vector fields on already blown-up rational surfaces.
