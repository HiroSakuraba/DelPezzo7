r"""
artin_schreier_budget_scan.py

Global divisor-budget scan for Artin-Schreier covers over smooth del Pezzo bases.

Setup
-----
Let S be a smooth del Pezzo surface over an algebraically closed field of
characteristic 3, let L be a line bundle on S, and consider the characteristic-3
Artin-Schreier hypersurface in Tot(L)

    Y^3 - H^2 Y - G = 0,

with H in H^0(S,L), G in H^0(S,3L).

Adjunction gives

    K_X = pi^*(K_S + 2L)|_X,

so the del Pezzo condition forces

    A := -K_S - 2L

to be ample on S.

This module scans the resulting numerical budget for smooth del Pezzo bases.
The key controlled-crossing model is a reduced SNC pole divisor

    H = D_1 + ... + D_m in |L|,

with all singularities of X engineered at the transverse crossings of H.
If N is the number of crossing points, then

    N = p_a(L) - sum g(D_i) + m - 1
      = (L^2 + K_S.L)/2 + m - sum g(D_i)
      <= (beta - alpha)/2 + m,

where

    d     = (-K_S)^2,
    alpha = (-K_S).L,
    beta  = L^2.

Since -K_S is ample, every nonzero effective component D_i satisfies
(-K_S).D_i >= 1, hence m <= alpha. Therefore

    N <= (alpha + beta)/2.

The del Pezzo condition A ample implies the necessary inequalities

    alpha > 0,
    d - 2*alpha > 0,          (A.(-K_S) > 0)
    alpha - 2*beta > 0,       (A.L > 0)
    d - 4*alpha + 4*beta > 0, (A^2 > 0)
    alpha^2 >= d*beta.        (Hodge index)

The scan below enumerates all integer pairs (alpha,beta) satisfying these
necessary conditions, and records the strongest possible crossing bound
N <= (alpha + beta)/2.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Tuple


@dataclass(frozen=True)
class DegreeBudgetRow:
    degree: int
    feasible_pairs: List[Tuple[int, int]]
    max_crossing_bound: int | None
    verdict: str

    def summary_lines(self) -> List[str]:
        out = [f"degree d = {self.degree}"]
        if not self.feasible_pairs:
            out.append("  no nonzero (alpha,beta) pair survives the del Pezzo budget")
        else:
            out.append("  feasible integer pairs (alpha,beta) = " + ", ".join(str(p) for p in self.feasible_pairs))
            out.append(f"  strongest crossing upper bound N <= {self.max_crossing_bound}")
        out.append(f"  verdict: {self.verdict}")
        return out


@dataclass(frozen=True)
class GlobalBudgetSummary:
    rows: List[DegreeBudgetRow]
    global_max_crossings: int
    theorem_statement: str

    def to_markdown(self) -> str:
        lines = [
            "# Global divisor-budget scan for Artin–Schreier del Pezzo bases",
            "",
            "We write",
            "",
            "- $d = (-K_S)^2$ for the degree of the smooth del Pezzo base $S$,",
            "- $\\alpha = (-K_S)\\cdot L$,",
            "- $\\beta = L^2$.",
            "",
            "For a reduced SNC pole divisor $H \in |L|$ with $N$ transverse crossings,",
            "",
            "$$",
            "N \le \frac{\alpha + \beta}{2}.",
            "$$",
            "",
            "The del Pezzo condition for the Artin–Schreier cover imposes the necessary inequalities",
            "",
            "$$",
            "d-2\alpha>0,\qquad \alpha-2\beta>0,\qquad d-4\alpha+4\beta>0,\qquad \alpha^2\ge d\beta.",
            "$$",
            "",
            f"**Global result:** {self.theorem_statement}",
            "",
            "## Degree-by-degree scan",
            "",
            "| degree $d$ | feasible $(\\alpha,\\beta)$ | crossing bound | verdict |",
            "|---:|---|---:|---|",
        ]
        for row in self.rows:
            feas = ", ".join(f"$({a},{b})$" for a, b in row.feasible_pairs) if row.feasible_pairs else "none"
            bound = "-" if row.max_crossing_bound is None else str(row.max_crossing_bound)
            lines.append(f"| {row.degree} | {feas} | {bound} | {row.verdict} |")
        lines += [
            "",
            "## Interpretation",
            "",
            "This kills the entire **smooth del Pezzo base + reduced controlled-crossing pole divisor** lane as a route to more than 7 singularities.",
            "In fact the numerical budget is far tighter: it never permits more than 2 crossings on any smooth del Pezzo base.",
            "",
            "So the original idea *cannot* be rescued merely by replacing $\\mathbf P^1\\times \\mathbf P^1$ with another smooth del Pezzo base.",
            "Any surviving Artin–Schreier route would have to leave this framework, for example by using a singular base, a non-SNC/non-reduced pole geometry, or a genuinely different singularity-creation mechanism.",
        ]
        return "\n".join(lines)


def feasible_pairs_for_degree(degree: int, beta_min: int = -8, beta_max: int = 8) -> List[Tuple[int, int]]:
    """Enumerate integer (alpha,beta) pairs satisfying the necessary del Pezzo budget."""
    out: List[Tuple[int, int]] = []
    for alpha in range(1, degree + 1):
        if degree - 2 * alpha <= 0:
            continue
        for beta in range(beta_min, beta_max + 1):
            if alpha - 2 * beta <= 0:
                continue
            if degree - 4 * alpha + 4 * beta <= 0:
                continue
            if alpha * alpha < degree * beta:
                continue
            # parity constraint from adjunction: beta - alpha is even.
            if (beta - alpha) % 2 != 0:
                continue
            out.append((alpha, beta))
    out.sort()
    return out


def crossing_upper_bound(alpha: int, beta: int) -> int:
    """Upper bound N <= (alpha + beta)/2 for a reduced SNC controlled-crossing divisor."""
    return (alpha + beta) // 2


def scan_all_smooth_del_pezzo_degrees() -> GlobalBudgetSummary:
    rows: List[DegreeBudgetRow] = []
    global_max = -10**9
    for d in range(1, 10):
        feas = feasible_pairs_for_degree(d)
        if not feas:
            row = DegreeBudgetRow(
                degree=d,
                feasible_pairs=[],
                max_crossing_bound=None,
                verdict="no nonzero effective pole class survives the del Pezzo budget",
            )
        else:
            mx = max(crossing_upper_bound(a, b) for a, b in feas)
            global_max = max(global_max, mx)
            if mx >= 8:
                verdict = "numerically viable for >=8 crossings"
            else:
                verdict = f"not viable for >=8 crossings (best possible bound is {mx})"
            row = DegreeBudgetRow(d, feas, mx, verdict)
        rows.append(row)
    theorem = (
        "for every smooth del Pezzo base $S$, every Artin–Schreier cover in the reduced SNC "
        "controlled-crossing framework satisfies $N \le 2$; in particular no smooth del Pezzo base "
        "is numerically viable for $N \ge 8$."
    )
    return GlobalBudgetSummary(rows, global_max, theorem)


def run_budget_scan_report() -> str:
    summary = scan_all_smooth_del_pezzo_degrees()
    lines = [
        "=" * 72,
        "Artin-Schreier global divisor-budget scan over smooth del Pezzo bases",
        "=" * 72,
        "",
    ]
    for row in summary.rows:
        lines.extend(row.summary_lines())
        lines.append("")
    lines.append("Global theorem:")
    lines.append(f"  {summary.theorem_statement}")
    return "\n".join(lines)


if __name__ == "__main__":
    print(run_budget_scan_report())
