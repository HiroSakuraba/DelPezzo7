"""
coordinate_global_forest_scan.py

Global abstract bounded-multiplicity scan over ALL rooted-forest cluster types with
7 blow-ups on P^1 x P^1.

Each cluster type is encoded by a parent array

    parent[i] in {-1,0,...,i-1},

where parent[i] = -1 means the i-th blown-up point is a root (a distinct simple
point on P^1 x P^1), and parent[i] = j means the i-th point is infinitely near
to the j-th one.

For any such cluster, we enumerate divisor classes

    C = a F1 + b F2 - sum_i m_i E_i

with nonnegative multiplicities satisfying:
    * m_i <= m_parent(i) whenever parent[i] != -1,
    * C^2 = -2,
    * K.C = 0.

Numerically this means

    sum_i m_i = 2a + 2b,
    sum_i m_i^2 = 2ab + 2.

The module then builds the orthogonality graph and computes:
    * the maximum clique size,
    * the maximum clique size containing a genuinely non-simple class
      (max multiplicity >= 2),
    * the forest-shape distribution of these maxima.

Main use:
    settle whether any 7-point cluster type beyond the already-tested simple lane
    can even support an abstract 8-clique before spending time on realization.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from functools import lru_cache
from math import isqrt
from typing import Dict, Iterable, List, Sequence, Tuple


@dataclass(frozen=True)
class ForestClass:
    a: int
    b: int
    multiplicities: Tuple[int, ...]

    @property
    def self_intersection(self) -> int:
        return 2 * self.a * self.b - sum(m * m for m in self.multiplicities)

    @property
    def anticanonical_degree(self) -> int:
        return 2 * self.a + 2 * self.b - sum(self.multiplicities)

    @property
    def max_multiplicity(self) -> int:
        return max(self.multiplicities)

    def intersects(self, other: "ForestClass") -> int:
        return self.a * other.b + self.b * other.a - sum(x * y for x, y in zip(self.multiplicities, other.multiplicities))

    def compact_label(self) -> str:
        mults = ",".join(str(x) for x in self.multiplicities)
        return f"({self.a},{self.b}; {mults})"


@dataclass(frozen=True)
class ForestScanRecord:
    canon: str
    parent: Tuple[int, ...]
    class_count: int
    nonsimple_count: int
    max_clique_size: int
    max_clique_with_nonsimple_size: int


@dataclass
class GlobalForestScanReport:
    num_forest_shapes: int
    max_clique_histogram: Dict[int, int]
    max_nonsimple_clique_histogram: Dict[int, int]
    forests_with_8_cliques: List[ForestScanRecord]
    forests_with_nonsimple_8_cliques: List[ForestScanRecord]
    top_records: List[ForestScanRecord]

    def summary(self) -> str:
        lines: List[str] = []
        lines.append("Global rooted-forest bounded-multiplicity scan on 7 blow-ups of P^1 x P^1")
        lines.append("")
        lines.append(f"number of rooted-forest shapes scanned: {self.num_forest_shapes}")
        lines.append("")
        lines.append("Histogram of maximum abstract orthogonal clique sizes:")
        for k in sorted(self.max_clique_histogram):
            lines.append(f"  size {k}: {self.max_clique_histogram[k]} forest shapes")
        lines.append("")
        lines.append("Histogram of maximum clique sizes containing a genuinely non-simple class:")
        for k in sorted(self.max_nonsimple_clique_histogram):
            lines.append(f"  size {k}: {self.max_nonsimple_clique_histogram[k]} forest shapes")
        lines.append("")
        lines.append(f"forest shapes with an abstract 8-clique: {len(self.forests_with_8_cliques)}")
        for rec in self.forests_with_8_cliques:
            lines.append(
                f"  {rec.canon}  | parent={rec.parent} | classes={rec.class_count} | nonsimple={rec.nonsimple_count}"
            )
        lines.append("")
        lines.append(
            f"forest shapes with an abstract 8-clique containing a non-simple class: {len(self.forests_with_nonsimple_8_cliques)}"
        )
        if not self.forests_with_nonsimple_8_cliques:
            lines.append("  none")
        else:
            for rec in self.forests_with_nonsimple_8_cliques:
                lines.append(
                    f"  {rec.canon}  | parent={rec.parent} | classes={rec.class_count} | nonsimple={rec.nonsimple_count}"
                )
        lines.append("")
        lines.append("Top forest shapes by abstract clique size:")
        for rec in self.top_records:
            lines.append(
                f"  canon={rec.canon} | parent={rec.parent} | max={rec.max_clique_size} | max_with_nonsimple={rec.max_clique_with_nonsimple_size} | classes={rec.class_count} | nonsimple={rec.nonsimple_count}"
            )
        lines.append("")
        lines.append(
            "Conclusion: among all 7-point rooted-forest cluster types, the only abstract 8-clique appears in the simple-point forest."
        )
        lines.append(
            "No rooted-forest cluster type supports an abstract 8-clique containing a genuinely non-simple class."
        )
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Forest generation and canonicalization.
# ---------------------------------------------------------------------------


def generate_parent_arrays(n: int = 7) -> Iterable[Tuple[int, ...]]:
    arr = [-1]

    def rec(i: int) -> Iterable[Tuple[int, ...]]:
        if i == n:
            yield tuple(arr)
            return
        for p in [-1] + list(range(i)):
            arr.append(p)
            yield from rec(i + 1)
            arr.pop()

    yield from rec(1)


def forest_canonical_form(parent: Sequence[int]) -> str:
    children: Dict[int, List[int]] = defaultdict(list)
    roots: List[int] = []
    for i, p in enumerate(parent):
        if p == -1:
            roots.append(i)
        else:
            children[p].append(i)

    def encode(u: int) -> str:
        return "(" + "".join(sorted(encode(v) for v in children[u])) + ")"

    return "|".join(sorted(encode(r) for r in roots))


def canonical_forest_representatives(n: int = 7) -> Dict[str, Tuple[int, ...]]:
    reps: Dict[str, Tuple[int, ...]] = {}
    for parent in generate_parent_arrays(n):
        canon = forest_canonical_form(parent)
        reps.setdefault(canon, parent)
    return reps


# ---------------------------------------------------------------------------
# Generic class enumeration and clique search.
# ---------------------------------------------------------------------------


def enumerate_candidate_classes(parent: Sequence[int], max_a: int = 8, max_b: int = 8) -> List[ForestClass]:
    n = len(parent)
    out: List[ForestClass] = []
    values = [0] * n

    for a in range(max_a + 1):
        for b in range(max_b + 1):
            sum_target = 2 * a + 2 * b
            square_target = 2 * a * b + 2

            def rec(pos: int, s: int, q: int) -> None:
                if pos == n:
                    if s == 0 and q == 0:
                        out.append(ForestClass(a, b, tuple(values)))
                    return
                max_x = min(s, isqrt(q))
                p = parent[pos]
                if p != -1:
                    max_x = min(max_x, values[p])
                rem = n - pos - 1
                for x in range(max_x + 1):
                    s_rem = s - x
                    q_rem = q - x * x
                    if s_rem < 0 or q_rem < 0:
                        continue
                    if rem > 0:
                        base, extra = divmod(s_rem, rem)
                        min_sq = (rem - extra) * base * base + extra * (base + 1) * (base + 1)
                        if q_rem < min_sq:
                            continue
                    elif s_rem != 0 or q_rem != 0:
                        continue
                    values[pos] = x
                    rec(pos + 1, s_rem, q_rem)
                values[pos] = 0

            rec(0, sum_target, square_target)

    out = sorted(set(out), key=lambda c: (c.a, c.b, c.multiplicities))
    return out


def orthogonality_masks(classes: Sequence[ForestClass]) -> Tuple[List[int], int]:
    n = len(classes)
    adj = [0] * n
    nonsimple_mask = 0
    for i, c in enumerate(classes):
        if c.max_multiplicity >= 2:
            nonsimple_mask |= 1 << i
        mask = 0
        for j, d in enumerate(classes):
            if i != j and c.intersects(d) == 0:
                mask |= 1 << j
        adj[i] = mask
    return adj, nonsimple_mask


def maximum_clique_size(classes: Sequence[ForestClass]) -> int:
    adj, _ = orthogonality_masks(classes)
    n = len(classes)
    best = 0

    def bronk(R: int, P: int, X: int) -> None:
        nonlocal best
        if P == 0 and X == 0:
            best = max(best, R.bit_count())
            return
        if R.bit_count() + P.bit_count() <= best:
            return
        U = P | X
        if U:
            t = U
            pivot_candidates: List[int] = []
            while t:
                b = t & -t
                pivot_candidates.append(b.bit_length() - 1)
                t ^= b
            pivot = max(pivot_candidates, key=lambda u: (P & adj[u]).bit_count())
            ext = P & ~adj[pivot]
        else:
            ext = P
        while ext:
            b = ext & -ext
            v = b.bit_length() - 1
            bronk(R | b, P & adj[v], X & adj[v])
            P ^= b
            X |= b
            ext ^= b
            if R.bit_count() + P.bit_count() <= best:
                return

    bronk(0, (1 << n) - 1, 0)
    return best


def maximum_clique_with_nonsimple_size(classes: Sequence[ForestClass]) -> int:
    adj, nonsimple_mask = orthogonality_masks(classes)
    n = len(classes)
    best = 0

    def bronk(R: int, P: int, X: int, used_nonsimple: bool) -> None:
        nonlocal best
        if P == 0 and X == 0:
            if used_nonsimple:
                best = max(best, R.bit_count())
            return
        if R.bit_count() + P.bit_count() <= best:
            return
        if (not used_nonsimple) and ((P & nonsimple_mask) == 0):
            return
        U = P | X
        if U:
            t = U
            pivot_candidates: List[int] = []
            while t:
                b = t & -t
                pivot_candidates.append(b.bit_length() - 1)
                t ^= b
            pivot = max(pivot_candidates, key=lambda u: (P & adj[u]).bit_count())
            ext = P & ~adj[pivot]
        else:
            ext = P
        while ext:
            b = ext & -ext
            v = b.bit_length() - 1
            bronk(
                R | b,
                P & adj[v],
                X & adj[v],
                used_nonsimple or bool(b & nonsimple_mask),
            )
            P ^= b
            X |= b
            ext ^= b
            if R.bit_count() + P.bit_count() <= best:
                return
            if (not used_nonsimple) and ((P & nonsimple_mask) == 0):
                return

    bronk(0, (1 << n) - 1, 0, False)
    return best


# ---------------------------------------------------------------------------
# Global scan.
# ---------------------------------------------------------------------------


def run_global_forest_scan(max_a: int = 8, max_b: int = 8) -> GlobalForestScanReport:
    reps = canonical_forest_representatives(7)
    records: List[ForestScanRecord] = []
    for canon, parent in sorted(reps.items()):
        classes = enumerate_candidate_classes(parent, max_a=max_a, max_b=max_b)
        max_clique = maximum_clique_size(classes)
        max_clique_with_nonsimple = maximum_clique_with_nonsimple_size(classes)
        nonsimple_count = sum(1 for c in classes if c.max_multiplicity >= 2)
        records.append(
            ForestScanRecord(
                canon=canon,
                parent=parent,
                class_count=len(classes),
                nonsimple_count=nonsimple_count,
                max_clique_size=max_clique,
                max_clique_with_nonsimple_size=max_clique_with_nonsimple,
            )
        )

    max_hist = Counter(r.max_clique_size for r in records)
    nonsimple_hist = Counter(r.max_clique_with_nonsimple_size for r in records)
    forests_with_8 = [r for r in records if r.max_clique_size >= 8]
    forests_with_nonsimple_8 = [r for r in records if r.max_clique_with_nonsimple_size >= 8]
    top_records = sorted(
        records,
        key=lambda r: (-r.max_clique_size, -r.max_clique_with_nonsimple_size, r.canon),
    )[:12]
    return GlobalForestScanReport(
        num_forest_shapes=len(records),
        max_clique_histogram=dict(sorted(max_hist.items())),
        max_nonsimple_clique_histogram=dict(sorted(nonsimple_hist.items())),
        forests_with_8_cliques=forests_with_8,
        forests_with_nonsimple_8_cliques=forests_with_nonsimple_8,
        top_records=top_records,
    )


if __name__ == "__main__":
    print(run_global_forest_scan().summary())
