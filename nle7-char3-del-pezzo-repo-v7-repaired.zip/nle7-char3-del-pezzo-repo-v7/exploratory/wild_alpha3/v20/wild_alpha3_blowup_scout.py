"""
wild_alpha3_blowup_scout.py

Scouting module for the nonlinear wild / alpha_3 lane on blown-up rational
surfaces in characteristic 3.

This module does not attempt a full classification of additive group actions on
all rational surfaces.  Instead, it builds a concrete bridge between the global
P^1 x P^1 picture and the first equivariant blow-up step.

Main ingredients
----------------
1. Global vector fields on P^1 are written on an affine chart as
      D = (a + b x + c x^2) d/dx.
   In characteristic 3 one has the exact identity
      D^3 = (b^2 - a c) D.
   Hence D generates an alpha_3-action iff b^2 - a c = 0 and D != 0.

2. Every nonzero alpha_3 vector field on P^1 has exactly one geometric zero.
   Therefore every split field on P^1 x P^1 of the form
      D = D_x + D_y
   with both summands nonzero alpha_3 has exactly one isolated fixed point.

3. Near a generic isolated alpha_3 fixed point, after analytic normalization
   one meets the local model
      D_nil = x^2 d/dx + y^2 d/dy.
   After one equivariant blow-up and saturation, the exceptional divisor
   acquires exactly three fixed points.  This is the first place where the
   wild lane can outgrow the ambient-linear fixed-point bounds.

4. Those three exceptional fixed points are reduced / semisimple in the first
   blow-up model; a second blow-up at one of them does not branch again.  So
   the obvious split-model iteration does NOT automatically generate an
   arbitrarily large fixed-point tree.

Interpretation
--------------
The nonlinear wild lane is still alive, but only beyond the naive split field
and beyond the ambient-linear model.  A realistic search has to look for more
nontrivial additive vector fields on blown-up surfaces than the product-type
alpha_3 fields coming directly from P^1 x P^1.
"""

from __future__ import annotations

from dataclasses import dataclass
from itertools import product
from typing import Dict, Iterable, List, Sequence, Tuple

import sympy as sp

MOD = 3
x, y, u, v = sp.symbols("x y u v")


def mod3_int(n: int) -> int:
    return n % MOD


# ---------------------------------------------------------------------------
# Global alpha_3 fields on P^1.
# ---------------------------------------------------------------------------


def p1_alpha3_scalar(a: int, b: int, c: int) -> int:
    """Return lambda in D^3 = lambda D for D=(a+bx+cx^2)d/dx over F_3."""
    return (b * b - a * c) % MOD


def is_nonzero_alpha3_field_P1(a: int, b: int, c: int) -> bool:
    return (a, b, c) != (0, 0, 0) and p1_alpha3_scalar(a, b, c) == 0


@dataclass(frozen=True)
class P1FieldRecord:
    coeffs: Tuple[int, int, int]
    zero_count: int
    lambda_scalar: int


def p1_zero_count_for_alpha3_field(a: int, b: int, c: int) -> int:
    """
    A nonzero alpha_3 field on P^1 has one geometric zero.
    Reason: the homogenized quadratic defining the zero divisor has
    discriminant b^2-ac = 0, so it is a doubled point.
    """
    if not is_nonzero_alpha3_field_P1(a, b, c):
        raise ValueError("Field is not a nonzero alpha_3 field")
    return 1


def enumerate_alpha3_fields_P1() -> List[P1FieldRecord]:
    out: List[P1FieldRecord] = []
    for a, b, c in product(range(MOD), repeat=3):
        if is_nonzero_alpha3_field_P1(a, b, c):
            out.append(
                P1FieldRecord(
                    coeffs=(a, b, c),
                    zero_count=p1_zero_count_for_alpha3_field(a, b, c),
                    lambda_scalar=0,
                )
            )
    return out


# ---------------------------------------------------------------------------
# Local blow-up calculus for planar vector fields.
# ---------------------------------------------------------------------------


def _poly_from_mod3_expr(expr: sp.Expr, vars_: Sequence[sp.Symbol]) -> sp.Poly:
    poly = sp.Poly(sp.expand(expr), *vars_, modulus=MOD)
    return poly


@dataclass(frozen=True)
class BlowupChartData:
    chart: str
    saturation_power: int
    Px: str
    Py: str
    exceptional_zeros: Tuple[str, ...]
    note: str


def exceptional_roots_single_variable(poly_expr: sp.Expr, var: sp.Symbol) -> Tuple[str, ...]:
    poly = sp.Poly(sp.expand(poly_expr), var, modulus=MOD)
    coeffs = [int(c) % MOD for c in poly.all_coeffs()]
    # We only use this on degree <= 2 examples; report roots in P^1(F_3).
    roots: List[str] = []
    for val in range(MOD):
        if int(poly.eval(val)) % MOD == 0:
            roots.append(str(val))
    if int(poly.LC()) % MOD == 0:  # degree drops, so infinity is a root if top coeff vanishes
        roots.append("infinity")
    return tuple(dict.fromkeys(roots))


def blowup_chart_y_eq_ux(P: sp.Expr, Q: sp.Expr) -> BlowupChartData:
    P1 = sp.expand(P.subs({y: u * x}))
    Q1 = sp.expand(Q.subs({y: u * x}))
    Ucoeff = sp.expand((Q1 - u * P1) / x)
    polyP = _poly_from_mod3_expr(P1, (x, u))
    polyU = _poly_from_mod3_expr(Ucoeff, (x, u))
    s = min(polyP.total_degree() if polyP else 0, polyU.total_degree() if polyU else 0)
    # true common x-adic valuation
    def x_order(poly: sp.Poly) -> int:
        if poly.is_zero:
            return 99
        return min(mon[0] for mon, coeff in poly.terms() if coeff % MOD != 0)
    s = min(x_order(polyP), x_order(polyU))
    satP = sp.expand(P1 / (x ** s))
    satU = sp.expand(Ucoeff / (x ** s))
    exc = sp.expand(satU.subs({x: 0}))
    roots = exceptional_roots_single_variable(exc, u)
    return BlowupChartData(
        chart="y = u x",
        saturation_power=s,
        Px=str(_poly_from_mod3_expr(satP, (x, u)).as_expr()),
        Py=str(_poly_from_mod3_expr(satU, (x, u)).as_expr()),
        exceptional_zeros=roots,
        note="Exceptional fixed points are roots of the saturated u-coefficient at x=0.",
    )


def blowup_chart_x_eq_vy(P: sp.Expr, Q: sp.Expr) -> BlowupChartData:
    P2 = sp.expand(P.subs({x: v * y}))
    Q2 = sp.expand(Q.subs({x: v * y}))
    Vcoeff = sp.expand((P2 - v * Q2) / y)
    polyV = _poly_from_mod3_expr(Vcoeff, (v, y))
    polyQ = _poly_from_mod3_expr(Q2, (v, y))
    def y_order(poly: sp.Poly) -> int:
        if poly.is_zero:
            return 99
        return min(mon[1] for mon, coeff in poly.terms() if coeff % MOD != 0)
    s = min(y_order(polyV), y_order(polyQ))
    satV = sp.expand(Vcoeff / (y ** s))
    satQ = sp.expand(Q2 / (y ** s))
    exc = sp.expand(satV.subs({y: 0}))
    roots = exceptional_roots_single_variable(exc, v)
    return BlowupChartData(
        chart="x = v y",
        saturation_power=s,
        Px=str(_poly_from_mod3_expr(satV, (v, y)).as_expr()),
        Py=str(_poly_from_mod3_expr(satQ, (v, y)).as_expr()),
        exceptional_zeros=roots,
        note="Exceptional fixed points are roots of the saturated v-coefficient at y=0.",
    )


# ---------------------------------------------------------------------------
# Prototype models.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class LocalPrototypeReport:
    name: str
    P: str
    Q: str
    chart_y_eq_ux: BlowupChartData
    chart_x_eq_vy: BlowupChartData
    total_exceptional_fixed_points: int
    verdict: str


@dataclass
class WildAlpha3ScoutReport:
    p1_alpha3_count: int
    split_p1xp1_fixed_points: int
    nilpotent_prototype: LocalPrototypeReport
    reduced_prototype: LocalPrototypeReport

    def summary(self) -> str:
        lines: List[str] = []
        lines.append("Wild alpha_3 scouting on blown-up rational surfaces (characteristic 3)")
        lines.append("")
        lines.append("Global P^1 and split P^1 x P^1 stage")
        lines.append(f"  nonzero alpha_3 fields on P^1 over F_3: {self.p1_alpha3_count}")
        lines.append("  each such field has exactly one geometric zero on P^1")
        lines.append(f"  split field D = D_x + D_y on P^1 x P^1 therefore has {self.split_p1xp1_fixed_points} isolated fixed point")
        lines.append("")
        lines.append("First equivariant blow-up of the generic nilpotent isolated zero")
        lines.append(f"  prototype: {self.nilpotent_prototype.name} with D = ({self.nilpotent_prototype.P}) d/dx + ({self.nilpotent_prototype.Q}) d/dy")
        for ch in [self.nilpotent_prototype.chart_y_eq_ux, self.nilpotent_prototype.chart_x_eq_vy]:
            lines.append(f"  chart {ch.chart}: saturation power {ch.saturation_power}, coefficients ({ch.Px}), ({ch.Py})")
            lines.append(f"    exceptional zeros: {', '.join(ch.exceptional_zeros) if ch.exceptional_zeros else 'none'}")
        lines.append(f"  total exceptional fixed points after the first blow-up: {self.nilpotent_prototype.total_exceptional_fixed_points}")
        lines.append(f"  verdict: {self.nilpotent_prototype.verdict}")
        lines.append("")
        lines.append("Control comparison: a reduced fixed point")
        lines.append(f"  prototype: {self.reduced_prototype.name} with D = ({self.reduced_prototype.P}) d/dx + ({self.reduced_prototype.Q}) d/dy")
        for ch in [self.reduced_prototype.chart_y_eq_ux, self.reduced_prototype.chart_x_eq_vy]:
            lines.append(f"  chart {ch.chart}: saturation power {ch.saturation_power}, coefficients ({ch.Px}), ({ch.Py})")
            lines.append(f"    exceptional zeros: {', '.join(ch.exceptional_zeros) if ch.exceptional_zeros else 'none'}")
        lines.append(f"  total exceptional fixed points after the first blow-up: {self.reduced_prototype.total_exceptional_fixed_points}")
        lines.append(f"  verdict: {self.reduced_prototype.verdict}")
        lines.append("")
        lines.append("Scouting verdict")
        lines.append("  * the obvious split alpha_3 field on P^1 x P^1 starts with only one isolated fixed point;")
        lines.append("  * the first equivariant blow-up of a nilpotent isolated zero creates exactly three exceptional fixed points;")
        lines.append("  * this shows why the nonlinear wild lane is not killed by the ambient-linear fixed-point bounds;")
        lines.append("  * but the first new fixed points are reduced, so the naive iterative split model does not automatically explode to >7;")
        lines.append("  * any successful wild construction will likely need genuinely nonlinear additive vector fields on already blown-up surfaces, not just the product field lifted from P^1 x P^1.")
        return "\n".join(lines)


def analyze_prototype(name: str, P: sp.Expr, Q: sp.Expr, verdict: str) -> LocalPrototypeReport:
    c1 = blowup_chart_y_eq_ux(P, Q)
    c2 = blowup_chart_x_eq_vy(P, Q)
    all_pts = set()
    # Exceptional divisor is P^1 of tangent directions [x:y].
    # On y = u x, root u corresponds to [1:u]; infinity is [0:1].
    for root in c1.exceptional_zeros:
        if root == "infinity":
            all_pts.add("[0:1]")
        else:
            all_pts.add(f"[1:{root}]")
    # On x = v y, root v corresponds to [v:1]; infinity is [1:0].
    for root in c2.exceptional_zeros:
        if root == "infinity":
            all_pts.add("[1:0]")
        else:
            all_pts.add(f"[{root}:1]")
    return LocalPrototypeReport(
        name=name,
        P=str(P),
        Q=str(Q),
        chart_y_eq_ux=c1,
        chart_x_eq_vy=c2,
        total_exceptional_fixed_points=len(all_pts),
        verdict=verdict,
    )


def run_wild_alpha3_blowup_scout() -> WildAlpha3ScoutReport:
    p1_fields = enumerate_alpha3_fields_P1()
    # Split nonzero alpha_3 fields on P^1 x P^1 have one zero on each factor.
    split_fixed = 1

    nilp = analyze_prototype(
        name="generic nilpotent isolated alpha_3 zero",
        P=x**2,
        Q=y**2,
        verdict="First blow-up creates three exceptional fixed points (tangent directions 0, 1, infinity).",
    )
    red = analyze_prototype(
        name="reduced / semisimple comparison point",
        P=x,
        Q=-y,
        verdict="First blow-up has only two exceptional fixed points; no branching analogue of the nilpotent case.",
    )
    return WildAlpha3ScoutReport(
        p1_alpha3_count=len(p1_fields),
        split_p1xp1_fixed_points=split_fixed,
        nilpotent_prototype=nilp,
        reduced_prototype=red,
    )


if __name__ == "__main__":
    print(run_wild_alpha3_blowup_scout().summary())
