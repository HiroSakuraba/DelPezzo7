"""
wild_alpha3_local_search.py

Systematic local scouting for genuinely nonlinear wild / alpha_3 vector fields in
characteristic 3.

Goal
----
Search the homogeneous quadratic local models

    D = P_2(x,y) d/dx + Q_2(x,y) d/dy

with coefficients in F_3 that satisfy D^3 = 0, have an isolated zero at the
origin, and therefore describe the quadratic leading part of a nilpotent local
alpha_3 fixed point on a rational surface.

This is the first place where one can ask whether the nonlinear wild lane can
branch more aggressively than the prototype x^2 d/dx + y^2 d/dy.

What this module computes
-------------------------
1. Enumerate all homogeneous quadratic pairs (P_2, Q_2) over F_3.
2. Keep the nilpotent ones: D^3(x)=D^3(y)=0.
3. Keep only those with isolated zero at the origin over the algebraic closure,
   i.e. P_2 and Q_2 have no common projective zero on P^1.
4. Compute the first equivariant blow-up and the exceptional fixed points.
5. Translate to each exceptional fixed point and detect whether its transformed
   local field still has vanishing linear part (which would allow recursive
   quadratic branching).

Main scouting result
--------------------
Among all homogeneous quadratic nilpotent local models over F_3 with isolated
zero at the origin:

* there are 48 such models;
* the first equivariant blow-up produces at most 4 exceptional fixed points;
* 18 models attain this maximum 4-point branching;
* every exceptional fixed point is reduced (nonzero linear part);
* therefore no homogeneous quadratic nilpotent model yields recursive
  nilpotent branching at the next level.

Interpretation
--------------
The nonlinear wild lane is still more flexible than the split product model,
because the first blow-up can create 4 isolated exceptional fixed points rather
than 3.  But the homogeneous quadratic local search also says that one cannot
get an automatic explosion to >7 singularities by repeatedly blowing up the
same quadratic nilpotent pattern.  Any successful wild construction must use a
more structured global surface / vector-field geometry than a single quadratic
normal form iterated locally.
"""

from __future__ import annotations

from dataclasses import dataclass
from itertools import product
from typing import Dict, Iterable, List, Sequence, Tuple

import sympy as sp

MOD = 3
x, y, u, v = sp.symbols("x y u v")
X, U, V, Y = sp.symbols("X U V Y")

QUAD_MONOMIALS = (x**2, x * y, y**2)


# ---------------------------------------------------------------------------
# Small polynomial helpers.
# ---------------------------------------------------------------------------


def mod_poly_expr(expr: sp.Expr, vars_: Sequence[sp.Symbol]) -> sp.Expr:
    return sp.Poly(sp.expand(expr), *vars_, modulus=MOD).as_expr()


def derivation_apply(f: sp.Expr, P: sp.Expr, Q: sp.Expr) -> sp.Expr:
    return mod_poly_expr(P * sp.diff(f, x) + Q * sp.diff(f, y), (x, y))


def compose_D3_zero(P: sp.Expr, Q: sp.Expr) -> bool:
    dx3 = derivation_apply(derivation_apply(derivation_apply(x, P, Q), P, Q), P, Q)
    dy3 = derivation_apply(derivation_apply(derivation_apply(y, P, Q), P, Q), P, Q)
    return dx3 == 0 and dy3 == 0


def quadratic_from_coeffs(coeffs: Sequence[int]) -> sp.Expr:
    return sum(int(c) * m for c, m in zip(coeffs, QUAD_MONOMIALS))


def has_projective_common_zero(P: sp.Expr, Q: sp.Expr) -> bool:
    """Test whether homogeneous quadratics P,Q have a common zero on P^1_{\bar F_3}."""
    t = sp.symbols("t")
    p = sp.Poly(sp.expand(P.subs({x: t, y: 1})), t, modulus=MOD)
    q = sp.Poly(sp.expand(Q.subs({x: t, y: 1})), t, modulus=MOD)
    res = int(sp.resultant(p, q, t)) % MOD
    inf = (int(P.subs({x: 1, y: 0})) % MOD == 0) and (int(Q.subs({x: 1, y: 0})) % MOD == 0)
    return res == 0 or inf


def min_total_degree(expr: sp.Expr, vars_: Sequence[sp.Symbol]) -> int:
    poly = sp.Poly(expr, *vars_, modulus=MOD)
    if poly.is_zero:
        return 99
    return min(sum(mon) for mon, coeff in poly.terms() if coeff % MOD != 0)


def linear_terms(expr: sp.Expr, vars_: Sequence[sp.Symbol]) -> Tuple[Tuple[Tuple[int, ...], int], ...]:
    poly = sp.Poly(expr, *vars_, modulus=MOD)
    out: List[Tuple[Tuple[int, ...], int]] = []
    for mon, coeff in poly.terms():
        if coeff % MOD != 0 and sum(mon) == 1:
            out.append((mon, int(coeff) % MOD))
    out.sort()
    return tuple(out)


# ---------------------------------------------------------------------------
# Blow-up calculus.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ExceptionalPointRecord:
    projective_direction: str
    chart: str
    affine_root: int
    transformed_P: str
    transformed_Q: str
    linear_part_P: str
    linear_part_Q: str
    is_reduced: bool


@dataclass(frozen=True)
class LocalModelRecord:
    coeffs_P: Tuple[int, int, int]
    coeffs_Q: Tuple[int, int, int]
    P: str
    Q: str
    exceptional_points: Tuple[ExceptionalPointRecord, ...]

    @property
    def exceptional_count(self) -> int:
        return len(self.exceptional_points)


@dataclass(frozen=True)
class WildAlpha3LocalSearchReport:
    total_homogeneous_quadratic_models: int
    nilpotent_models: int
    isolated_nilpotent_models: int
    max_exceptional_points_after_first_blowup: int
    num_models_attaining_max: int
    all_exceptional_points_reduced: bool
    representative_max_models: Tuple[LocalModelRecord, ...]

    def summary(self) -> str:
        lines: List[str] = []
        lines.append("Homogeneous quadratic local alpha_3 search over F_3")
        lines.append("")
        lines.append(f"Total homogeneous quadratic pairs (P_2,Q_2): {self.total_homogeneous_quadratic_models}")
        lines.append(f"Nilpotent pairs with D^3=0: {self.nilpotent_models}")
        lines.append(f"Nilpotent pairs with isolated zero at the origin: {self.isolated_nilpotent_models}")
        lines.append("")
        lines.append("First equivariant blow-up")
        lines.append(f"  maximum number of exceptional fixed points: {self.max_exceptional_points_after_first_blowup}")
        lines.append(f"  number of models attaining this maximum: {self.num_models_attaining_max}")
        lines.append(f"  every exceptional fixed point reduced (nonzero linear part): {self.all_exceptional_points_reduced}")
        lines.append("")
        lines.append("Representative max-branching models")
        for rec in self.representative_max_models:
            lines.append(f"  D = ({rec.P}) d/dx + ({rec.Q}) d/dy")
            dirs = ", ".join(pt.projective_direction for pt in rec.exceptional_points)
            lines.append(f"    exceptional directions: {dirs}")
            for pt in rec.exceptional_points:
                lines.append(
                    f"      {pt.projective_direction} on {pt.chart} root={pt.affine_root}: "
                    f"linear part ({pt.linear_part_P}, {pt.linear_part_Q}), reduced={pt.is_reduced}"
                )
        lines.append("")
        lines.append("Scouting verdict")
        lines.append("  * quadratic nilpotent local models can branch to 4 exceptional fixed points after one blow-up;")
        lines.append("  * this beats the earlier 3-point prototype and keeps the nonlinear wild lane alive;")
        lines.append("  * but no exceptional point remains quadratic-nilpotent, so there is no automatic recursive explosion;")
        lines.append("  * any successful wild construction must therefore use more global structure than a single iterated quadratic normal form.")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# First blow-up data and exceptional-point translation.
# ---------------------------------------------------------------------------


def _x_order(poly: sp.Poly) -> int:
    if poly.is_zero:
        return 99
    return min(mon[0] for mon, coeff in poly.terms() if coeff % MOD != 0)


def _y_order(poly: sp.Poly) -> int:
    if poly.is_zero:
        return 99
    return min(mon[1] for mon, coeff in poly.terms() if coeff % MOD != 0)


def first_blowup_exceptional_records(P: sp.Expr, Q: sp.Expr) -> Tuple[ExceptionalPointRecord, ...]:
    records: Dict[str, ExceptionalPointRecord] = {}

    # Chart y = u x.
    P1 = sp.expand(P.subs({y: u * x}))
    Q1 = sp.expand(Q.subs({y: u * x}))
    Ucoeff = sp.expand((Q1 - u * P1) / x)
    s = min(_x_order(sp.Poly(P1, x, u, modulus=MOD)), _x_order(sp.Poly(Ucoeff, x, u, modulus=MOD)))
    satP = mod_poly_expr(P1 / (x**s), (x, u))
    satU = mod_poly_expr(Ucoeff / (x**s), (x, u))
    exc = sp.Poly(satU.subs({x: 0}), u, modulus=MOD)
    for r in range(MOD):
        if int(exc.eval(r)) % MOD != 0:
            continue
        translated_P = mod_poly_expr(satP.subs({x: X, u: U + r}), (X, U))
        translated_Q = mod_poly_expr(satU.subs({x: X, u: U + r}), (X, U))
        lpP = mod_poly_expr(sum((coeff * (X if mon == (1, 0) else U) for mon, coeff in linear_terms(translated_P, (X, U))), 0), (X, U))
        lpQ = mod_poly_expr(sum((coeff * (X if mon == (1, 0) else U) for mon, coeff in linear_terms(translated_Q, (X, U))), 0), (X, U))
        proj = f"[1:{r}]"
        records[proj] = ExceptionalPointRecord(
            projective_direction=proj,
            chart="y = u x",
            affine_root=r,
            transformed_P=str(translated_P),
            transformed_Q=str(translated_Q),
            linear_part_P=str(lpP),
            linear_part_Q=str(lpQ),
            is_reduced=(lpP != 0 or lpQ != 0),
        )

    # Chart x = v y.
    P2 = sp.expand(P.subs({x: v * y}))
    Q2 = sp.expand(Q.subs({x: v * y}))
    Vcoeff = sp.expand((P2 - v * Q2) / y)
    s = min(_y_order(sp.Poly(Vcoeff, v, y, modulus=MOD)), _y_order(sp.Poly(Q2, v, y, modulus=MOD)))
    satV = mod_poly_expr(Vcoeff / (y**s), (v, y))
    satQ = mod_poly_expr(Q2 / (y**s), (v, y))
    exc = sp.Poly(satV.subs({y: 0}), v, modulus=MOD)
    for r in range(MOD):
        if int(exc.eval(r)) % MOD != 0:
            continue
        proj = f"[{r}:1]"
        if proj in records:
            continue
        translated_P = mod_poly_expr(satV.subs({v: V + r, y: Y}), (V, Y))
        translated_Q = mod_poly_expr(satQ.subs({v: V + r, y: Y}), (V, Y))
        lpP = mod_poly_expr(sum((coeff * (V if mon == (1, 0) else Y) for mon, coeff in linear_terms(translated_P, (V, Y))), 0), (V, Y))
        lpQ = mod_poly_expr(sum((coeff * (V if mon == (1, 0) else Y) for mon, coeff in linear_terms(translated_Q, (V, Y))), 0), (V, Y))
        records[proj] = ExceptionalPointRecord(
            projective_direction=proj,
            chart="x = v y",
            affine_root=r,
            transformed_P=str(translated_P),
            transformed_Q=str(translated_Q),
            linear_part_P=str(lpP),
            linear_part_Q=str(lpQ),
            is_reduced=(lpP != 0 or lpQ != 0),
        )

    return tuple(sorted(records.values(), key=lambda rec: rec.projective_direction))


# ---------------------------------------------------------------------------
# Enumeration and reporting.
# ---------------------------------------------------------------------------


def enumerate_isolated_quadratic_nilpotent_models() -> List[LocalModelRecord]:
    out: List[LocalModelRecord] = []
    for coeffs_P in product(range(MOD), repeat=3):
        for coeffs_Q in product(range(MOD), repeat=3):
            if coeffs_P == (0, 0, 0) and coeffs_Q == (0, 0, 0):
                continue
            P = quadratic_from_coeffs(coeffs_P)
            Q = quadratic_from_coeffs(coeffs_Q)
            if not compose_D3_zero(P, Q):
                continue
            if has_projective_common_zero(P, Q):
                continue
            out.append(
                LocalModelRecord(
                    coeffs_P=tuple(int(c) for c in coeffs_P),
                    coeffs_Q=tuple(int(c) for c in coeffs_Q),
                    P=str(mod_poly_expr(P, (x, y))),
                    Q=str(mod_poly_expr(Q, (x, y))),
                    exceptional_points=first_blowup_exceptional_records(P, Q),
                )
            )
    return out


def run_wild_alpha3_local_search() -> WildAlpha3LocalSearchReport:
    total = MOD**6 - 1
    nilpotent = 0
    isolated: List[LocalModelRecord] = []
    for coeffs_P in product(range(MOD), repeat=3):
        for coeffs_Q in product(range(MOD), repeat=3):
            if coeffs_P == (0, 0, 0) and coeffs_Q == (0, 0, 0):
                continue
            P = quadratic_from_coeffs(coeffs_P)
            Q = quadratic_from_coeffs(coeffs_Q)
            if not compose_D3_zero(P, Q):
                continue
            nilpotent += 1
            if has_projective_common_zero(P, Q):
                continue
            isolated.append(
                LocalModelRecord(
                    coeffs_P=tuple(int(c) for c in coeffs_P),
                    coeffs_Q=tuple(int(c) for c in coeffs_Q),
                    P=str(mod_poly_expr(P, (x, y))),
                    Q=str(mod_poly_expr(Q, (x, y))),
                    exceptional_points=first_blowup_exceptional_records(P, Q),
                )
            )

    max_exc = max(rec.exceptional_count for rec in isolated)
    reps = [rec for rec in isolated if rec.exceptional_count == max_exc]
    all_reduced = all(pt.is_reduced for rec in isolated for pt in rec.exceptional_points)

    # Keep a few canonical representatives for the summary.
    reps = sorted(reps, key=lambda rec: (rec.P, rec.Q))[:4]

    return WildAlpha3LocalSearchReport(
        total_homogeneous_quadratic_models=total,
        nilpotent_models=nilpotent,
        isolated_nilpotent_models=len(isolated),
        max_exceptional_points_after_first_blowup=max_exc,
        num_models_attaining_max=sum(1 for rec in isolated if rec.exceptional_count == max_exc),
        all_exceptional_points_reduced=all_reduced,
        representative_max_models=tuple(reps),
    )


if __name__ == "__main__":
    print(run_wild_alpha3_local_search().summary())
