# Wild / \(\alpha_3\) Blow-up Scout Note (v19)

This note records the first scouting calculation for the nonlinear wild-quotient lane on blown-up rational surfaces in characteristic 3.

## 1. Global \(\alpha_3\) fields on \(\mathbf P^1\)

On an affine chart, every global vector field on \(\mathbf P^1\) has the form
\[
D = (a + bx + cx^2)\,\partial_x.
\]
In characteristic 3 one has the exact restricted-Lie identity
\[
D^3 = (b^2-ac) D.
\]
Therefore \(D\) generates an \(\alpha_3\)-action iff
\[
b^2-ac = 0,
\qquad
D \neq 0.
\]
The homogenized zero divisor is a quadratic of discriminant \(b^2-ac\), so every nonzero \(\alpha_3\)-field on \(\mathbf P^1\) has exactly **one** geometric zero.

Consequently, a split field on
\[
\mathbf P^1 \times \mathbf P^1,
\qquad
D = D_x + D_y,
\]
with both summands nonzero \(\alpha_3\)-fields has exactly **one isolated fixed point**.

So the raw product model starts too small.

## 2. First equivariant blow-up of a nilpotent isolated zero

The local prototype for a generic nilpotent isolated \(\alpha_3\)-fixed point is
\[
D_{\mathrm{nil}} = x^2\partial_x + y^2\partial_y.
\]
Blow up the origin.

### Chart \(y = ux\)
Then
\[
D(x)=x^2,
\qquad
D(u)=\frac{D(y)-uD(x)}{x}=x(u^2-u).
\]
After saturating by the common factor \(x\), the lifted field is
\[
\widetilde D = x\partial_x + (u^2-u)\partial_u.
\]
On the exceptional divisor \(x=0\), fixed points satisfy
\[
u^2-u = 0,
\]
so
\[
u = 0,1.
\]

### Chart \(x = vy\)
Similarly,
\[
\widetilde D = (v^2-v)\partial_v + y\partial_y,
\]
so on the exceptional divisor \(y=0\) one gets
\[
v^2-v = 0,
\]
thus
\[
v = 0,1.
\]
Gluing the two charts, the exceptional divisor has exactly the three fixed points
\[
[1:0],\qquad [1:1],\qquad [0:1].
\]

So the first equivariant blow-up turns **one** nilpotent isolated fixed point into **three** exceptional fixed points.

This is the first clear sign that the nonlinear wild lane is not killed by the ambient linear fixed-point bounds.

## 3. Comparison with a reduced fixed point

For the reduced prototype
\[
D_{\mathrm{red}} = x\partial_x - y\partial_y,
\]
the same calculation gives only **two** exceptional fixed points after blow-up.

So the nilpotent \(\alpha_3\) point is the genuinely branching one.

## 4. Interpretation

This scout result says two things at once.

First, the wild lane is **not** exhausted by the earlier ambient-linear bound. The first equivariant blow-up of a nilpotent \(\alpha_3\) point already creates more fixed points than the raw product model had.

Second, the first-generation exceptional fixed points are already reduced / semisimple in this basic model. So the naive split-field iteration does not automatically explode into an arbitrarily large fixed-point tree.

## 5. Practical next move

A serious wild search should now look for genuinely nonlinear additive vector fields on already blown-up rational surfaces, rather than only lifting split product fields from \(\mathbf P^1 \times \mathbf P^1\).

The right objects to enumerate next are:
- \(\alpha_3\)-vector fields on blow-ups with prescribed nilpotent isolated zero schemes,
- equivariant blow-up patterns that preserve nilpotent rather than reduced fixed points,
- quotient candidates where the exceptional fixed-point tree can stay branching for more than one stage.
