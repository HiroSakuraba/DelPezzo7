"""
toric_rank1_artin_schreier_scan.py

Rank-1 toric/log del Pezzo feasibility scan for the Artin-Schreier budget

    Y^3 - H^2 Y - G = 0

in characteristic 3.

Core question
-------------
For a rank-1 toric/log del Pezzo surface B and a nonzero effective Cartier line
bundle L on B, can the Fano budget

    -(K_B + 2L)

remain ample?

If not, then the top-down Artin-Schreier route is dead on that base before any
singularity engineering begins.

Strategy
--------
1. Reduce rank-1 toric/log del Pezzo surfaces to fake weighted projective planes.
2. Scan weighted projective planes P(a,b,c): this is already enough because any
   quasi-etale quotient only makes Cartier classes sparser.
3. For the surviving base(s), bound how many isolated singularities the standard
   pole/branch geometry can create.
"""
from __future__ import annotations

from dataclasses import dataclass
from math import gcd, lcm
from typing import List, Tuple


@dataclass(frozen=True)
class WPPRow:
    weights: Tuple[int, int, int]
    lcm_value: int
    sigma: float
    budget_allows_nonzero_L: bool

    def summary(self) -> str:
        a, b, c = self.weights
        allow = "yes" if self.budget_allows_nonzero_L else "no"
        return f"P({a},{b},{c}): lcm={self.lcm_value}, sigma=(a+b+c)/l={self.sigma:.6g}, nonzero-L budget={allow}"


def is_well_formed_wpp(a: int, b: int, c: int) -> bool:
    return gcd(a, b) == gcd(a, c) == gcd(b, c) == 1


def wpp_budget_invariant(a: int, b: int, c: int) -> Tuple[int, float]:
    ell = lcm(a, b, c)
    sigma = (a + b + c) / ell
    return ell, sigma


def enumerate_wpps(max_weight: int = 40) -> List[WPPRow]:
    rows: List[WPPRow] = []
    for a in range(1, max_weight + 1):
        for b in range(a, max_weight + 1):
            for c in range(b, max_weight + 1):
                if not is_well_formed_wpp(a, b, c):
                    continue
                ell, sigma = wpp_budget_invariant(a, b, c)
                rows.append(WPPRow((a, b, c), ell, sigma, sigma > 2.0))
    return rows


def budget_survivors(max_weight: int = 40) -> List[WPPRow]:
    return [row for row in enumerate_wpps(max_weight) if row.budget_allows_nonzero_L]


def prove_only_P2_survives() -> List[str]:
    return [
        "Weighted-projective-plane reduction.",
        "Let Y = P(a,b,c) be well-formed with 1 <= a <= b <= c.",
        "Write ell = lcm(a,b,c). The primitive ample Cartier generator is A = O_Y(ell),",
        "and the anticanonical slope is sigma = (a+b+c)/ell, so a nonzero Cartier L = mA",
        "can satisfy -(K_Y + 2L) ample only if sigma > 2m >= 2, hence a+b+c > 2 ell.",
        "",
        "Now classify the inequality a+b+c > 2 ell:",
        "  - If a >= 2 and b >= 2, then pairwise coprimeness gives ell = abc, hence",
        "      2 ell = 2abc >= 4c > a+b+c.",
        "    Impossible.",
        "  - Hence a = 1.",
        "  - If b >= 3, then ell = bc and",
        "      2 ell - (1+b+c) = 2bc - 1 - b - c > 0.",
        "    Impossible.",
        "  - So b is 1 or 2.",
        "  - If (a,b) = (1,2), then ell = 2c and a+b+c = c+3 < 4c = 2 ell for every c >= 1.",
        "  - Therefore (a,b) = (1,1), and then ell = c. The inequality c+2 > 2c forces c = 1.",
        "",
        "Conclusion: the only well-formed weighted projective plane with any nonzero",
        "Artin-Schreier Fano budget is P(1,1,1) = P^2.",
        "",
        "Any rank-1 toric/log del Pezzo surface is a fake weighted projective plane, i.e. a",
        "finite quasi-etale quotient of such a weighted projective plane. Pulling back an ample",
        "Cartier L along the quotient preserves the inequality -(K + 2L) ample, so no quotient",
        "can create a new survivor once the weighted-projective cover fails.",
    ]


def residual_p2_budget_lines() -> List[str]:
    return [
        "Residual base: P^2.",
        "Take A = O_{P^2}(1). Then -K_{P^2} = 3A, so the budget condition",
        "  -(K + 2L) ample",
        "with nonzero Cartier L = mA forces 3 - 2m > 0, hence m = 1.",
        "So the only surviving line bundle is L = O_{P^2}(1).",
        "",
        "Pole/branch geometry on P^2 with L = O(1):",
        "  - The pole divisor H is a single line, so the crossing mechanism creates 0 crossings.",
        "  - In the standard smooth-pole lane G = H*M with M in H^0(O(2)), isolated singularities",
        "    occur at H ∩ {M = 0}. Since M|_H has degree 2 on H ≅ P^1, this creates at most",
        "    2 isolated A_2-type points.",
        "",
        "Therefore even the unique surviving rank-1 toric base P^2 cannot approach >7 singularities",
        "inside the existing Artin-Schreier mechanism.",
    ]


def report_text(max_weight: int = 60) -> str:
    survivors = budget_survivors(max_weight)
    lines: List[str] = []
    lines.append("=" * 76)
    lines.append("Rank-1 toric/log del Pezzo Artin-Schreier budget scan")
    lines.append("=" * 76)
    lines.append("")
    lines.append("Setup:")
    lines.append("  Seek rank-1 toric/log del Pezzo bases B with a nonzero effective Cartier")
    lines.append("  line bundle L such that -(K_B + 2L) is ample.")
    lines.append("")
    lines.extend(prove_only_P2_survives())
    lines.append("")
    lines.append(f"Computational confirmation up to weights <= {max_weight}:")
    lines.append(f"  number of well-formed weighted projective planes scanned: {len(enumerate_wpps(max_weight))}")
    lines.append(f"  survivors with nonzero budget: {len(survivors)}")
    for row in survivors:
        lines.append("  " + row.summary())
    lines.append("")
    lines.extend(residual_p2_budget_lines())
    lines.append("")
    lines.append("Global verdict:")
    lines.append("  Among rank-1 toric/log del Pezzo surfaces, the only base that even survives")
    lines.append("  the Artin-Schreier Fano budget is P^2, and there the standard pole/branch")
    lines.append("  geometry yields at most 2 isolated singularities.")
    return "\n".join(lines)


def markdown_report(max_weight: int = 60) -> str:
    survivors = budget_survivors(max_weight)
    lines = [
        "# Rank-1 toric/log del Pezzo Artin–Schreier budget scan",
        "",
        "We ask for rank-1 toric/log del Pezzo surfaces $B$ admitting a **nonzero effective Cartier** line bundle $L$ such that",
        "",
        "$$",
        "-(K_B + 2L)\\ \text{is ample}.",
        "$$",
        "",
        "This is the necessary Fano budget for the characteristic-3 Artin–Schreier model",
        "",
        "$$",
        "Y^3 - H^2 Y - G = 0,\\qquad H\\in H^0(B,L).",
        "$$",
        "",
        "## Step 1: weighted-projective reduction",
        "",
        "Every rank-1 toric/log del Pezzo surface is a fake weighted projective plane, so it suffices to bound the budget on weighted projective covers $\\mathbf P(a,b,c)$. Any quasi-étale quotient only makes Cartier classes sparser, not richer.",
        "",
        "For a well-formed weighted projective plane $Y=\\mathbf P(a,b,c)$ with $1\\le a\\le b\\le c$, write",
        "",
        "$$",
        "\\ell = \\operatorname{lcm}(a,b,c),\\qquad A=\\mathcal O_Y(\\ell).",
        "$$",
        "",
        "Then every Cartier line bundle is $mA$, $m\\ge 1$, and",
        "",
        "$$",
        "-K_Y \\equiv \\frac{a+b+c}{\\ell}A.",
        "$$",
        "",
        "So a nonzero Cartier $L=mA$ can satisfy the Fano budget only if",
        "",
        "$$",
        "\\frac{a+b+c}{\\ell} > 2m \\ge 2,",
        "$$",
        "",
        "i.e. only if $a+b+c > 2\\ell$.",
        "",
        "## Step 2: solve the inequality",
        "",
        "For a well-formed surface, the weights are pairwise coprime.",
        "",
        "If $a\\ge 2$ and $b\\ge 2$, then $\\ell=abc$ and",
        "",
        "$$",
        "2\\ell = 2abc \\ge 4c > a+b+c,",
        "$$",
        "",
        "so the inequality fails.",
        "",
        "Hence $a=1$.",
        "",
        "If $b\\ge 3$, then $\\ell=bc$ and",
        "",
        "$$",
        "2\\ell-(1+b+c)=2bc-1-b-c > 0,",
        "$$",
        "",
        "so again the inequality fails.",
        "",
        "Thus $b\\in\\{1,2\\}$.",
        "",
        "If $(a,b)=(1,2)$, then $\\ell=2c$ and",
        "",
        "$$",
        "1+2+c = c+3 < 4c = 2\\ell",
        "$$",
        "",
        "for every $c\\ge 1$, so this also fails.",
        "",
        "Therefore $(a,b)=(1,1)$, hence $\\ell=c$, and",
        "",
        "$$",
        "c+2 > 2c",
        "$$",
        "",
        "forces $c=1$.",
        "",
        "So the only weighted projective survivor is",
        "",
        "$$",
        "\\mathbf P(1,1,1)=\\mathbf P^2.",
        "$$",
        "",
        f"Computational confirmation up to weights $\\le {max_weight}$: scanned {len(enumerate_wpps(max_weight))} well-formed triples, survivors = {len(survivors)}.",
    ]
    for row in survivors:
        lines.extend(["", "- " + row.summary()])
    lines += [
        "",
        "## Step 3: residual singularity count on $\\mathbf P^2$",
        "",
        "On $\\mathbf P^2$, write $A=\\mathcal O(1)$. Then",
        "",
        "$$",
        "-K_{\\mathbf P^2}=3A.",
        "$$",
        "",
        "A nonzero Cartier $L=mA$ satisfies the Fano budget only if",
        "",
        "$$",
        "3-2m>0,",
        "$$",
        "",
        "so necessarily $m=1$ and",
        "",
        "$$",
        "L=\\mathcal O_{\\mathbf P^2}(1).",
        "$$",
        "",
        "Now the pole divisor $H\\in |L|$ is just a single line, so the old crossing mechanism creates **no crossings at all**.",
        "",
        "In the standard smooth-pole branch geometry $G=H\\,M$ with $M\\in H^0(\\mathbf P^2,\\mathcal O(2))$, isolated singularities are created at",
        "",
        "$$",
        "H \\cap \\{M=0\\}.",
        "$$",
        "",
        "Since $M|_H$ has degree $2$ on $H\\cong \\mathbf P^1$, this yields at most **2 isolated points**.",
        "",
        "## Verdict",
        "",
        "Among rank-1 toric/log del Pezzo bases, the Artin–Schreier Fano budget leaves only $\\mathbf P^2$, and there the standard pole/branch geometry yields at most 2 isolated singularities. So this lane does **not** offer a path to more than 7 singularities without changing the mechanism more radically.",
    ]
    return "\n".join(lines)


if __name__ == "__main__":
    print(report_text())
