# v63 semisplit quotient-twist presentation for the surviving `I0* + I0*` branch

## What this step did

The `v61` family-wide audit showed that the **explicit nonsplit** two-point torsor family from `v58`
always gives ordinary-weight cubic-cone singularities on the total space. So the next clean move was to
look for a **different birational presentation** of the same `I0* + I0*` branch that actually removes the
section while keeping the local quotient geometry ordinary.

The clean place where this works is the **semisplit** part of the explicit two-point `I0* + I0*` Jacobian family.

For a semisplit model
\[
y^2 = x^3 + \alpha t x^2 + \beta t^2 x + \gamma t^3,
\]
the residual cubic
\[
f(u)=u^3+\alpha u^2+\beta u+\gamma
\]
has a unique root \(r\in\mathbf F_3\). That gives a rational 2-torsion point
\[
T_t=(rt,0)
\]
on the generic fiber, and hence a rational 2-torsion point
\[
T=(r,0)
\]
on the constant residual elliptic curve
\[
E: y^2=x^3+\alpha x^2+\beta x+\gamma.
\]

This allows the **section-killing involution**
\[
g_E(P)= -P+T
\]
on \(E\), defined over \(\mathbf F_3\), and therefore the diagonal involution
\[
g(P,u)=\bigl(g_E(P),-u\bigr)
\]
on \(E\times \mathbf P^1_u\).

That is the birational escape hatch that the nonsplit branch did **not** have.

## Why this is the right kind of involution

- It has order 2.
- It exchanges the zero section and the `T`-section:
  \[
  g_E(O)=T,\qquad g_E(T)=O,
  \]
  so the quotient no longer carries the original section.
- Fixed points on `E` solve
  \[
  P=-P+T\iff 2P=T.
  \]
  Since `[2]:E\to E` is separable of degree 4 in characteristic 3, there are exactly **4 geometric solutions**.
- Combined with the two branch points of \(u\mapsto u^2=t\) at `u=0,∞`, the diagonal quotient has
  \[
  4\times 2 = 8
  \]
  isolated quotient fixed points.
- The derivative of `g_E` at a fixed point is `-1` on the tangent line of `E`, and the derivative of `u\mapsto -u`
  is `-1` on the base tangent. So locally the surface quotient is of type
  \[
  (z_1,z_2)\mapsto (-z_1,-z_2),
  \]
  hence an ordinary `A_1` quotient point.

So this presentation gives exactly the kind of “8 ordinary quotient points and no obvious section” geometry that the
v58/v61 cubic-cone total-space model failed to produce.

## Explicit semisplit models

The semisplit exact two-point models in the normalized `v56` family are:

- `(α,β,γ)=(1,0,1)`, 2-torsion root `r=1`, `#E(F_3)=6`
- `(α,β,γ)=(1,1,1)`, 2-torsion root `r=2`, `#E(F_3)=6`
- `(α,β,γ)=(1,2,0)`, 2-torsion root `r=0`, `#E(F_3)=6`
- `(α,β,γ)=(2,0,2)`, 2-torsion root `r=2`, `#E(F_3)=2`
- `(α,β,γ)=(2,1,2)`, 2-torsion root `r=1`, `#E(F_3)=2`
- `(α,β,γ)=(2,2,0)`, 2-torsion root `r=0`, `#E(F_3)=2`


All six have a rational 2-torsion point and no rational 4-torsion (the group orders over `F_3` are `2` or `6`), so
there is no rational fixed section solving `2P=T`.

## Representative explicit model

The cleanest representative is
\[
(\alpha,\beta,\gamma)=(1,0,1),
\]
namely
\[
y^2 = x^3 + t x^2 + t^3.
\]

Its residual elliptic curve is
\[
E: y^2 = x^3 + x^2 + 1,
\]
with rational 2-torsion point
\[
T=(1,0).
\]

For this model the section-killing involution on `E` is
\[
g_E(x,y)=\left(\frac{x+1}{x-1},\;\frac{2y}{(x-1)^2}\right),
\]
which is exactly the map `-P+T` in characteristic 3.

The diagonal involution on the smooth product is then
\[
g(x,y,u)=\left(\frac{x+1}{x-1},\;\frac{2y}{(x-1)^2},\;-u\right).
\]

This gives the quotient presentation
\[
X = (E\times \mathbf P^1_u)/\langle g\rangle,
\qquad t=u^2,
\]
with:
- zero section and `T`-section exchanged,
- 8 isolated fixed points upstairs,
- 8 `A_1` quotient points downstairs.

## What this *does* and *does not* show

What it **does** show:
- the `I0* + I0*` branch has a genuine **different birational presentation** that avoids the cubic-cone total-space singularities of the explicit nonsplit `v58` torsor family;
- in this presentation, the section can be removed by an explicit involution defined over `F_3`;
- the resulting quotient has the right *count* and *local type* of quotient points.

What it **does not** yet show:
- that this quotient is already the final klt del Pezzo model;
- that its minimal resolution / contraction data matches exactly the desired two `I0*` fibers after all birational modifications;
- or that `-K` is ample on the final contraction.

So this is a real geometric improvement over `v58`/`v61`, but it is still a birational presentation layer, not the final theorem.
