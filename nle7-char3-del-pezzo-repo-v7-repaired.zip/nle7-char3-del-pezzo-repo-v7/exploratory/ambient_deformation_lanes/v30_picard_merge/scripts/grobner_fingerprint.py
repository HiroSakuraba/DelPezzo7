"""
grobner_fingerprint.py — low-degree Jacobian-ideal fingerprinting.

This is not a full Gröbner basis engine.  It computes a robust, finite-field-safe
fingerprint from the Jacobian ideal by assembling low-degree Macaulay slices,
measuring quotient Hilbert data, and extracting a compact initial-support profile.
"""
from __future__ import annotations

from functools import lru_cache
from typing import Dict, Sequence, Tuple

import numpy as np

from .projective_geometry import (
    coeffs_from_dict,
    derivative_dict,
    homogeneous_monomials,
    polynomial_dict,
)

Exp = Tuple[int, ...]


def _mul_exp(a: Exp, b: Exp) -> Exp:
    return tuple(int(x) + int(y) for x, y in zip(a, b))


def _leading_exp_lex(poly: Dict[Exp, int]) -> Exp | None:
    if not poly:
        return None
    return max(poly.keys())


@lru_cache(maxsize=None)
def _monomials_by_degree(n_vars: int, degree: int):
    return homogeneous_monomials(n_vars, degree)


def jacobian_generators(field, coeffs: Sequence[int], monomials: Sequence[Exp]):
    coeff_dict = polynomial_dict(coeffs, monomials)
    n_vars = len(monomials[0])
    gens = []
    for j in range(n_vars):
        d = derivative_dict(field, coeff_dict, j)
        if d:
            gens.append(d)
    return gens


def _poly_to_vector(field, poly: Dict[Exp, int], n_vars: int, degree: int) -> np.ndarray:
    vec, _ = coeffs_from_dict(field, poly, n_vars, degree)
    return vec


def _multiply_poly_by_monomial(field, poly: Dict[Exp, int], mono: Exp) -> Dict[Exp, int]:
    out = {}
    for exp, c in poly.items():
        out[_mul_exp(exp, mono)] = int(c) % field.q
    return out


def homogeneous_ideal_degree_rank(field, generators, n_vars: int, total_degree: int):
    rows = []
    lead_terms = []
    for g in generators:
        deg_g = sum(next(iter(g.keys()))) if g else 0
        if deg_g > total_degree:
            continue
        for mono in _monomials_by_degree(n_vars, total_degree - deg_g):
            poly = _multiply_poly_by_monomial(field, g, mono)
            rows.append(_poly_to_vector(field, poly, n_vars, total_degree))
            lt = _leading_exp_lex(poly)
            if lt is not None:
                lead_terms.append(lt)
    if not rows:
        dim = len(_monomials_by_degree(n_vars, total_degree))
        return {
            'ambient_dim': dim,
            'ideal_rank': 0,
            'quotient_dim': dim,
            'leading_terms': [],
            'row_count': 0,
        }
    M = np.vstack(rows) % field.q
    rk = field.rank(M)
    ambient_dim = len(_monomials_by_degree(n_vars, total_degree))
    return {
        'ambient_dim': ambient_dim,
        'ideal_rank': int(rk),
        'quotient_dim': int(max(ambient_dim - rk, 0)),
        'leading_terms': lead_terms,
        'row_count': int(M.shape[0]),
    }


def quotient_hilbert_function(field, generators, n_vars: int, max_degree: int = 5):
    hf = []
    ranks = []
    leading_hist = []
    for d in range(max_degree + 1):
        rep = homogeneous_ideal_degree_rank(field, generators, n_vars, d)
        hf.append(int(rep['quotient_dim']))
        ranks.append(int(rep['ideal_rank']))
        leading_hist.append(len(set(rep['leading_terms'])))
    return {
        'hilbert_function': hf,
        'ideal_ranks': ranks,
        'leading_term_counts': leading_hist,
    }


def grobner_fingerprint_report(field, coeffs: Sequence[int], monomials: Sequence[Exp], max_degree: int = 5):
    n_vars = len(monomials[0])
    gens = jacobian_generators(field, coeffs, monomials)
    if not gens:
        return {
            'applicable': False,
            'risk': 'HIGH',
            'reason': 'zero_jacobian',
        }
    qhf = quotient_hilbert_function(field, gens, n_vars, max_degree=max_degree)
    hf = qhf['hilbert_function']
    lead = qhf['leading_term_counts']
    cumulative = [int(sum(hf[:i + 1])) for i in range(len(hf))]
    growth = [hf[i + 1] - hf[i] for i in range(len(hf) - 1)]
    flat_tail = 0
    for i in range(len(growth) - 1, -1, -1):
        if growth[i] == 0:
            flat_tail += 1
        else:
            break
    support_spread = int(sum(lead))
    low_degree_mass = int(sum(hf[: min(4, len(hf))]))
    syzygy_proxy = int(sum(max(0, hf[i] - hf[i + 1]) for i in range(len(hf) - 1)))
    risk_score = 0.0
    risk_score += 1.5 * max(0, low_degree_mass - 8)
    risk_score += 2.0 * max(0, cumulative[-1] - 18)
    risk_score += 2.5 * max(0, flat_tail - 1)
    risk_score += 1.0 * max(0, syzygy_proxy - 1)
    risk_score -= 0.2 * min(support_spread, 20)
    if risk_score >= 18:
        risk = 'HIGH'
    elif risk_score >= 8:
        risk = 'MEDIUM'
    else:
        risk = 'LOW'
    return {
        'applicable': True,
        'n_jacobian_generators': len(gens),
        'hilbert_function': hf,
        'ideal_ranks': qhf['ideal_ranks'],
        'leading_term_counts': lead,
        'cumulative_quotient_dims': cumulative,
        'growth': growth,
        'flat_tail': int(flat_tail),
        'low_degree_mass': low_degree_mass,
        'support_spread': support_spread,
        'syzygy_proxy': syzygy_proxy,
        'fingerprint': tuple(hf + lead),
        'risk_score': float(round(risk_score, 4)),
        'risk': risk,
    }
