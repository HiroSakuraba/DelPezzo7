"""Wrapper for the compiled GF(9) visible-part critical-locus scanner."""
from __future__ import annotations
from pathlib import Path
from typing import Dict, Optional
import subprocess
ROOT = Path(__file__).resolve().parents[1]
COMPILED = ROOT / "compiled"

def run_f9_visible_scan(mode: str, input_path: str | Path | None = None, timeout: Optional[int] = None) -> Dict[str, object]:
    cmd = [str(COMPILED / "f9_visible_scan"), mode]
    if mode != "order" and input_path is not None:
        cmd.append(str(Path(input_path).resolve()))
    proc = subprocess.run(cmd, cwd=str(COMPILED), capture_output=True, text=True, timeout=timeout)
    return {"returncode": proc.returncode, "stdout": proc.stdout, "stderr": proc.stderr, "cmd": cmd}
