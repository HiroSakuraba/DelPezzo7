"""
circuit_signature.py — refined circuit / dependency profile for projective point sets.

This is a stricter combinatorial layer than the coarse matroid screen.  It records
minimal dependent subsets, how they cluster, and whether the dependence structure
is concentrated around a small core of points or pairs.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from itertools import combinations
from typing import Sequence

from .projective_geometry import projective_span_rank


def _subset_vector_rank(field, points: Sequence[Sequence[int]]) -> int:
    return projective_span_rank(field, points)


def minimal_circuits(field, points: Sequence[Sequence[int]], max_size: int | None = None):
    """Return minimal dependent subsets as tuples of point indices.

    For projective points represented by homogeneous vectors, a subset is dependent
    when the vector rank is strictly less than the subset size.  A circuit is a
    minimal dependent subset.
    """
    n = len(points)
    if n == 0:
        return []
    ambient_rank = min(len(points[0]), n)
    if max_size is None:
        max_size = min(ambient_rank + 1, n)
    max_size = max(3, min(int(max_size), n))
    circuits = []
    for size in range(3, max_size + 1):
        for idxs in combinations(range(n), size):
            subset = [points[i] for i in idxs]
            if _subset_vector_rank(field, subset) >= size:
                continue
            minimal = True
            for j in range(size):
                subidx = idxs[:j] + idxs[j + 1:]
                if _subset_vector_rank(field, [points[i] for i in subidx]) < size - 1:
                    minimal = False
                    break
            if minimal:
                circuits.append(tuple(idxs))
    return circuits


def circuit_signature_report(field, points: Sequence[Sequence[int]], max_size: int | None = None):
    n = len(points)
    if n == 0:
        return {
            'applicable': False,
            'risk': 'HIGH',
            'reason': 'empty point set',
        }
    circuits = minimal_circuits(field, points, max_size=max_size)
    size_counts = Counter(len(c) for c in circuits)
    point_load = Counter()
    pair_load = Counter()
    for C in circuits:
        for i in C:
            point_load[i] += 1
        for p in combinations(C, 2):
            pair_load[p] += 1
    max_point_load = max(point_load.values(), default=0)
    max_pair_load = max(pair_load.values(), default=0)
    avg_circuit_size = (sum(len(C) for C in circuits) / len(circuits)) if circuits else 0.0
    support_density = (sum(size_counts.values()) / max(1, n))
    cluster_concentration = max_point_load / max(1, len(circuits)) if circuits else 0.0
    shared_edge_density = sum(1 for v in pair_load.values() if v >= 2) / max(1, len(pair_load)) if pair_load else 0.0
    line_circuits = int(size_counts.get(3, 0))
    plane_circuits = int(size_counts.get(4, 0))
    high_order_circuits = int(sum(v for k, v in size_counts.items() if k >= 5))

    risk_score = 0.0
    risk_score += 1.5 * line_circuits
    risk_score += 2.5 * plane_circuits
    risk_score += 4.0 * high_order_circuits
    risk_score += 3.0 * max(0, max_point_load - 1)
    risk_score += 4.0 * max(0.0, 5.0 * shared_edge_density - 1.0)
    risk_score += 6.0 * max(0.0, 4.0 * cluster_concentration - 1.0)
    if len(circuits) == 0:
        risk = 'LOW'
    elif risk_score >= 16:
        risk = 'HIGH'
    elif risk_score >= 7:
        risk = 'MEDIUM'
    else:
        risk = 'LOW'
    return {
        'applicable': True,
        'n_points': n,
        'n_circuits': len(circuits),
        'size_counts': {int(k): int(v) for k, v in sorted(size_counts.items())},
        'line_circuits': line_circuits,
        'plane_circuits': plane_circuits,
        'high_order_circuits': high_order_circuits,
        'max_point_load': int(max_point_load),
        'max_pair_load': int(max_pair_load),
        'avg_circuit_size': float(avg_circuit_size),
        'support_density': float(support_density),
        'cluster_concentration': float(cluster_concentration),
        'shared_edge_density': float(shared_edge_density),
        'risk_score': float(round(risk_score, 4)),
        'risk': risk,
        'circuits': circuits[:32],
    }
