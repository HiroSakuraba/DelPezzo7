"""
constraint_solver.py — local existence / nonexistence solver on a fixed singularity family.

This tool works inside one kernel family.  It can exhaustively enumerate small kernels
and otherwise run a structured beam/random search over kernel combinations.
"""
from __future__ import annotations

from itertools import combinations, product
from typing import Sequence

import numpy as np

from .projective_geometry import homogeneous_monomials, no_linear_factor, singularity_constraint_matrix, uses_all_vars
from .symbolic_restriction import section_health_check, symbolic_anticollapse_report


def _combine(field, basis, combo):
    out = np.zeros(len(basis[0]), dtype=np.int16)
    for a, b in zip(combo, basis):
        aa = int(a) % field.q
        if aa == 0:
            continue
        out = (out + aa * np.array(b, dtype=np.int16)) % field.q
    return out % field.q


def _enumerate_combos(field, dim: int, max_states: int, seed: int = 0):
    total = (field.q ** dim) - 1
    if total <= max_states:
        combos = [c for c in product(range(field.q), repeat=dim) if any(c)]
        combos.sort(key=lambda c: (sum(1 for x in c if x == 0), -sum(1 for x in c if x != 0), c))
        return combos, True
    rng = np.random.default_rng(seed)
    combos = []
    seen = set()
    for w in range(2, min(dim, 4) + 1):
        for idxs in combinations(range(dim), w):
            for vals in product((1, 2), repeat=w):
                c = [0] * dim
                for i, v in zip(idxs, vals):
                    c[i] = v
                t = tuple(c)
                if t not in seen:
                    seen.add(t)
                    combos.append(t)
                    if len(combos) >= max_states:
                        return combos, False
    while len(combos) < max_states:
        c = tuple(int(x) for x in rng.integers(0, field.q, size=dim))
        if any(c) and c not in seen:
            seen.add(c)
            combos.append(c)
    return combos, False


def _candidate_score(field, coeffs, monomials, hyperplane=None):
    score = 0.0
    if uses_all_vars(coeffs, monomials):
        score += 10.0
    else:
        score -= 20.0
    if no_linear_factor(field, coeffs, monomials):
        score += 12.0
    else:
        score -= 25.0
    anti = None
    if hyperplane is not None:
        health = section_health_check(field, coeffs, monomials, hyperplane)
        anti = symbolic_anticollapse_report(field, coeffs, monomials, hyperplane, health=health)
        score += float(anti.get('symbolic_anticollapse_score', 0)) / 5.0
        score -= {'LOW': 0.0, 'MEDIUM': 10.0, 'HIGH': 25.0}.get(anti.get('collapse_risk', 'HIGH'), 25.0)
        if health.get('status') == 'DEGENERATE':
            score -= 30.0
    return score, anti


def solve_kernel_constraints(field, points: Sequence[Sequence[int]], degree: int = 3, hyperplane: Sequence[int] | None = None, max_states: int = 1500, max_solutions: int = 8, seed: int = 0):
    monomials = homogeneous_monomials(len(points[0]), degree)
    M = singularity_constraint_matrix(field, points, monomials)
    basis = field.kernel(M)
    dim = len(basis)
    rep = {
        'applicable': True,
        'degree': int(degree),
        'kernel_dimension': int(dim),
        'searched_states': 0,
        'exhaustive': False,
        'feasible_count': 0,
        'best_score': None,
        'best_combo': None,
        'solutions': [],
        'infeasibility_hint': None,
    }
    if dim == 0:
        rep['infeasibility_hint'] = 'zero_kernel'
        return rep
    combos, exhaustive = _enumerate_combos(field, dim, max_states=max_states, seed=seed)
    rep['exhaustive'] = exhaustive
    best_score = -1e18
    best_combo = None
    for combo in combos:
        rep['searched_states'] += 1
        coeffs = _combine(field, basis, combo)
        score, anti = _candidate_score(field, coeffs, monomials, hyperplane=hyperplane)
        if score > best_score:
            best_score = score
            best_combo = tuple(int(x) for x in combo)
        feasible = uses_all_vars(coeffs, monomials) and no_linear_factor(field, coeffs, monomials)
        if feasible and hyperplane is not None:
            feasible = anti is not None and anti.get('collapse_risk') != 'HIGH'
        if feasible:
            rep['feasible_count'] += 1
            if len(rep['solutions']) < max_solutions:
                rep['solutions'].append({
                    'combo': tuple(int(x) for x in combo),
                    'score': float(round(score, 4)),
                    'anti_collapse_score': None if anti is None else anti.get('symbolic_anticollapse_score'),
                    'collapse_risk': None if anti is None else anti.get('collapse_risk'),
                })
    rep['best_score'] = None if best_combo is None else float(round(best_score, 4))
    rep['best_combo'] = best_combo
    if rep['feasible_count'] == 0:
        rep['infeasibility_hint'] = 'searched_no_feasible_combo'
    elif exhaustive:
        rep['infeasibility_hint'] = 'feasible_combo_exists'
    return rep
