"""
picard_verifier.py — Picard number verification for del Pezzo surface candidates.

Wraps the compiled picard_count binary to:
  1. Count points over F_9 and F_81
  2. Compute Frobenius traces s_1, s_2
  3. Classify singularity types via Hessian rank
  4. Bound the geometric Picard number

For a surface X/F_q with b_2 eigenvalues of Frobenius on H^2_et:
  #X(F_{q^n}) = 1 + s_n + q^{2n}
  s_n = sum of n-th powers of eigenvalues alpha_i
  |alpha_i| = q (Weil conjecture / Deligne's theorem)

Picard number rho = # eigenvalues that are q * (root of unity).
For surfaces over finite fields, rho = # eigenvalues equal to +-q
(Tate conjecture, proved for surfaces by Tate).

Singular surfaces: if X has r isolated A_1 nodes, then H^2_et(X)
may differ from H^2_et(Y) where Y is the minimal resolution.
The point count applies to X, not Y.  The verifier reports the raw
Frobenius data and leaves interpretation to the user.
"""
from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path
from typing import Dict, List, Optional, Tuple

ROOT = Path(__file__).resolve().parents[1]
COMPILED = ROOT / "compiled"
PICARD_BIN = COMPILED / "picard_count"
DELPEZ_BIN = COMPILED / "delpez_engine"


def _build_if_needed():
    if not PICARD_BIN.exists():
        subprocess.run(["bash", str(COMPILED / "build.sh")],
                       cwd=str(COMPILED), capture_output=True)


def run_picard_count(mode: str, coeffs: List[int],
                     coeffs2: Optional[List[int]] = None,
                     timeout: int = 60) -> Dict:
    """Run picard_count binary and parse JSON output.

    mode: 'ci22' or 'cubic'
    coeffs: GF(9) coefficient vector (15 for quadric, 20 for cubic)
    coeffs2: second quadric for CI(2,2) mode
    """
    _build_if_needed()
    cmd = [str(PICARD_BIN), mode] + [str(c) for c in coeffs]
    if mode == "ci22" and coeffs2 is not None:
        cmd += [str(c) for c in coeffs2]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True,
                              timeout=timeout, cwd=str(COMPILED))
        if proc.returncode != 0:
            return {"ok": False, "error": proc.stderr.strip(),
                    "returncode": proc.returncode}
        data = json.loads(proc.stdout)
        data["ok"] = True
        _annotate(data)
        return data
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "timeout"}
    except json.JSONDecodeError as e:
        return {"ok": False, "error": f"JSON parse: {e}"}


def _singularities_isolated(d: Dict) -> bool:
    """Check if singular locus is 0-dimensional via field extension behavior.

    For isolated singularities defined over F_q:
      #Sing(F_{q^2}) = #Sing(F_q) + 2*(number of conjugate pairs over F_{q^2}\\F_q)
    So #Sing(F_{q^2}) - #Sing(F_q) is even and moderate.

    For a 1-dimensional singular locus (e.g. a line):
      #Sing(F_{q^2}) ~ q * #Sing(F_q)   (grows linearly in q)

    Threshold: flag as non-isolated if nsing_f81 > 3 * nsing_f9 + 10.
    """
    ns9 = d.get("nsing_f9", 0)
    ns81 = d.get("nsing_f81", 0)
    if ns9 == 0:
        return ns81 == 0
    return ns81 <= 3 * ns9 + 10


def _annotate(d: Dict):
    """Add derived Picard-number annotations to raw picard_count output."""
    q = d.get("q", 9)
    s1, s2 = d.get("s1", 0), d.get("s2", 0)
    b2 = d.get("b2", 6)
    ns = d.get("nsing_f9", 0)

    # Weil bound: |s1| <= b2 * q for a smooth surface with that b2.
    # If |s1| > b2*q, the surface has larger H^2 (from singularity resolution).
    weil_bound = b2 * q
    s1_exceeds_smooth_bound = abs(s1) > weil_bound

    # For a smooth degree-d del Pezzo: s1 = q*rho + (sum of non-algebraic eigenvalues)
    # where non-algebraic eigenvalues have |alpha| = q but alpha/q is not a root of unity.
    # Exact rho=1 check: s1 = +-q and s2 = q^2 (one eigenvalue = +-q, rest cancel in pairs)
    # For b2=6: rho=1 → one eigenvalue q, five others pair off.
    # Newton's identities: if exactly r eigenvalues = q, rest = alpha_i with sum sigma:
    #   s1 = r*q + sigma, s2 = r*q^2 + sum(alpha_i^2)
    # By Weil: |sigma| <= (b2-r)*q, |sum(alpha_i^2)| <= (b2-r)*q^2

    # Simple rho=1 consistency check for SMOOTH surfaces:
    # s1 = q + sigma where |sigma| <= (b2-1)*q
    # s2 = q^2 + sum(a_i^2) where |sum(a_i^2)| <= (b2-1)*q^2
    rho1_s1_consistent = (abs(s1 - q) <= (b2-1)*q) or (abs(s1 + q) <= (b2-1)*q)

    # Tighter: if rho=1 with eigenvalue +q:
    #   s1-q = sigma, s2-q^2 = sum(a_i^2)
    #   Newton: sigma^2 - sum(a_i^2) = 2*e2(remaining)
    #   For 5 remaining eigenvalues (b2=6): |e2| <= C(5,2)*q^2 = 10*q^2
    # Similarly for eigenvalue -q.

    # Best integer rho estimate from s1:
    # If all rho eigenvalues = +q: s1 = rho*q + sigma, |sigma| <= (b2-rho)*q
    # → |s1 - rho*q| <= (b2-rho)*q → s1/q - rho in [-(b2-rho), b2-rho]
    # → rho in [max(0, ceil((s1/q-b2+1)/2)), ... ]
    # For now, report s1/q directly.
    s1_over_q = s1 / q  # float
    s2_over_q2 = s2 / (q*q)

    # Singularity classification
    hess = d.get("sing_hessian_ranks", [])
    n_a1 = d.get("a1_singularities", 0)
    n_worse = d.get("worse_singularities", 0)
    all_a1 = (n_a1 == ns and n_worse == 0) if ns > 0 else True
    # For A_1 nodes: resolution adds 1 to rho per node.
    # So rho(resolution) = rho(X) + n_a1 (approximately, for RDP).
    # And b_2(resolution) = b_2(smooth model) + n_a1.

    # Practical ρ=1 filter for singular surfaces:
    # Very unlikely if |s1| > 2*q (since rho(X)=1 means one eigenvalue ±q
    # and the rest live in a smaller H^2 for the singular surface).
    # The definitive answer needs the full charpoly, but this is a strong filter.

    d["annotations"] = {
        "s1_over_q": round(s1_over_q, 4),
        "s2_over_q2": round(s2_over_q2, 4),
        "weil_smooth_bound": weil_bound,
        "s1_exceeds_smooth_bound": s1_exceeds_smooth_bound,
        "rho1_s1_consistent": rho1_s1_consistent,
        "all_a1_singularities": all_a1,
        "resolution_b2_estimate": b2 + n_a1,
        "local_a1_only": all_a1,
        "klt": all_a1 and _singularities_isolated(d),
        "singularities_isolated": _singularities_isolated(d),
        "summary": _summary_string(d, s1_over_q, s1_exceeds_smooth_bound,
                                    all_a1, n_a1, ns),
    }


def _summary_string(d, s1q, exceeds, all_a1, n_a1, ns):
    parts = []
    isolated = _singularities_isolated(d)
    if ns == 0:
        parts.append("smooth")
    else:
        parts.append(f"{ns} sing ({n_a1} A1" +
                     (f", {ns-n_a1} worse" if ns > n_a1 else "") + ")")
        if not isolated:
            ns81 = d.get("nsing_f81", 0)
            parts.append(f"NON-ISOLATED (nsing_f81={ns81})")
    parts.append(f"s1/q={s1q:.1f}")
    if exceeds:
        parts.append("EXCEEDS smooth Weil bound")
    if abs(s1q - 1) < 0.01 or abs(s1q + 1) < 0.01:
        parts.append("rho=1 CANDIDATE")
    elif abs(s1q - round(s1q)) < 0.01 and abs(s1q) <= 6:
        parts.append(f"rho~{abs(round(s1q))} candidate")
    if all_a1 and ns > 0:
        if isolated:
            parts.append("all klt")
        else:
            parts.append("all A1 local types (not isolated)")
    return "; ".join(parts)


# ═══════════════════ DELPEZ HIT PARSING ═══════════════════

PAT_CI22 = re.compile(
    r"t(\d+): CI\(2,2\) (\d+)sing/(\d+)pts s1=([-\d]+) c_f9=(\d+) kdim=(\d+)")
PAT_CI22_Q1 = re.compile(r"^\s+Q1:([\s\d]+)$", re.MULTILINE)
PAT_CI22_Q2 = re.compile(r"^\s+Q2:([\s\d]+)$", re.MULTILINE)

PAT_CUBIC = re.compile(
    r"t(\d+): (\d+)sing c_f3=(\d+) c_f9=(\d+) s1=([-\d]+) rho_diff~(\d+) kdim=(\d+)")
PAT_CUBIC_F = re.compile(r"^\s+F:([\s\d]+)$", re.MULTILINE)


def parse_delpez_hits(stdout: str, mode: int) -> List[Dict]:
    """Parse delpez_engine output into structured hits with coefficient vectors."""
    lines = stdout.split("\n")
    hits = []

    if mode == 2:  # CI(2,2)
        i = 0
        while i < len(lines):
            m = PAT_CI22.search(lines[i])
            if m:
                hit = {
                    "trial": int(m.group(1)),
                    "singular_count": int(m.group(2)),
                    "point_count_f9": int(m.group(3)),
                    "s1": int(m.group(4)),
                    "c_f9": int(m.group(5)),
                    "kernel_dimension": int(m.group(6)),
                }
                # Look for Q1/Q2 on next lines
                if i+1 < len(lines):
                    mq1 = PAT_CI22_Q1.match(lines[i+1])
                    if mq1:
                        hit["Q1"] = [int(x) for x in mq1.group(1).split()]
                if i+2 < len(lines):
                    mq2 = PAT_CI22_Q2.match(lines[i+2])
                    if mq2:
                        hit["Q2"] = [int(x) for x in mq2.group(1).split()]
                hits.append(hit)
            i += 1

    elif mode == 1:  # cubic
        i = 0
        while i < len(lines):
            m = PAT_CUBIC.search(lines[i])
            if m:
                hit = {
                    "trial": int(m.group(1)),
                    "singular_count": int(m.group(2)),
                    "point_count_f3": int(m.group(3)),
                    "point_count_f9": int(m.group(4)),
                    "s1": int(m.group(5)),
                    "rho_diff_estimate": int(m.group(6)),
                    "kernel_dimension": int(m.group(7)),
                }
                if i+1 < len(lines):
                    mf = PAT_CUBIC_F.match(lines[i+1])
                    if mf:
                        hit["F"] = [int(x) for x in mf.group(1).split()]
                hits.append(hit)
            i += 1

    return hits


def verify_hit(hit: Dict, mode: int, timeout: int = 60) -> Dict:
    """Run picard_count on a parsed hit and return annotated result."""
    if mode == 2:
        q1 = hit.get("Q1")
        q2 = hit.get("Q2")
        if not q1 or not q2:
            return {"ok": False, "error": "missing Q1/Q2 coefficients"}
        return run_picard_count("ci22", q1, q2, timeout=timeout)
    elif mode == 1:
        f = hit.get("F")
        if not f:
            return {"ok": False, "error": "missing F coefficients"}
        return run_picard_count("cubic", f, timeout=timeout)
    return {"ok": False, "error": f"unknown mode {mode}"}


def search_and_verify(mode: int, seed: int = 42, max_trials: int = 20,
                      verify_top: int = 3, engine_timeout: int = 30,
                      picard_timeout: int = 60) -> Dict:
    """Run delpez_engine, parse hits, verify top candidates with picard_count.

    Returns a report with all hits and picard verification of the top ones.
    """
    _build_if_needed()
    # Run the search engine
    proc = subprocess.run(
        [str(DELPEZ_BIN), str(mode), str(seed), str(max_trials)],
        capture_output=True, text=True, timeout=engine_timeout,
        cwd=str(COMPILED))
    if proc.returncode != 0:
        return {"ok": False, "error": proc.stderr.strip()}

    hits = parse_delpez_hits(proc.stdout, mode)
    if not hits:
        return {"ok": True, "hits": [], "verified": [], "summary": "no hits"}

    # Deduplicate by family signature
    seen = set()
    unique_hits = []
    for h in hits:
        if mode == 2:
            sig = (h["singular_count"], h["point_count_f9"])
        else:
            sig = (h["singular_count"], h.get("point_count_f3", 0), h["point_count_f9"])
        if sig not in seen:
            seen.add(sig)
            unique_hits.append(h)

    # Sort: prefer low |s1/q|, then more singularities
    q = 9
    unique_hits.sort(key=lambda h: (abs(h["s1"]/q), -h["singular_count"]))

    # Verify top candidates
    verified = []
    for h in unique_hits[:verify_top]:
        v = verify_hit(h, mode, timeout=picard_timeout)
        verified.append({"hit": h, "picard": v})

    return {
        "ok": True,
        "mode": mode,
        "seed": seed,
        "total_hits": len(hits),
        "unique_families": len(unique_hits),
        "hits": unique_hits,
        "verified": verified,
    }
