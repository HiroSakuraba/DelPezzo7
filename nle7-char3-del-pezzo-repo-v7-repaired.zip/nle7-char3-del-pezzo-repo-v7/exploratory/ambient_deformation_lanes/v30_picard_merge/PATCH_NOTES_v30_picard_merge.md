# v30 Picard merge

- merged `picard_count.c` and `scripts/picard_verifier.py` into the current v29 tree
- build now emits `compiled/picard_count`
- `scripts/f9_verify_shortlist.py` can run Picard verification on locally KLT visible-part survivors
- fixed verifier summary language so non-isolated A1 families are no longer labeled `all klt`
- added `examples/run_v30_picard_merge_demo.py`
- added `tests/test_picard_verifier.py`
