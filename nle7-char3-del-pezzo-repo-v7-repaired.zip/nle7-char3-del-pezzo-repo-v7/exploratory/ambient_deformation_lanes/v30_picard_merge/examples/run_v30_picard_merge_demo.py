from __future__ import annotations
import json
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.picard_verifier import search_and_verify
from scripts.f9_verify_shortlist import load_place_rows, verify_rows

out = {}
out["ci22_demo"] = search_and_verify(2, seed=42, max_trials=8, verify_top=2, engine_timeout=30, picard_timeout=60)
out["cubic_demo"] = search_and_verify(1, seed=42, max_trials=8, verify_top=2, engine_timeout=30, picard_timeout=60)
base = Path(__file__).resolve().parent
visible = base / 'visible_shortlist_1500001_1800000_v29.json'
if visible.exists():
    rows = load_place_rows(visible)
    out["visible_demo"] = verify_rows(rows, top_n=min(10, len(rows)), picard_limit=2)
out_json = base / 'picard_merge_demo_v30.json'
out_md = base / 'picard_merge_demo_v30.md'
out_json.write_text(json.dumps(out, indent=2))
with out_md.open('w', encoding='utf-8') as fh:
    fh.write('# Picard merge demo v30\n\n')
    for key, val in out.items():
        fh.write(f'## {key}\n')
        if isinstance(val, dict) and val.get('ok') is False:
            fh.write(f"- error: {val.get('error')}\n\n")
            continue
        if key.endswith('_demo') and 'verified' in val:
            fh.write(f"- total_hits: {val.get('total_hits')}\n")
            fh.write(f"- unique_families: {val.get('unique_families')}\n")
            for item in val.get('verified', []):
                pic = item.get('picard', {})
                anns = pic.get('annotations', {}) if isinstance(pic, dict) else {}
                fh.write(f"- family hit: {item.get('hit', {})}\n")
                fh.write(f"  - summary: {anns.get('summary', 'n/a')}\n")
        elif key == 'visible_demo':
            st = val.get('stats', {})
            fh.write(f"- rows_seen: {st.get('rows_seen')}\n")
            fh.write(f"- rows_all_klt: {st.get('rows_all_klt')}\n")
            fh.write(f"- rows_picard_run: {st.get('rows_picard_run')}\n")
            fh.write(f"- rows_picard_ok: {st.get('rows_picard_ok')}\n")
            fh.write(f"- rows_picard_klt: {st.get('rows_picard_klt')}\n")
        fh.write('\n')
print(out_json)
print(out_md)
