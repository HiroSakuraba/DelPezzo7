# v27 visible shortlist demo
- scanned rows: 128
- shortlisted rows: 3
- best line: 73
- best score: 129
- best profile: ncrit_f9=19, ncrit_f3=1, frob_pairs=9, rank_place=3, support_vis=5
- best placement: line=111, place_count=28, coeffs=0,0,0,0
