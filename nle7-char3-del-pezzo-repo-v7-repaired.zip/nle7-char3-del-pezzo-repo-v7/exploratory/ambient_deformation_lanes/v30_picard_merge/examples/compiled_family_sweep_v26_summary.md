# Compiled Family Sweep v26

- seeds: 16
- max_trials_per_seed: 30

## cubic_gf9_compiled
- runs: 16
- total hits: 248
- unique families: 30
- non-dense families: 28
- top family: {'trial': 9, 'singular_count': 28, 'point_count_f3': 10, 'point_count_f9': 244, 's1': 162, 'rho_diff_estimate': 18, 'kernel_dimension': 4, 'hessian_rank3_count': 0, 'hessian_rank2_count': 27, 'hessian_rank1_count': 0, 'hessian_rank0_count': 1, 'family_signature': (28, 10, 244, 4, 0, 27, 0, 1), 'dense_singular_locus': False, 'f3_sparse': False, 'rho1_point_count': False, 'interesting_score': 100, 'hessian_bad_count': 1, 'count': 48}
- top interesting family: {'trial': 13, 'singular_count': 28, 'point_count_f3': 7, 'point_count_f9': 244, 's1': 162, 'rho_diff_estimate': 18, 'kernel_dimension': 4, 'hessian_rank3_count': 0, 'hessian_rank2_count': 27, 'hessian_rank1_count': 0, 'hessian_rank0_count': 1, 'family_signature': (28, 7, 244, 4, 0, 27, 0, 1), 'dense_singular_locus': False, 'f3_sparse': False, 'rho1_point_count': False, 'interesting_score': 106, 'hessian_bad_count': 1, 'count': 7}
- elapsed: 1.93 s

## ci22_gf9_compiled
- runs: 16
- total hits: 441
- unique families: 36
- non-dense families: 36
- top family: {'trial': 6, 'singular_count': 19, 'point_count_f9': 163, 's1': 81, 'c_f9': 163, 'kernel_dimension': 10, 'shared_vanishing_points': 5, 'engine_score': 362, 'family_signature': (19, 163, 10, 5), 'dense_singular_locus': False, 'interesting_score': 110, 'point_window_distance': 0, 'in_point_window': True, 'count': 69}
- top interesting family: {'trial': 6, 'singular_count': 19, 'point_count_f9': 163, 's1': 81, 'c_f9': 163, 'kernel_dimension': 10, 'shared_vanishing_points': 5, 'engine_score': 362, 'family_signature': (19, 163, 10, 5), 'dense_singular_locus': False, 'interesting_score': 110, 'point_window_distance': 0, 'in_point_window': True, 'count': 69}
- elapsed: 18.45 s

