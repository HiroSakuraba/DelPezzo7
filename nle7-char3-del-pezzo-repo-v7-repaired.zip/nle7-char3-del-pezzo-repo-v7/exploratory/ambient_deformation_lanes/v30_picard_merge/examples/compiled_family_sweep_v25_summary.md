# Compiled Family Sweep v25

## cubic_gf9_compiled
- runs: 16
- total hits: 608
- unique families: 89
- non-dense families: 86
- top family: {'trial': 16, 'singular_count': 4, 'point_count_f3': 5, 'point_count_f9': 109, 's1': 27, 'rho_diff_estimate': 3, 'kernel_dimension': 4, 'family_signature': (4, 5, 109, 4), 'dense_singular_locus': False, 'f3_sparse': False, 'rho1_point_count': False, 'interesting_score': 10, 'count': 41}
- top interesting family: {'trial': 17, 'singular_count': 28, 'point_count_f3': 7, 'point_count_f9': 244, 's1': 162, 'rho_diff_estimate': 18, 'kernel_dimension': 4, 'family_signature': (28, 7, 244, 4), 'dense_singular_locus': False, 'f3_sparse': False, 'rho1_point_count': False, 'interesting_score': 126, 'count': 3}
- elapsed: 0.28 s

## ci22_gf9_compiled
- runs: 16
- total hits: 1239
- unique families: 42
- non-dense families: 42
- top family: {'trial': 9, 'singular_count': 19, 'point_count_f9': 163, 's1': 81, 'c_f9': 163, 'kernel_dimension': 11, 'family_signature': (19, 163, 11), 'dense_singular_locus': False, 'interesting_score': 95, 'count': 67}
- top interesting family: {'trial': 9, 'singular_count': 19, 'point_count_f9': 163, 's1': 81, 'c_f9': 163, 'kernel_dimension': 11, 'family_signature': (19, 163, 11), 'dense_singular_locus': False, 'interesting_score': 95, 'count': 67}
- elapsed: 11.08 s

