# v16 tool upgrade ledger

| Current module | Mathematical purpose | Missing capability addressed in v16 |
|---|---|---|
| `combinatorial_screen.py` | Coarse matroid / coding pre-screen on point sets | Could not distinguish isolated dependencies from clustered circuit pathologies |
| `circuit_signature.py` | Refined circuit profile of projective point configurations | Adds minimal-circuit counts, clustering, shared-edge density, and dependence concentration |
| `configuration_search.py` | Kernel probing by testing kernel combinations | Could say “no passing combo sampled,” but not whether a small kernel family is genuinely infeasible under stronger constraints |
| `constraint_solver.py` | Local solver on a fixed singularity family | Adds exhaustive / bounded-search feasibility on the actual kernel family |
| `symbolic_restriction.py` | Anti-collapse screening of restricted sections | Could detect bad sections, but not classify the Jacobian ideal stratum they belong to |
| `grobner_fingerprint.py` | Jacobian-ideal fingerprint from low-degree Macaulay slices | Adds Hilbert / leading-term / flat-tail singular-stratum classification |
| `beam_section_analyzer.py` | Deep section ranking | Now uses Gröbner-style singular-stratum evidence rather than only traces, incidence, and anti-collapse |
| `section_conditioned_search.py` | Proposal generation and scoring | Now sees circuit-level combinatorics and, on small kernels, actual local solver feasibility |

## Priority of the three new tools

1. **`constraint_solver.py`** — highest direct search value
2. **`grobner_fingerprint.py`** — highest late-stage family classification value
3. **`circuit_signature.py`** — highest early combinatorial screen value

## Intended use pattern

- use `circuit_signature.py` before committing to a proposal family,
- use `constraint_solver.py` when a fixed configuration family looks plausible but kernel feasibility is unclear,
- use `grobner_fingerprint.py` on restricted sections that survive symbolic anti-collapse and need stronger classification.


## v17 ports

| current module | mathematical purpose | missing capability |
|---|---|---|
| `compiled/delpez_engine.c` mode 2 | search CI(2,2) del Pezzo surfaces in `P^4/GF(9)` | current constraint model still uses the stronger-than-necessary “both quadrics individually singular” surrogate for many proposals |
| `compiled/cubic_exhaust_f3.c` | exhaustive finite verification of the cubic `F_3` incidence bound | not yet wrapped as a theorem-report artifact generator with structured JSON output |
| `compiled/cubic_dim10_f3.c` | exhaustive verification of the high-kernel-dimension bounded family | not yet fed back into the Python failure prior automatically |
| `compiled/gf9_section_backend.c` | exact compiled restriction of homogeneous 5-variable forms to a hyperplane over `GF(9)` | no compiled point-count / singular-scan companion yet |
| `scripts/two_quadrics_search.py` | Python-facing CI(2,2) lane wrapper | not yet integrated into the strategy controller / multi-lane sweep script |
| `scripts/compiled_backends.py` | build and run compiled accelerators from Python | parser coverage still narrow; only the CI(2,2) hit lines are structured fully |
| `scripts/gf9_restriction_backend.py` | opportunistic compiled backend for exact `GF(9)` restriction | currently supports degrees 2, 3, 4 in 5 variables only |
