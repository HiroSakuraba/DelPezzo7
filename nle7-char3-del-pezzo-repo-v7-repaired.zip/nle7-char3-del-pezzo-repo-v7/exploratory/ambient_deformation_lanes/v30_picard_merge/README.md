# Projective Higher-Dimensional Tools Bundle v16

v16 adds three new structural tools that are meant to do more than rank candidates after the fact.
They are designed to answer three earlier questions directly:

\[
\text{(i) is the point configuration already structurally bad?}
\]
\[
\text{(ii) does the kernel family admit any feasible coefficient vector at all?}
\]
\[
\text{(iii) is the section Jacobian ideal living in a known bad singular stratum?}
\]

## New tools

### 1. `scripts/circuit_signature.py`
A refined combinatorial dependence tool.

It computes minimal dependent subsets (circuits), their size profile, clustering, and concentration around small cores of points or pairs. This is stronger than the earlier coarse matroid screen because it distinguishes:

- isolated low-level dependencies,
- line-heavy configurations,
- plane-heavy configurations,
- and circuit clustering that often precedes symbolic collapse.

Main entry point:

```python
from scripts.circuit_signature import circuit_signature_report
rep = circuit_signature_report(F, points_in_p3)
```

Important fields:

- `n_circuits`
- `size_counts`
- `max_point_load`
- `shared_edge_density`
- `risk`

### 2. `scripts/constraint_solver.py`
A local existence / nonexistence solver on one singularity family.

For a fixed point set, it builds the kernel of the singularity constraint matrix and then searches actual linear combinations of the kernel basis, not just the basis vectors themselves. It can run exhaustively on small kernels and uses a structured finite search on larger ones.

Main entry point:

```python
from scripts.constraint_solver import solve_kernel_constraints
rep = solve_kernel_constraints(F, points, degree=3, hyperplane=H)
```

This is the first tool in the stack that can say something sharper than “we sampled and found nothing.”
For small kernels it can certify that no feasible combo was found in the entire searched kernel.

Important fields:

- `kernel_dimension`
- `searched_states`
- `exhaustive`
- `feasible_count`
- `best_score`
- `infeasibility_hint`

### 3. `scripts/grobner_fingerprint.py`
A Jacobian-ideal fingerprint tool.

This is not a full Gröbner basis engine. Instead it computes low-degree Macaulay slices of the Jacobian ideal, then records a compact fingerprint:

- low-degree quotient Hilbert data,
- low-degree ideal ranks,
- leading-term counts,
- flat-tail / saturation behavior,
- and a singular-stratum risk score.

Main entry point:

```python
from scripts.grobner_fingerprint import grobner_fingerprint_report
rep = grobner_fingerprint_report(F, coeffs, monomials)
```

Important fields:

- `hilbert_function`
- `ideal_ranks`
- `leading_term_counts`
- `flat_tail`
- `low_degree_mass`
- `risk`

## Where v16 integrates them

### Proposal layer
`SectionConditionedSearch` now records:

- `circuit_report`
- `constraint_solver_report`
- alongside the existing
  - `matroid_report`
  - `coding_report`
  - `restricted_kernel_report`

The circuit signature is used in proposal scoring. The constraint solver is used selectively on small kernel families, where it can give an actual feasibility signal.

### Deep section analysis
`beam_section_analyzer.py` now computes:

- `grobner_fingerprint`

for the restricted section, and uses that in the final deep section quality score.

## Quick start

Run:

```bash
python tests/smoke_test.py
python examples/run_v16_tooling_demo.py
```

Generated demo artifacts:

- `examples/v16_tooling_demo.json`
- `examples/v16_tooling_demo.md`

## Practical interpretation

These three tools play different roles:

- `circuit_signature.py` is an **early structural screen**
- `constraint_solver.py` is a **local existence / nonexistence probe**
- `grobner_fingerprint.py` is a **family-stratum classifier** for restricted sections

That division is deliberate. They are meant to reduce wasted search in different ways rather than duplicating one another.


## v17 compiled ports

This revision ports three concrete items from the external pipeline into this stack:

1. **Two quadrics in `P^4` over `GF(9)`** as a real del Pezzo `K^2=4` search lane.
   - wrapper: `scripts/two_quadrics_search.py`
   - backend: `compiled/delpez_engine.c` mode `2`

2. **Compiled exhaustive `F_3` proof engines** for bounded finite verification.
   - `compiled/cubic_exhaust_f3.c`
   - `compiled/cubic_dim10_f3.c`
   - Python wrapper: `scripts/compiled_backends.py`

3. **Exact `GF(9)` hyperplane-restriction backend**.
   - shared library: `compiled/gf9_section_backend.c`
   - Python wrapper: `scripts/gf9_restriction_backend.py`
   - integrated automatically into `scripts/symbolic_restriction.py` when the field is `GF(9)` and the polynomial is homogeneous in 5 variables of degree 2, 3, or 4.

### Build

Run:

```bash
bash compiled/build.sh
```

This produces:
- `compiled/cubic_exhaust_f3`
- `compiled/cubic_dim10_f3`
- `compiled/delpez_engine`
- `compiled/libgf9_section_backend.so`

### Notes

- The CI(2,2) lane is intentionally exposed as a separate search wrapper rather than forced through the generic `SectionConditionedSearch` machinery, because it is a different geometric object than the hypersurface-section lanes.
- The exhaustive proof engines are ported as optional accelerators and bounded theorem-support tools. They are not run automatically in routine candidate sweeps.
- The compiled GF(9) restriction backend is exact and used opportunistically; the pure-Python exact restriction remains the fallback.
