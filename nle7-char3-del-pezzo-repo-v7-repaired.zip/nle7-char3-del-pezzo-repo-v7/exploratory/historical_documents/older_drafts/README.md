# Older draft documents

This directory preserves older papers and handoff-style documents for provenance and future AI-agent clarity.

These files are useful for:
- historical context,
- matroid/coding-theoretic exposition,
- quartic/K3 sandbox background,
- earlier search-lane strategy.

They are not theorem dependencies for the final `N \le 7` paper unless explicitly cited there.

See `../../../docs/HISTORICAL_DOCUMENTS_INDEX.md` for file-by-file guidance.
