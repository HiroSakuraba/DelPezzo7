# Family-wide cone audit for the explicit v58 two-point torsor branch

We audited the **entire explicit nonsplit two-point torsor family** from v58, not just the `(1,0,2)` representative.

## Summary

- models scanned: 6
- all homogeneous degree 3 at the chart singularities: True
- all affine cones in ordinary weights: True
- all exceptional cubics smooth: True
- all local total-space singularities simple-elliptic read: True
- any local total-space singularity klt in this audit: False

## Representative rows

### (alpha,beta,gamma)=(1,0,2)

- torsor model: `t*y^2 = x^3 + t*x^2 + 2*t^3`
- projective cone: `T*Y^2 = X^3 + 1*T*X^2 + 0*T^2*X + 2*T^3`
- smooth exceptional cubic over F3: `True`
- F3-point count on exceptional cubic: `6`
- singular F3-points on exceptional cubic: `[]`
- local type read: Affine cone over a smooth plane cubic; equivalently a simple elliptic surface singularity of cubic-cone type (analytically an elliptic cone / tilde-E6 type in the classical classification).
- klt read: Not klt as a local total-space singularity: simple elliptic surface singularities are minimally elliptic / log-canonical type rather than klt.

### (alpha,beta,gamma)=(1,1,2)

- torsor model: `t*y^2 = x^3 + t*x^2 + t^2*x + 2*t^3`
- projective cone: `T*Y^2 = X^3 + 1*T*X^2 + 1*T^2*X + 2*T^3`
- smooth exceptional cubic over F3: `True`
- F3-point count on exceptional cubic: `6`
- singular F3-points on exceptional cubic: `[]`
- local type read: Affine cone over a smooth plane cubic; equivalently a simple elliptic surface singularity of cubic-cone type (analytically an elliptic cone / tilde-E6 type in the classical classification).
- klt read: Not klt as a local total-space singularity: simple elliptic surface singularities are minimally elliptic / log-canonical type rather than klt.

### (alpha,beta,gamma)=(1,2,1)

- torsor model: `t*y^2 = x^3 + t*x^2 + 2*t^2*x + t^3`
- projective cone: `T*Y^2 = X^3 + 1*T*X^2 + 2*T^2*X + 1*T^3`
- smooth exceptional cubic over F3: `True`
- F3-point count on exceptional cubic: `6`
- singular F3-points on exceptional cubic: `[]`
- local type read: Affine cone over a smooth plane cubic; equivalently a simple elliptic surface singularity of cubic-cone type (analytically an elliptic cone / tilde-E6 type in the classical classification).
- klt read: Not klt as a local total-space singularity: simple elliptic surface singularities are minimally elliptic / log-canonical type rather than klt.

### (alpha,beta,gamma)=(2,0,1)

- torsor model: `t*y^2 = x^3 + 2*t*x^2 + t^3`
- projective cone: `T*Y^2 = X^3 + 2*T*X^2 + 0*T^2*X + 1*T^3`
- smooth exceptional cubic over F3: `True`
- F3-point count on exceptional cubic: `10`
- singular F3-points on exceptional cubic: `[]`
- local type read: Affine cone over a smooth plane cubic; equivalently a simple elliptic surface singularity of cubic-cone type (analytically an elliptic cone / tilde-E6 type in the classical classification).
- klt read: Not klt as a local total-space singularity: simple elliptic surface singularities are minimally elliptic / log-canonical type rather than klt.

### (alpha,beta,gamma)=(2,1,1)

- torsor model: `t*y^2 = x^3 + 2*t*x^2 + t^2*x + t^3`
- projective cone: `T*Y^2 = X^3 + 2*T*X^2 + 1*T^2*X + 1*T^3`
- smooth exceptional cubic over F3: `True`
- F3-point count on exceptional cubic: `10`
- singular F3-points on exceptional cubic: `[]`
- local type read: Affine cone over a smooth plane cubic; equivalently a simple elliptic surface singularity of cubic-cone type (analytically an elliptic cone / tilde-E6 type in the classical classification).
- klt read: Not klt as a local total-space singularity: simple elliptic surface singularities are minimally elliptic / log-canonical type rather than klt.

### (alpha,beta,gamma)=(2,2,2)

- torsor model: `t*y^2 = x^3 + 2*t*x^2 + 2*t^2*x + 2*t^3`
- projective cone: `T*Y^2 = X^3 + 2*T*X^2 + 2*T^2*X + 2*T^3`
- smooth exceptional cubic over F3: `True`
- F3-point count on exceptional cubic: `10`
- singular F3-points on exceptional cubic: `[]`
- local type read: Affine cone over a smooth plane cubic; equivalently a simple elliptic surface singularity of cubic-cone type (analytically an elliptic cone / tilde-E6 type in the classical classification).
- klt read: Not klt as a local total-space singularity: simple elliptic surface singularities are minimally elliptic / log-canonical type rather than klt.

## Bottom line

Every explicit nonsplit two-point torsor model in the v58 normalized family has local chart singularities that are affine cones over smooth plane cubics. So the explicit v58 branch, as currently realized, consists of simple elliptic total-space singularities rather than klt/rational-double-point type singularities.

So the explicit `I0* + I0*` torsor branch still survives as a **Jacobian/torsor mechanism**, but the specific normalized v58 total-space family is not already a klt del Pezzo model. Any successful theorem path now needs a genuinely different birational model of the same data, or this explicit branch must be abandoned.