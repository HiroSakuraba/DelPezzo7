# v100 Aristotle audit patch

This note records the one local correction made after the external Aristotle audit of paper draft v7.

## Corrected exotic-chain root data

For the exotic baskets in the standard normal forms:
- `7A1 + 1/7(1,1)`: orthogonal real-root subsystem `A7`, `56` roots, maximal pairwise orthogonal size `4`.
- `7A1 + 1/7(1,2)`: orthogonal real-root set has `48` roots, maximal pairwise orthogonal size `4`.
- `7A1 + 1/11(1,2)`: orthogonal real-root set has `32` roots, maximal pairwise orthogonal size `4`.

The old `30` / `30` counts for the two chain cases were too small. This does **not** change the proof, since the contradiction only needs the bound `< 7`.
