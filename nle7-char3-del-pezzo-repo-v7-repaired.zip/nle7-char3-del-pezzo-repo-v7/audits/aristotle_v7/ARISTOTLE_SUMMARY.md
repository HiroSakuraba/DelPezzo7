# Summary of changes
## Review of Derivations and Lemmas: Accuracy and Logical Consistency

I performed a thorough review of the paper "A Computer-Assisted Bound of Seven Singular Points for Rank-One klt del Pezzo Surfaces in Characteristic Three." The detailed findings are in `review_report.md`, and all key numerical computations are machine-verified in `RequestProject/VerifyComputations.lean` (compiles cleanly with no sorries).

### Overall Verdict: The main theorem and proof are correct.

All five N = 8 candidate baskets are validly eliminated, and the logical chain is sound.

### One Issue Found

**Lemma 4.2 (orthogonal root subsystems for exotic baskets):** The paper claims the root subsystem is A₅ (30 roots, max 3 pairwise orthogonal) for both 1/7(1,2) and 1/11(1,2). Independent computation suggests:

- **1/7(1,2):** 48 roots (larger than A₅), max **4** pairwise orthogonal.
- **1/11(1,2):** 32 roots (likely A₅ + A₁), max **4** pairwise orthogonal.

**This does NOT affect the proof's validity.** The bound max ≤ 4 < 7 still provides the required contradiction in Theorem 4.3. Recommendation: correct the root counts and max bounds in Lemma 4.2.

### Everything Else Verified Correct

- All 17 discrepancy table entries (Appendix A) ✓
- All K²_X computations for the five baskets ✓
- Cauchy–Schwarz bound in exotic normalization ✓
- Mixed basket polarization (L², K·L, L₁ and L₂ orbits) ✓
- All five orbit representatives satisfy D² = −3 and K·D = 1 ✓
- All Bézout violations (3a > d or 3b > d) confirmed ✓
- Degree-one computation for 8A₁ ✓
- Arithmetic genus computations on F₂: p_a(M)=0, p_a(2M)=1, p_a(3M)=4 ✓
- Node bound: max 6 < 8 required A₁ points ✓
- Disjointness S·C = 0 and branch class evenness ✓
- Base-point-avoids-(−2)-curves argument (M² = −1 contradiction) ✓
- Logical chain from five eliminations to main theorem ✓