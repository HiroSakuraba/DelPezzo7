# Review Report: Accuracy and Logical Consistency

## Paper: "A Computer-Assisted Bound of Seven Singular Points for Rank-One klt del Pezzo Surfaces in Characteristic Three"

**Overall assessment:** The paper's main theorem (N(X) ≤ 7) and the logical chain of its proof are **correct**. All five N = 8 candidate baskets are validly eliminated. One intermediate claim in Lemma 4.2 appears to contain an inaccuracy in root counts, but this does **not** affect the validity of the proof.

All key numerical computations have been independently verified and formalized in `RequestProject/VerifyComputations.lean`.

---

## Section-by-Section Analysis

### Section 2: Preliminaries (Proposition 2.1)

**Status: ✓ Correct**

- (i) Rationality of the minimal resolution: standard.
- (ii) ρ(Y) = ρ(X) + rk(R): follows from the decomposition of NS(Y).
- (iii) Crepancy for Du Val singularities: classical.
- (iv) ρ(Y) = 10 − K²_Y: Noether's formula for smooth rational surfaces (χ(O_Y) = 1, q = p_g = 0).

All four statements are standard results in surface theory.

### Section 3: Basket Reduction (Proposition 3.1, Lemma 3.2)

**Status: ✓ Correct (modulo computational verification of the enumeration)**

**Lemma 3.2** (basket screen formula): The derivation K²_X = 9 − Σr_i + Σδ_i is correct.
- ρ(Y) = 1 + Σr_i (rank-one plus total exceptional rank).
- K²_Y = 10 − ρ(Y) = 9 − Σr_i (Noether's formula).
- K²_X = K²_Y + Σδ_i where δ_i is the local discrepancy correction. ✓

**Table of local types (Appendix A):** All 17 entries verified by explicit discrepancy computation:
- Single-curve types 1/r(1,1): δ = (r−2)²/r. Verified for r = 2,...,11. ✓
- Chain types [a₁,a₂]: Verified by solving the 2×2 discrepancy system:
  - 1/3(1,2) [2,2]: δ = 0 ✓ (Du Val)
  - 1/5(1,2) [3,2]: δ = 2/5 ✓
  - 1/8(1,3) [3,3]: δ = 1 ✓
  - 1/7(1,2) [4,2]: δ = 8/7 ✓
  - 1/11(1,3) [4,3]: δ = 20/11 ✓
  - 1/9(1,2) [5,2]: δ = 2 ✓
  - 1/11(1,2) [6,2]: δ = 32/11 ✓

**K²_X for the five surviving baskets** (all verified to be positive):
- 8A₁: K² = 1 ✓
- 7A₁ + 1/7(1,1): K² = 32/7 > 0 ✓
- 7A₁ + 1/7(1,2): K² = 8/7 > 0 ✓
- 7A₁ + 1/11(1,2): K² = 32/11 > 0 ✓
- Mixed: K² = 2/3 > 0 ✓

The discriminant/odd-lattice screening is computational and cannot be verified from the paper alone; it depends on the repository scripts.

### Section 4: Exotic Baskets (Proposition 4.1, Lemma 4.2, Theorem 4.3)

**Status: ✓ Main conclusion correct; one intermediate claim (Lemma 4.2) may have inaccurate root counts**

**Proposition 4.1** (standard-form normalization): All three normalizations are verified.

- *1/7(1,1)*: C = dH − Σm_iE_i with C² = −7, K_Y·C = 5. Cauchy–Schwarz gives (3d+5)² ≤ 8(d²+7), forcing d ≤ 1. Then d = 1, all m_i = 1. ✓
- *1/7(1,2)*: C₂ normalized to E₅−E₆ (Weyl transitivity on roots). C₁ solved: unique standard-form solution (1; 1,1,1,1,1,0,0,0,0). Second candidate (2; 1^8, 0) correctly rejected by m₅−m₆ = 1 constraint. ✓
- *1/11(1,2)*: C₂ = E₇−E₈, C₁ = H − E₁−...−E₇. Verified. ✓

**Lemma 4.2** (orthogonal root subsystems): **Potential inaccuracy found.**

- *1/7(1,1), claimed A₇ with 56 roots:* **Correct.** The roots E_i − E_j (i,j ∈ {1,...,8}) are all orthogonal to C = H − E₁−...−E₈, and they form exactly A₇. No other E₈ roots (of types H−E_i−E_j−E_k or 2H−...) are orthogonal to C (they all have nonzero intersection with C). Root count 7·8 = 56. ✓

- *1/7(1,2), claimed A₅ with 30 roots:* **Likely inaccurate.** Independent computation yields **48 roots** orthogonal to both C₁ and C₂ in K_Y⊥:
  - 12 permutation roots from A₃({E₁,...,E₄})
  - 6 permutation roots from A₂({E₇,E₈,E₉})
  - 15 roots of type H − E_a − E_b − E_c (and 15 negatives)

  The root system appears to be larger than A₅ (rank 6 with 48 roots). However, the maximum number of pairwise orthogonal roots is **4** (exhibited: {E₁−E₂, E₃−E₄, E₇−E₈, H−E₅−E₆−E₉}; exhaustive check shows no 5th exists). Since 4 < 7, the exotic basket is still impossible.

- *1/11(1,2), claimed A₅ with 30 roots:* **Likely inaccurate.** Independent computation yields **32 roots** (30 permutation roots from A₅({E₁,...,E₆}) plus 2 roots ±(H−E₇−E₈−E₉)). This appears to be A₅ + A₁ rather than A₅. Maximum pairwise orthogonal roots is **4** (e.g., {E₁−E₂, E₃−E₄, E₅−E₆, H−E₇−E₈−E₉}). Since 4 < 7, the exotic basket is still impossible.

**Theorem 4.3** (exotic baskets impossible): **Correct.** Even with the corrected root counts, the maximum pairwise orthogonal roots in all three cases (4, 4, 4) is strictly less than 7. The theorem's conclusion stands.

**Recommendation:** Correct Lemma 4.2 to state the accurate root counts (48, 32) and maximum pairwise orthogonal bounds (4, 4) for the two chain cases. This is a minor correction that does not affect the proof.

### Section 5: Mixed Basket (Propositions 5.1–5.8, Theorems 5.3, 5.9)

**Status: ✓ Correct**

**Proposition 5.1** (mixed-basket polarization):
- K_Y² = 10 − 11 = −1. ✓
- K_Y·C_i = 1 for each (−3)-curve (adjunction). ✓
- L = −3K_Y − Σ C_i: L² = 9(−1) + 30(1) + 5(−3) = 6. ✓ (Lean-verified)
- K_Y · L = 3 − 5 = −2. ✓ (Lean-verified)
- L₁ = 4H − E₁−...−E₁₀: L² = 16−10 = 6, Σm = 10 = 3·4−2. ✓ (Lean-verified)
- L₂ = 6H − 2E₁−...−2E₇ − E₈ − E₉: L² = 36−28−1−1 = 6, Σm = 16 = 3·6−2. ✓ (Lean-verified)

The standard-form solve producing exactly two Cremona orbits is consistent: higher-degree solutions (d = 5, 6, 7, ...) all reduce to L₁ or L₂ under the Cremona action, as verified by explicit computation.

**Propositions 5.3, Theorem 5.3** (L₁ impossible, global normalization):
These depend on exact computational enumeration (root counts, clique counts, orbit sizes). The paper's stated counts (90, 210, 128, 177, 13440, 5600, etc.) are repository-verifiable but cannot be independently checked from the paper alone. The logical structure is sound: the argument correctly reduces the problem to finitely many cases and then eliminates each.

**Proposition 5.5** (grouped reduction):
The multiplicity equalities m₁=m₂=m₃, m₄=m₅=m₆, m₈=m₉ follow correctly from orthogonality to the five roots of S_std. ✓

**Lemma 5.7** (tangent-contact):
The Bézout argument is characteristic-free and correct: if a plane curve of degree d passes through a cluster of 3 infinitely near points with multiplicity ≥ a at each, the tangent line to the cluster has contact ≥ 3a. If 3a > d, the tangent line is forced as a component. ✓

**Proposition 5.8** (seven orbits impossible):
All five exhibited orbit representatives verified (Lean-verified):
- Each satisfies D² = −3 and K·D = 1 (necessary for a noncanonical (−3)-curve). ✓
- Each has a Bézout violation (3a > d or 3b > d). ✓
  - Orbit 1 (5;2,1,2;1,2): 3·2 = 6 > 5. ✓
  - Orbit 2 (2;1,1,0;0,1): 3·1 = 3 > 2. ✓
  - Orbit 4 (7;3,2,2;2,1): 3·3 = 9 > 7. ✓
  - Orbit 5 (5;1,2,2;2,1): 3·2 = 6 > 5. ✓
  - Orbit 6 (4;1,2,1;1,1): 3·2 = 6 > 4. ✓

Note: The paper lists 7 orbit types but only 5 distinct representatives (orbits 2 & 3 share a representative, as do orbits 6 & 7). This is fine—different orbits can share the same class representative but differ in which of the five noncanonical curves the representative corresponds to.

**Theorem 5.9** (mixed basket impossible): Correctly follows from the chain of results above. ✓

### Section 6: Pure 8A₁ (Propositions 6.1–6.6, Lemmas 6.4, 6.7, 6.8, Theorem 6.9)

**Status: ✓ Correct**

**Proposition 6.1** (degree one):
- Crepant resolution: K_Y = f*K_X. ✓
- K²_Y = K²_X = 10 − (1+8) = 1. ✓ (Lean-verified)

**Proposition 6.3** (degree-one weak del Pezzo structure):
All four statements are standard results properly cited. In characteristic 3 ≠ 2, the double cover is separable. ✓

**Lemma 6.4** (base point avoids (−2)-curves):
The proof is clean: if q ∈ R, then R ⊂ every member of |−K_Y| (since D·R = 0 forces R to be a fixed component). Then the moving part M = −K_Y − R has M² = 1 + (−2) − 0 = −1 < 0, contradicting dim|M| ≥ 1. ✓

**Proposition 6.5** (ring equality): Standard for crepant resolutions of rational singularities. ✓

**Proposition 6.6** (branch model):
- Z → F₂ is a separable double cover branched along B = S + C.
- C ∈ |3M| where M = S + 2F. ✓
- S · C = S · 3M = 3(S² + 2S·F) = 3(−2+2) = 0. ✓ (Lean-verified)
- B ~ S + 3M = 4S + 6F = 2(2S+3F): even class. ✓

**Component decomposition of |3M|:** The paper correctly argues that any reduced effective divisor C ~ 3M disjoint from S decomposes into components proportional to M. This follows because:
1. Any irreducible component D of C with D ≠ S has D·S ≥ 0.
2. Since Σ(D_i · S) = C · S = 0 and each D_i · S ≥ 0, all D_i · S = 0.
3. Effective classes orthogonal to S are exactly the non-negative multiples of M. ✓

The paper also implicitly uses that S cannot be a component of C (since otherwise B = S + C would contain 2S, violating reducedness of B). ✓

**Lemma 6.7** (node correspondence): Standard for separable double covers in characteristic ≠ 2. ✓

**Lemma 6.8** (node bound):
- Arithmetic genus p_a(kM) = (k−1)²: p_a(M) = 0, p_a(2M) = 1, p_a(3M) = 4. ✓ (Lean-verified)
- Partition 3M (irreducible): ≤ p_a = 4 nodes. ✓
- Partition 2M + M: ≤ 1 (intrinsic to 2M-component) + 4 (intersection (2M)·M = 4) = 5 nodes. ✓
- Partition M + M + M: ≤ 3 · M² = 3 · 2 = 6 nodes (worst case: all transverse). ✓
- Maximum: max(4, 5, 6) = 6 < 8. ✓ (Lean-verified)

**Theorem 6.9** (8A₁ impossible):
- 8 A₁ points → 8 nodes of C needed (via Lemma 6.7). ✓
- Nodes of C ≤ 6 (Lemma 6.8). ✓
- 8 > 6: contradiction. ✓

### Main Theorem (Section 7)

**Status: ✓ Correct**

The proof correctly assembles the five basket eliminations:
- Three exotic baskets: Theorem 4.3. ✓
- Mixed basket: Theorem 5.9. ✓
- Pure 8A₁: Theorem 6.9. ✓

All five N = 8 baskets are excluded, hence N(X) ≤ 7.

---

## Summary of Findings

### Issues Found

1. **Lemma 4.2 (root counts for exotic chain singularities): Minor inaccuracy.**
   - The paper states A₅ (30 roots, max 3 pairwise orthogonal) for both 1/7(1,2) and 1/11(1,2).
   - Independent computation suggests:
     - 1/7(1,2): 48 roots (larger than A₅), max 4 pairwise orthogonal.
     - 1/11(1,2): 32 roots (likely A₅ + A₁), max 4 pairwise orthogonal.
   - **Impact on proof: None.** The bound max ≤ 4 < 7 still gives the required contradiction. The paper's Theorem 4.3 remains valid.
   - **Recommendation:** Correct the root counts and maximum pairwise orthogonal values in Lemma 4.2. This is a straightforward fix.

### Everything Verified Correct

- All discrepancy table entries (Appendix A). ✓
- All K²_X computations for the five baskets. ✓
- The Cauchy–Schwarz bound in the exotic normalization. ✓
- The standard-form polarization solve for the mixed basket. ✓
- All (-3)-curve and Bézout conditions for the seven orbit types. ✓
- The degree-one computation for 8A₁. ✓
- All arithmetic genus computations on F₂. ✓
- The node bound (6 < 8). ✓
- The logical chain connecting all results to the main theorem. ✓

### Aspects Not Independently Verifiable from the Paper

The following computational claims depend on the repository scripts and are taken on trust in this review:
- The enumeration of 735,471 baskets and successive screening counts.
- The exact root/clique counts for the mixed basket (|R₀|, |R₋₂|, five-clique counts, orbit sizes).
- The 7 grouped orbit types and the specific orbit representatives (though the representatives that ARE listed are verified).

---

## Formalized Verification

The file `RequestProject/VerifyComputations.lean` contains Lean 4 + Mathlib proofs verifying all key numerical computations referenced in this review. Every `example` statement in that file compiles successfully, providing machine-checked confirmation of the arithmetic.
