# AI agent entrypoint

This file is for a future AI agent who needs to understand what matters without rereading the entire repository blindly.

## 1. What is load-bearing for the theorem?
The final theorem proof uses only the corrected final chain in `scripts/`, `results/`, and the current `paper/` draft. Do **not** treat older exploratory files as theorem dependencies unless the paper cites them directly.

## 2. What were the important exploratory lanes?

### A. Ambient/deformation and high-dimensional search stack (`v30`)
This lane contains reusable search infrastructure, including:
- `scripts/matroid_realizability.py`
- `scripts/circuit_signature.py`
- `scripts/constraint_solver.py`
- `scripts/grobner_fingerprint.py`

These were valuable for structural screening and candidate triage, but they are not part of the final proof. They remain useful as design patterns for future hard search problems.

### B. Quasi-elliptic/global probe (`v50`)
This lane records several ambient scans and later branch probes. It is mainly useful if you want to understand which ambient-model directions were explored and abandoned before the blowup-lattice proof stabilized.

### C. Wild/additive and Artin-Schreier lane (`v20`)
This lane is important historically because it explains why characteristic-3 additive-action constructions were investigated and how they were constrained. Start with:
- `no_go_ledger.md`
- `klt_progress_v20.md`


### D. Historical draft documents
A separate folder preserves older papers / handoff documents:
- `exploratory/historical_documents/older_drafts/`
- `docs/HISTORICAL_DOCUMENTS_INDEX.md`

These are useful for search-memory, matroid/coding exposition, quartic-sandbox context, and older AI-agent handoff. They are **not** theorem dependencies unless cited.

## 3. If the theorem ever needs to be extended
The first place to look is the mixed-basket and pure `8A1` proof chain in the final scripts. The second place is the exploratory wild/ambient lanes, not because they are likely theorem inputs, but because they show which escape routes have already been checked.

## 4. Matroid note
There is no matroid section in the paper. The matroid and circuit tools are preserved in the repository as exploratory search infrastructure for future agents, not as final theorem ingredients.
