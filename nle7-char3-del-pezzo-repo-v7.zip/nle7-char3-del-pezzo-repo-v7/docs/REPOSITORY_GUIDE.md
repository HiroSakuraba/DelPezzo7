# Repository guide

## Purpose
This repository accompanies the paper and is meant to make the computational parts of the argument inspectable, rerunnable, and archivable.

## How to navigate

### If you are checking the theorem
Read only:
- `paper/`
- `scripts/`
- `results/`

### If you are a future AI agent continuing the project
Start with:
- `docs/AI_AGENT_ENTRYPOINT.md`
- `docs/HISTORICAL_NO_GO_LEDGER.md`
- then inspect `exploratory/` selectively.

## Reproducibility map

| Paper component | Repository files |
|---|---|
| Final basket reduction / corrected lattice screen | `scripts/i0iv_v79_odd_lattice_bilinear_anticanonical_screen.py`, `results/json/v79.json`, `results/notes/v79.md` |
| Exotic basket closures | `scripts/i0iv_v94_exotic_baskets_global_closure.py`, `results/json/v94.json`, `results/notes/v94.md` |
| Mixed basket polarization orbit reduction | `scripts/i0iv_v95_mixed_basket_polarization_orbit_reduction.py`, `results/json/v95.json`, `results/notes/v95.md` |
| Mixed basket grouped orbit reduction | `scripts/i0iv_v96_L2_orbit_combinatorics_reduction.py`, `results/json/v96.json`, `results/notes/v96.md` |
| Mixed basket global normalization theorem | `scripts/i0iv_v98_mixed_basket_global_normalization_theorem.py`, `results/json/v98.json`, `results/notes/v98.md` |
| Pure 8A1 closure via degree-1 branch-node bound | `scripts/i0iv_v72_singular_base_degree1_double_cover.py`, `results/json/v72.json`, `results/notes/v72.md`, `results/notes/v99.md` |

## Exploratory map

| Exploratory lane | Main files | Why preserved |
|---|---|---|
| Ambient/deformation + Picard merge | `exploratory/ambient_deformation_lanes/v30_picard_merge/` | Shows the earlier search stack, including matroid-style screens and compiled finite-field backends. |
| Quasi-elliptic/global probe | `exploratory/quasi_elliptic_global_probe/v50/` | Records late ambient scans that were informative but not part of the final theorem. |
| Wild/additive/Artin-Schreier lane | `exploratory/wild_alpha3/v20/` | Preserves the no-go ledger for additive-action and Artin-Schreier branches. |

## Minimal rerun commands
Examples:

```bash
python scripts/i0iv_v95_mixed_basket_polarization_orbit_reduction.py
python scripts/i0iv_v96_L2_orbit_combinatorics_reduction.py
python scripts/i0iv_v98_mixed_basket_global_normalization_theorem.py
```

Some scripts print counts directly; others are best read together with their paired note and JSON summary.

| External audit patch for exotic-chain root counts | `results/notes/v100_aristotle_patch.md`, `results/json/v100_aristotle_patch.json`, `docs/EXTERNAL_AUDITS.md`, `audits/aristotle_v7/` |
